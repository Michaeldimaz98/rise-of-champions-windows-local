// Ranked-PvP persistence: in-memory state + atomic JSON file.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { blankState } from './competitive.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.resolve(__dirname, '../../data/ranked.json');

export let ranked = blankState();

export function loadRanked() {
  try {
    ranked = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    // Phase 39b: backfill fields for pre-sealed-duel state files.
    if (!ranked.rankedConfigs) ranked.rankedConfigs = {};
    if (!Array.isArray(ranked.fixtures)) ranked.fixtures = [];
    if (!ranked.recentOpponents) ranked.recentOpponents = {};
    return true;
  } catch {
    ranked = blankState();
    return false;
  }
}

export function persistRanked() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(ranked));
  fs.renameSync(tmp, DATA_FILE);
}
