// Competitive PvP (Phase 22) — DOMAIN module. Pure logic: no HTTP, no DOM, no DB.
// Elo-style rating, matchmaking queue, ranked fixtures, PvP seasons with
// tier rewards, and anti-abuse rules.
//
// Phase 39b: fixture execution moved to the sealed tactical duel model
// (pvp/sealed.js). Matchmaking/queue/Elo/seasons stay here; fixture creation
// delegates to createSealedFixture.
import { assert } from '../core/validate.js';
import { recordTransaction } from '../finance/finance.js';
import { createSealedFixture } from './sealed.js';

export const START_RATING = 1000;
export const K_FACTOR = 32;
export const SEASON_DAYS = 30;
export const MAX_RECENT_OPPONENTS = 3;

export const TIERS = [
  { name: 'Diamond', min: 1800 },
  { name: 'Platinum', min: 1500 },
  { name: 'Gold', min: 1300 },
  { name: 'Silver', min: 1100 },
  { name: 'Bronze', min: 0 },
];

export const TIER_REWARDS = { Diamond: 500000, Platinum: 250000, Gold: 100000, Silver: 50000, Bronze: 10000 };

function deepCopy(o) {
  return JSON.parse(JSON.stringify(o));
}

export function blankState() {
  const now = Date.now();
  return {
    season: { number: 1, startedAt: now, endsAt: now + SEASON_DAYS * 86400000 },
    ratings: {}, // userId -> { username, rating, w, d, l }
    queue: [], // { userId, username, joinedAt }
    fixtures: [], // ranked fixtures, newest last
    recentOpponents: {}, // userId -> [oppUserId, ...] (last N, anti rematch-spam)
    rankedConfigs: {}, // Phase 39b: userId -> last sealed tactical config (fallback P1)
  };
}

// --- rating ---
export function expectedScore(ra, rb) {
  return 1 / (1 + Math.pow(10, (rb - ra) / 400));
}

/** scoreA: 1 = A wins, 0.5 = draw, 0 = A loses. Returns [newA, newB]. */
export function updateRatings(ra, rb, scoreA) {
  const ea = expectedScore(ra, rb);
  return [
    Math.max(0, Math.round(ra + K_FACTOR * (scoreA - ea))),
    Math.max(0, Math.round(rb + K_FACTOR * ((1 - scoreA) - (1 - ea)))),
  ];
}

export function tierFor(rating) {
  for (const t of TIERS) if (rating >= t.min) return t.name;
  return 'Bronze';
}

export function getEntry(state, userId, username = '?') {
  let e = state.ratings[userId];
  if (!e) {
    e = { username, rating: START_RATING, w: 0, d: 0, l: 0 };
    state.ratings[userId] = e;
  } else if (username !== '?' && e.username !== username) {
    e.username = username;
  }
  return e;
}

// --- queue & matchmaking ---
/** A fixture the user still has to act on (preparing/sealed, not completed). */
export function isPendingFixture(f) {
  return f.status === 'preparing' || f.status === 'pending';
}

function pendingFixtureOf(state, userId) {
  return state.fixtures.find((f) => isPendingFixture(f)
    && (f.aUserId === userId || f.bUserId === userId));
}

export function joinQueue(state, { userId, username }, getCareer) {
  assert(!state.queue.some((q) => q.userId === userId), 'already in queue');
  assert(!pendingFixtureOf(state, userId), 'finish your pending ranked match first');
  getEntry(state, userId, username);
  state.queue.push({ userId, username, joinedAt: Date.now() });
  return tryMatch(state, getCareer);
}

export function leaveQueue(state, userId) {
  const i = state.queue.findIndex((q) => q.userId === userId);
  if (i >= 0) state.queue.splice(i, 1);
  return true;
}

/** Pair the two closest-rated queuers who aren't recent opponents. */
export function tryMatch(state, getCareer) {
  if (state.queue.length < 2) return null;
  let best = null;
  for (let i = 0; i < state.queue.length; i++) {
    for (let j = i + 1; j < state.queue.length; j++) {
      const a = state.queue[i];
      const b = state.queue[j];
      if ((state.recentOpponents[a.userId] ?? []).includes(b.userId)) continue;
      const diff = Math.abs(getEntry(state, a.userId).rating - getEntry(state, b.userId).rating);
      if (!best || diff < best.diff) best = { a, b, diff };
    }
  }
  if (!best) return null;
  state.queue = state.queue.filter((q) => q.userId !== best.a.userId && q.userId !== best.b.userId);
  return createSealedFixture(state, best.a.userId, best.b.userId, getCareer);
}

export function rememberOpponents(state, a, b) {
  for (const [u, o] of [[a, b], [b, a]]) {
    const list = state.recentOpponents[u] ?? [];
    list.unshift(o);
    state.recentOpponents[u] = list.slice(0, MAX_RECENT_OPPONENTS);
  }
}

// --- seasons ---
export function seasonEnded(state) {
  return Date.now() >= state.season.endsAt;
}

/**
 * Roll over to a new PvP season. Anyone may trigger once the season ended.
 * Tier rewards go to each manager's career club (if they played >= 1 match).
 * Ratings soft-reset toward START_RATING. applyReward(career, amount, text)
 * is injected so the domain stays persistence-free.
 */
export function rolloverSeason(state, { getCareer, applyReward }) {
  assert(seasonEnded(state), 'season has not ended yet');
  const rewards = [];
  for (const [userId, e] of Object.entries(state.ratings)) {
    const played = e.w + e.d + e.l;
    if (played === 0) continue;
    const tier = tierFor(e.rating);
    const amount = TIER_REWARDS[tier];
    const career = getCareer(userId);
    if (career && amount > 0) {
      applyReward(career, amount, `Ranked Season ${state.season.number} — ${tier} reward`);
      rewards.push({ userId, username: e.username, tier, amount });
    }
    // soft reset toward START_RATING
    e.rating = Math.round(START_RATING + (e.rating - START_RATING) * 0.5);
    e.w = 0; e.d = 0; e.l = 0;
  }
  const now = Date.now();
  state.season = { number: state.season.number + 1, startedAt: now, endsAt: now + SEASON_DAYS * 86400000 };
  state.queue = [];
  state.recentOpponents = {};
  return rewards;
}

export function rankedLeaderboard(state, limit = 20) {
  return Object.entries(state.ratings)
    .map(([userId, e]) => ({ userId, username: e.username, rating: e.rating, tier: tierFor(e.rating), w: e.w, d: e.d, l: e.l }))
    .sort((a, b) => b.rating - a.rating)
    .slice(0, limit);
}

export function defaultApplyReward(career, amount, text) {
  const club = career.clubs[career.playerClubId].club;
  recordTransaction(club, { type: 'pvp_season_reward', amount, description: text });
}
