// Sealed Tactical PvP (Phase 39b) — DOMAIN module. Pure logic: no HTTP, no DOM, no DB.
//
// Replaces the old Ranked execution model (whoever pressed Play used their live
// squad vs an opponent snapshot, with live tactical intervention for one side
// only). The new model is an asynchronous, symmetric Sealed Tactical Duel:
//
// - At matchmaking the server freezes an immutable competitive player pool per
//   manager, generates an immutable matchSeed, and precomputes an immutable
//   fallback tactical configuration per manager.
// - Each manager independently prepares a tactical configuration (XI,
//   formation, bench, base tactics, bounded tactical plan) and SEALS it.
//   Sealing snapshots the server-authoritative condition (fitness/injury) of
//   the selected players at seal time. A sealed configuration is immutable.
// - When both managers have sealed, the server runs ONE canonical simulation
//   with the existing match engine (no second engine) and persists ONE
//   canonical event log. Both managers see the same result.
// - If the 24h preparation deadline passes, missing sides use their
//   precomputed fallback. The fixture never hangs indefinitely.
// - Managers never need to be online simultaneously. No WebSocket/realtime.
import { createRng } from '../core/rng.js';
import { newId } from '../core/ids.js';
import { assert, isOneOf } from '../core/validate.js';
import {
  createMatch,
  playMatchSegment,
  emitKickoff,
  applyHalftimeBreak,
  emitFulltime,
  finalizeMatch,
  recalcTeamEff,
} from '../match/engine.js';
import { buildMatchReport } from '../match/report.js';
import {
  createTactics,
  setTactic,
  setFormation,
  setPlayerInstruction,
  ORDER_KEYS,
  FLAG_KEYS,
} from '../tactics/tactics.js';
import { getFormation } from '../tactics/formation.js';
import { careerTeamBundle } from '../career/career.js';
import { getEntry, updateRatings, rememberOpponents } from './competitive.js';

export const PREPARATION_WINDOW_MS = 24 * 3600 * 1000;
export const MAX_PLAN_RULES = 5;
export const PLAN_MINUTES = [45, 60, 75];
export const PLAN_SCORE_STATES = ['winning', 'drawing', 'losing', 'losing_by_2'];
export const PLAN_SUB_LIMIT = 5;
export const MAX_BENCH = 7;

const ACTIVE_STATUSES = ['preparing'];

export function isActiveSealedFixture(fx) {
  return !!fx && ACTIVE_STATUSES.includes(fx.status);
}

function deepCopy(o) {
  return JSON.parse(JSON.stringify(o));
}

/** Normalize tactics to a complete, validated object (fills defaults). */
export function normalizeTactics(input) {
  const t = createTactics();
  if (!input || typeof input !== 'object') return extractTactics(t);
  if (input.formation !== undefined) setFormation(t, input.formation);
  for (const key of [...ORDER_KEYS, ...FLAG_KEYS]) {
    if (input[key] !== undefined) setTactic(t, key, input[key]);
  }
  return extractTactics(t);
}

function extractTactics(t) {
  const out = { formation: t.formation };
  for (const key of [...ORDER_KEYS, ...FLAG_KEYS]) out[key] = t[key];
  return out;
}

/**
 * Minimal immutable player snapshot: only what the match engine reads.
 * The engine consumes id/name/position/attributes/fitness/injury. It does
 * NOT read morale/form (those are only written post-match), so they are
 * deliberately excluded from the frozen pool.
 */
export function snapshotPoolPlayer(p) {
  assert(p && p.id && p.position && p.attributes, 'invalid player for pool snapshot');
  return {
    id: p.id,
    name: p.name,
    position: p.position,
    attributes: { ...p.attributes },
    fitness: Math.max(0, Math.min(100, Math.round(p.fitness ?? 100))),
    injury: !!p.injury,
  };
}

function attrSum(p) {
  return Object.values(p.attributes ?? {}).reduce((s, v) => s + (v || 0), 0);
}

/** Deterministic pool ordering: attribute sum desc, id asc. */
function sortedPool(pool) {
  return [...pool].sort((a, b) => attrSum(b) - attrSum(a) || (a.id < b.id ? -1 : 1));
}

function poolById(pool) {
  return new Map(pool.map((p) => [p.id, p]));
}

function poolHasGk(pool) {
  return pool.some((p) => p.position === 'GK');
}

// ---------------------------------------------------------------------------
// Tactical plan validation
// ---------------------------------------------------------------------------

function validatePlanRule(rule, poolIds, lineupIds, benchIds) {
  assert(rule && typeof rule === 'object', 'plan rule must be an object');
  const cond = rule.if ?? {};
  assert(
    PLAN_MINUTES.includes(cond.minuteGte),
    `plan minuteGte must be one of ${PLAN_MINUTES.join(', ')}`
  );
  assert(
    PLAN_SCORE_STATES.includes(cond.scoreState),
    `plan scoreState must be one of ${PLAN_SCORE_STATES.join(', ')}`
  );
  const then = rule.then ?? {};
  const actionKeys = ['mentality', 'pressing', 'tempo', 'sub'].filter((k) => then[k] !== undefined);
  assert(actionKeys.length === 1, 'plan rule must have exactly one action (mentality|pressing|tempo|sub)');
  const t = createTactics();
  const key = actionKeys[0];
  if (key === 'sub') {
    const s = then.sub ?? {};
    assert(typeof s.out === 'string' && typeof s.in === 'string', 'plan sub needs {out,in} player ids');
    assert(s.out !== s.in, 'plan sub out/in must differ');
    assert(lineupIds.includes(s.out), 'plan sub out must be in the sealed XI');
    assert(benchIds.includes(s.in), 'plan sub in must be on the sealed bench');
    assert(poolIds.has(s.out) && poolIds.has(s.in), 'plan sub players must be in the fixture pool');
  } else {
    setTactic(t, key, then[key]); // throws on invalid value
  }
  return {
    if: { minuteGte: cond.minuteGte, scoreState: cond.scoreState },
    then: key === 'sub'
      ? { sub: { out: then.sub.out, in: then.sub.in } }
      : { [key]: then[key] },
  };
}

export function validatePlan(plan, poolIds, lineupIds, benchIds) {
  if (plan === undefined || plan === null) return [];
  assert(Array.isArray(plan), 'tactical plan must be an array');
  assert(plan.length <= MAX_PLAN_RULES, `tactical plan allows at most ${MAX_PLAN_RULES} rules`);
  return plan.map((r) => validatePlanRule(r, poolIds, lineupIds, benchIds));
}

/** Non-throwing plan filter for fallback sanitization. */
function sanitizePlan(plan, poolIds, lineupIds, benchIds) {
  if (!Array.isArray(plan)) return [];
  const out = [];
  for (const r of plan) {
    try {
      out.push(validatePlanRule(r, poolIds, lineupIds, benchIds));
      if (out.length >= MAX_PLAN_RULES) break;
    } catch { /* drop invalid rule */ }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Config normalization / sanitization
// ---------------------------------------------------------------------------

function checkXi(lineupIds, poolIds, pool) {
  assert(Array.isArray(lineupIds) && lineupIds.length === 11, 'lineup must have exactly 11 players');
  assert(new Set(lineupIds).size === 11, 'lineup must not contain duplicates');
  for (const id of lineupIds) assert(poolIds.has(id), `lineup player ${id} is not in the fixture pool`);
  if (poolHasGk(pool)) {
    const gks = lineupIds.filter((id) => poolIds.get(id).position === 'GK').length;
    assert(gks === 1, 'lineup must contain exactly one goalkeeper');
  }
}

function checkBench(benchIds, poolIds, lineupIds) {
  assert(Array.isArray(benchIds), 'bench must be an array');
  assert(benchIds.length <= MAX_BENCH, `bench allows at most ${MAX_BENCH} players`);
  assert(new Set(benchIds).size === benchIds.length, 'bench must not contain duplicates');
  for (const id of benchIds) {
    assert(poolIds.has(id), `bench player ${id} is not in the fixture pool`);
    assert(!lineupIds.includes(id), `bench player ${id} is already in the lineup`);
  }
}

/**
 * Strict validation of a manager-submitted sealed configuration.
 * Returns a normalized config WITHOUT condition/source (added by sealFixture).
 * Throws on any invalid input.
 */
/**
 * Phase 39c: validate sealed player instructions.
 * Accepts only the existing catalog ('red' | 'blue'), keyed by playerId.
 * Player must be in the sealed XI or bench; forged modifiers are rejected
 * by only reading the arrow value (unknown keys/values throw).
 * Returns a normalized { playerId: 'red'|'blue' } map (possibly empty).
 */
export function validateInstructions(input, lineupIds, benchIds) {
  const out = {};
  if (input == null) return out;
  assert(input && typeof input === 'object' && !Array.isArray(input),
    'playerInstructions must be an object');
  const eligible = new Set([...lineupIds, ...benchIds]);
  for (const [pid, arrow] of Object.entries(input)) {
    assert(typeof pid === 'string' && pid.length > 0, 'instruction playerId must be a string');
    assert(eligible.has(pid), `instruction for player outside sealed XI/bench: ${pid}`);
    assert(arrow === 'red' || arrow === 'blue',
      `invalid instruction '${arrow}' for player ${pid} (valid: red, blue)`);
    out[pid] = arrow;
  }
  return out;
}

export function validateSealInput(input, pool) {
  assert(input && typeof input === 'object', 'configuration required');
  const poolIds = poolById(pool);
  const lineupIds = [...(input.lineupIds ?? [])];
  const benchIds = [...(input.benchIds ?? [])];
  checkXi(lineupIds, poolIds, pool);
  checkBench(benchIds, poolIds, lineupIds);
  const tactics = normalizeTactics({ ...(input.tactics ?? {}), formation: input.formation });
  const plan = validatePlan(input.plan ?? [], poolIds, lineupIds, benchIds);
  const playerInstructions = validateInstructions(input.playerInstructions, lineupIds, benchIds);
  return {
    v: 1,
    lineupIds,
    benchIds,
    formation: tactics.formation,
    tactics,
    plan,
    playerInstructions,
  };
}

/** Fill XI to 11 deterministically from the pool (attr sum desc). */
function fillXi(lineupIds, pool) {
  const ids = [...lineupIds];
  const have = new Set(ids);
  const needGk = poolHasGk(pool) && !ids.some((id) => poolById(pool).get(id)?.position === 'GK');
  const byId = poolById(pool);
  if (needGk) {
    const gk = sortedPool(pool).find((p) => p.position === 'GK' && !have.has(p.id));
    if (gk) { ids.push(gk.id); have.add(gk.id); }
  }
  for (const p of sortedPool(pool)) {
    if (ids.length >= 11) break;
    if (!have.has(p.id)) { ids.push(p.id); have.add(p.id); }
  }
  return ids.slice(0, 11);
}

/**
 * Best-effort deterministic sanitization (for fallbacks / previous configs).
 * Returns a normalized config or null when the pool cannot yield a valid XI.
 */
export function sanitizeConfig(input, pool) {
  try {
    if (!input || typeof input !== 'object' || !Array.isArray(pool) || pool.length < 11) return null;
    const byId = poolById(pool);
    let lineupIds = (input.lineupIds ?? []).filter((id) => byId.has(id));
    lineupIds = [...new Set(lineupIds)];
    lineupIds = fillXi(lineupIds, pool);
    if (lineupIds.length !== 11) return null;
    let benchIds = [...new Set(input.benchIds ?? [])]
      .filter((id) => byId.has(id) && !lineupIds.includes(id))
      .slice(0, MAX_BENCH);
    let formation = '4-4-2';
    try { if (input.formation) { getFormation(input.formation); formation = input.formation; } } catch { /* default */ }
    let tactics;
    try { tactics = normalizeTactics({ ...(input.tactics ?? {}), formation }); }
    catch { tactics = normalizeTactics({ formation }); }
    const plan = sanitizePlan(input.plan, byId, lineupIds, benchIds);
    // plan sub targets may have shifted after fill — re-validate strictly; drop plan on failure
    let safePlan = plan;
    try { validatePlan(plan, byId, lineupIds, benchIds); } catch { safePlan = []; }
    // Phase 39c: carry player instructions through fallbacks. Accepts the
    // top-level sealed shape or the career-tactics shape; drops anything that
    // does not validate against the sanitized XI/bench (defensive).
    let playerInstructions = {};
    try {
      playerInstructions = validateInstructions(
        input.playerInstructions ?? input.tactics?.playerInstructions,
        lineupIds, benchIds);
    } catch { playerInstructions = {}; }
    return { v: 1, lineupIds, benchIds, formation: tactics.formation, tactics, plan: safePlan, playerInstructions };
  } catch {
    return null;
  }
}

/** Deterministic safe-default XI from the pool (best GK + best 10 outfield). */
function defaultXi(pool) {
  const sorted = sortedPool(pool);
  const gk = sorted.find((p) => p.position === 'GK');
  const out = sorted.filter((p) => p.position !== 'GK').slice(0, 10);
  const ids = [];
  if (gk) ids.push(gk.id);
  for (const p of out) ids.push(p.id);
  // top up if short (tiny pools)
  for (const p of sorted) {
    if (ids.length >= 11) break;
    if (!ids.includes(p.id)) ids.push(p.id);
  }
  return ids.slice(0, 11);
}

function conditionFromPool(pool, ids) {
  const byId = poolById(pool);
  const out = {};
  for (const id of ids) {
    const p = byId.get(id);
    if (p) out[id] = { fitness: p.fitness, injury: p.injury };
  }
  return out;
}

/**
 * Fallback priority: previous ranked config → career config at matchmaking →
 * deterministic safe default. The fallback is complete, valid, and immutable
 * after fixture creation; later career changes never alter it.
 */
export function buildFallbackConfig(pool, prevConfig, careerConfig, now = Date.now()) {
  const mk = (cfg, source) => ({
    ...cfg,
    condition: conditionFromPool(pool, [...cfg.lineupIds, ...cfg.benchIds]),
    source,
    createdAt: now,
  });
  if (prevConfig) {
    const s = sanitizeConfig(prevConfig, pool);
    if (s) return mk(s, 'previous');
  }
  if (careerConfig) {
    const s = sanitizeConfig(careerConfig, pool);
    if (s) return mk(s, 'career');
  }
  const lineupIds = defaultXi(pool);
  const s = sanitizeConfig({ lineupIds, benchIds: [], formation: '4-4-2', tactics: {}, plan: [] }, pool);
  if (s) return mk(s, 'default');
  throw new Error('cannot build a fallback configuration from the fixture pool');
}

// ---------------------------------------------------------------------------
// Fixture creation
// ---------------------------------------------------------------------------

function snapshotCareerConfig(career) {
  const bundle = careerTeamBundle(career, career.playerClubId);
  return {
    lineupIds: bundle.players.map((p) => p.id),
    benchIds: bundle.bench.map((p) => p.id),
    formation: bundle.tactics?.formation ?? '4-4-2',
    tactics: bundle.tactics ?? {},
    // Phase 39c: capture the manager's current instructions for fallback priority 2.
    playerInstructions: { ...(bundle.tactics?.playerInstructions ?? {}) },
    plan: [],
  };
}

/**
 * Create a sealed-tactical fixture at matchmaking. Freezes the competitive
 * player pool, generates the immutable matchSeed, and precomputes immutable
 * fallback configurations. Lightweight: only engine-relevant player fields.
 */
export function createSealedFixture(state, aUserId, bUserId, getCareer, now = Date.now()) {
  assert(aUserId && bUserId && aUserId !== bUserId, 'two distinct managers required');
  const careerA = getCareer(aUserId);
  const careerB = getCareer(bUserId);
  assert(careerA, `career missing for ${aUserId}`);
  assert(careerB, `career missing for ${bUserId}`);
  const rng = createRng(`ranked:${state.season.number}:${now}:${aUserId}:${bUserId}`);
  const aHome = rng.int(0, 1) === 0;
  const id = newId('rkf');
  const fx = {
    id,
    season: state.season.number,
    aUserId,
    bUserId,
    homeUserId: aHome ? aUserId : bUserId,
    awayUserId: aHome ? bUserId : aUserId,
    status: 'preparing',
    createdAt: now,
    preparationDeadline: now + PREPARATION_WINDOW_MS,
    matchSeed: `ranked:${state.season.number}:${id}`,
    clubNames: {},
    pool: {},
    careerConfig: {},
    fallback: {},
    sealed: { [aUserId]: null, [bUserId]: null },
    sealedAt: { [aUserId]: null, [bUserId]: null },
    result: null,
    completedVia: null,
    // legacy-compat fields (kept for history/dashboard shapes)
    homeScore: null,
    awayScore: null,
    playedBy: null,
    playedAt: null,
    ratingBefore: null,
    ratingAfter: null,
  };
  for (const [uid, career] of [[aUserId, careerA], [bUserId, careerB]]) {
    const entry = career.clubs[career.playerClubId];
    assert(entry, `club entry missing for ${uid}`);
    const players = (entry.squad.players ?? [])
      .map((pid) => career.players[pid])
      .filter(Boolean)
      .map(snapshotPoolPlayer);
    assert(players.length >= 11, `not enough players in squad for ${uid}`);
    fx.clubNames[uid] = entry.club.name;
    fx.pool[uid] = players;
    const cc = snapshotCareerConfig(career);
    fx.careerConfig[uid] = cc;
    fx.fallback[uid] = buildFallbackConfig(players, state.rankedConfigs?.[uid], cc, now);
  }
  state.fixtures.push(fx);
  return fx;
}

// ---------------------------------------------------------------------------
// Sealing
// ---------------------------------------------------------------------------

/** Server-authoritative condition read at seal time. Never trusts the client. */
function readCondition(career, pool, ids) {
  const byId = poolById(pool);
  const out = {};
  for (const id of ids) {
    const p = career.players?.[id];
    if (p) {
      out[id] = {
        fitness: Math.max(0, Math.min(100, Math.round(p.fitness ?? 100))),
        injury: !!p.injury,
      };
    } else {
      // Sold/transferred after matchmaking: frozen pool values stand.
      const sp = byId.get(id);
      out[id] = sp ? { fitness: sp.fitness, injury: sp.injury } : { fitness: 100, injury: false };
    }
  }
  return out;
}

function configSignature(c) {
  // Sort instruction keys so semantically identical configs match regardless
  // of object key order.
  const instr = c.playerInstructions ?? {};
  const sortedInstr = Object.fromEntries(
    Object.keys(instr).sort().map((k) => [k, instr[k]]));
  return JSON.stringify({
    lineupIds: c.lineupIds,
    benchIds: c.benchIds,
    formation: c.formation,
    tactics: c.tactics,
    plan: c.plan,
    playerInstructions: sortedInstr,
  });
}

function findFixture(state, fixtureId) {
  return state.fixtures.find((f) => f.id === fixtureId) ?? null;
}

/**
 * Seal a manager's tactical configuration. Atomic + idempotent-safe:
 * - identical repeat seal → { alreadySealed: true }
 * - different config after sealing → rejected
 * Triggers the canonical simulation immediately when both sides are sealed.
 */
export function sealFixture(state, fixtureId, userId, input, getCareer, now = Date.now()) {
  const fx = findFixture(state, fixtureId);
  assert(fx, 'fixture not found');
  assert(fx.aUserId === userId || fx.bUserId === userId, 'not your fixture');
  assert(fx.status === 'preparing', `fixture is not in preparation (status: ${fx.status})`);
  if (now >= fx.preparationDeadline) {
    ensureSettled(state, fixtureId, { getCareer, now });
    const e = new Error('preparation deadline has passed — fallback configuration used');
    e.code = 'DEADLINE_PASSED';
    throw e;
  }
  const pool = fx.pool[userId];
  assert(pool && pool.length, 'no fixture pool for this manager');
  const existing = fx.sealed[userId];
  const normalized = validateSealInput(input, pool);
  const career = getCareer(userId);
  assert(career, 'your career is missing');
  normalized.condition = readCondition(career, pool, [...normalized.lineupIds, ...normalized.benchIds]);
  normalized.source = 'sealed';
  normalized.createdAt = now;
  if (existing) {
    if (configSignature(existing) === configSignature(normalized)) {
      return { fixture: fx, alreadySealed: true, simulated: false };
    }
    const e = new Error('tactical configuration is already sealed and cannot be changed');
    e.code = 'ALREADY_SEALED';
    throw e;
  }
  fx.sealed[userId] = deepCopy(normalized);
  fx.sealedAt[userId] = now;
  // Remember as this manager's previous ranked config (condition stripped:
  // condition is always re-read per fixture).
  const { condition: _c, ...noCond } = normalized;
  if (!state.rankedConfigs) state.rankedConfigs = {};
  state.rankedConfigs[userId] = deepCopy(noCond);

  let simulated = false;
  if (fx.sealed[fx.aUserId] && fx.sealed[fx.bUserId]) {
    settleFixture(state, fx, 'both_sealed', { getCareer, now });
    simulated = true;
  }
  return { fixture: fx, alreadySealed: false, simulated };
}

// ---------------------------------------------------------------------------
// Canonical simulation
// ---------------------------------------------------------------------------

function effectiveConfig(fx, userId) {
  return fx.sealed[userId] ?? fx.fallback[userId];
}

function buildBundle(pool, config, clubName) {
  const byId = poolById(pool);
  const mk = (id) => {
    const base = byId.get(id);
    if (!base) throw new Error(`configuration references player outside the fixture pool: ${id}`);
    const p = deepCopy(base);
    const c = config.condition?.[id];
    if (c) {
      p.fitness = Math.max(0, Math.min(100, Math.round(c.fitness)));
      p.injury = !!c.injury;
    }
    return p;
  };
  const players = config.lineupIds.map(mk);
  const bench = config.benchIds.map(mk);
  const tactics = createTactics();
  setFormation(tactics, config.formation);
  for (const key of [...ORDER_KEYS, ...FLAG_KEYS]) {
    if (config.tactics[key] !== undefined) setTactic(tactics, key, config.tactics[key]);
  }
  // Phase 39c: sealed player instructions become part of the canonical engine
  // input, using the exact same 39a semantics as everywhere else. Missing or
  // legacy configs default to no instructions.
  for (const [pid, arrow] of Object.entries(config.playerInstructions ?? {})) {
    try { setPlayerInstruction(tactics, pid, arrow); } catch { /* validated at seal; ignore */ }
  }
  return { name: clubName, players, bench, tactics };
}

function scoreStateFor(m, side) {
  const gf = side === 'home' ? m.scoreH : m.scoreA;
  const ga = side === 'home' ? m.scoreA : m.scoreH;
  if (gf > ga) return 'winning';
  if (gf < ga) return ga - gf >= 2 ? 'losing_by_2' : 'losing';
  return 'drawing';
}

function applyPlanSub(m, side, team, sub) {
  const outP = team.players.find((p) => p.id === sub.out);
  const inP = team.bench.find((p) => p.id === sub.in);
  if (!outP || !inP) return false; // player left the pitch already (red card/injury) — skip safely
  if (inP.injury || !(inP.fitness > 0)) return false;
  team.players = team.players.map((p) => (p.id === outP.id ? inP : p));
  team.bench = team.bench.filter((p) => p.id !== inP.id);
  if (!m.ratings.has(inP.id)) {
    m.ratings.set(inP.id, { rating: 6.5, goals: 0, assists: 0, player: inP });
    m.minutes.set(inP.id, 0);
  }
  m.events.push({
    minute: m.minute,
    type: 'sub',
    team: side,
    playerId: inP.id,
    playerName: inP.name,
    detail: `${inP.name} replaces ${outP.name} (tactical plan)`,
  });
  return true;
}

function applyPlanAction(m, side, team, then, subsUsed) {
  if (then.mentality !== undefined) setTactic(team.tactics, 'mentality', then.mentality);
  if (then.pressing !== undefined) setTactic(team.tactics, 'pressing', then.pressing);
  if (then.tempo !== undefined) setTactic(team.tactics, 'tempo', then.tempo);
  if (then.sub !== undefined) {
    if (subsUsed[side] < PLAN_SUB_LIMIT && applyPlanSub(m, side, team, then.sub)) {
      subsUsed[side] += 1;
    }
  }
  recalcTeamEff(team);
}

/**
 * Run the ONE canonical simulation for a fixture using the existing match
 * engine pipeline (no second engine). Minute-by-minute segments are
 * RNG-identical to the historical full-run when plans are empty; plan
 * evaluation itself consumes no RNG, so the run is fully deterministic for
 * fixed inputs (seed + snapshot + sealed/fallback configs + conditions).
 */
export function runCanonicalSimulation(fx) {
  const homeCfg = effectiveConfig(fx, fx.homeUserId);
  const awayCfg = effectiveConfig(fx, fx.awayUserId);
  assert(homeCfg && awayCfg, 'both sides need a configuration before simulation');
  const home = buildBundle(fx.pool[fx.homeUserId], homeCfg, fx.clubNames[fx.homeUserId]);
  const away = buildBundle(fx.pool[fx.awayUserId], awayCfg, fx.clubNames[fx.awayUserId]);
  const m = createMatch({ home, away, seed: fx.matchSeed, knockout: false });
  emitKickoff(m);
  const fired = new Set();
  const subsUsed = { home: 0, away: 0 };
  for (let min = 1; min <= 90; min++) {
    playMatchSegment(m, min, min);
    if (min === 45) applyHalftimeBreak(m);
    for (const side of ['home', 'away']) {
      const team = side === 'home' ? m.H : m.A;
      const cfg = side === 'home' ? homeCfg : awayCfg;
      const plan = cfg.plan ?? [];
      for (let i = 0; i < plan.length; i++) {
        const key = `${side}:${i}`;
        if (fired.has(key)) continue;
        const rule = plan[i];
        if (rule.if.minuteGte > min) continue;
        if (scoreStateFor(m, side) !== rule.if.scoreState) continue;
        fired.add(key);
        applyPlanAction(m, side, team, rule.then, subsUsed);
      }
    }
  }
  m.winner = m.scoreH === m.scoreA ? 'draw' : m.scoreH > m.scoreA ? 'home' : 'away';
  emitFulltime(m);
  return finalizeMatch(m);
}

// ---------------------------------------------------------------------------
// Settlement / finalization
// ---------------------------------------------------------------------------

/**
 * Atomically settle a fixture: exactly one canonical simulation, Elo applied
 * exactly once, result persisted. Safe to retry: completed fixtures return
 * { alreadyCompleted: true } without side effects.
 */
export function settleFixture(state, fx, via, { getCareer = null, now = Date.now() } = {}) {
  if (fx.status === 'completed') return { fixture: fx, alreadyCompleted: true, result: fx.result };
  assert(fx.status === 'preparing', `cannot settle fixture with status ${fx.status}`);
  fx.status = 'simulating'; // single-threaded atomic transition
  const sim = runCanonicalSimulation(fx);
  fx.result = {
    score: sim.score,
    winner: sim.winner,
    events: sim.events,
    stats: sim.stats,
    playerRatings: sim.playerRatings,
    seed: sim.seed,
  };
  fx.homeScore = sim.score.home;
  fx.awayScore = sim.score.away;
  fx.playedAt = now;
  fx.completedVia = via;
  // Elo — exactly once, inside the atomic settle.
  const ea = getEntry(state, fx.aUserId);
  const eb = getEntry(state, fx.bUserId);
  const beforeA = ea.rating;
  const beforeB = eb.rating;
  const aIsHome = fx.homeUserId === fx.aUserId;
  const aGoals = aIsHome ? sim.score.home : sim.score.away;
  const bGoals = aIsHome ? sim.score.away : sim.score.home;
  const scoreA = aGoals > bGoals ? 1 : aGoals < bGoals ? 0 : 0.5;
  const [newA, newB] = updateRatings(beforeA, beforeB, scoreA);
  ea.rating = newA;
  eb.rating = newB;
  if (scoreA === 1) { ea.w++; eb.l++; }
  else if (scoreA === 0) { ea.l++; eb.w++; }
  else { ea.d++; eb.d++; }
  fx.ratingBefore = { [fx.aUserId]: beforeA, [fx.bUserId]: beforeB };
  fx.ratingAfter = { [fx.aUserId]: newA, [fx.bUserId]: newB };
  rememberOpponents(state, fx.aUserId, fx.bUserId);
  fx.status = 'completed';
  return { fixture: fx, alreadyCompleted: false, result: fx.result };
}

/**
 * Lazy deadline handling: if the preparation window has passed and the
 * fixture is still preparing, missing sides fall back to their precomputed
 * immutable fallback configurations and the fixture settles. Server time only.
 */
export function ensureSettled(state, fixtureId, { getCareer = null, now = Date.now() } = {}) {
  const fx = findFixture(state, fixtureId);
  if (!fx || fx.status !== 'preparing') return { fixture: fx, settled: false };
  if (now < fx.preparationDeadline) return { fixture: fx, settled: false };
  const out = settleFixture(state, fx, 'deadline', { getCareer, now });
  return { fixture: fx, settled: !out.alreadyCompleted, result: out.result };
}

/** Settle every overdue preparing fixture (called from ranked read paths). */
export function settleOverdue(state, { getCareer = null, now = Date.now() } = {}) {
  const settled = [];
  for (const fx of state.fixtures) {
    if (fx.status === 'preparing' && fx.preparationDeadline && now >= fx.preparationDeadline) {
      const out = settleFixture(state, fx, 'deadline', { getCareer, now });
      if (!out.alreadyCompleted) settled.push(fx);
    }
  }
  return settled;
}

// ---------------------------------------------------------------------------
// Migration
// ---------------------------------------------------------------------------

/**
 * Migrate a legacy fixture (old 'pending' shape without a frozen pool) to the
 * sealed model. Old 'played' fixtures are history and stay untouched.
 * Returns true when migrated.
 */
export function migrateLegacyFixture(state, fx, getCareer, now = Date.now()) {
  if (!fx || fx.pool) return false;
  if (fx.status !== 'pending') return false;
  const careerA = getCareer(fx.aUserId);
  const careerB = getCareer(fx.bUserId);
  if (!careerA || !careerB) return false;
  const built = createSealedFixture(state, fx.aUserId, fx.bUserId, getCareer, now);
  // Preserve identity + season of the legacy fixture.
  built.id = fx.id;
  built.season = fx.season;
  built.matchSeed = `ranked:${fx.season}:${fx.id}`;
  // Replace the legacy entry in place.
  const i = state.fixtures.indexOf(fx);
  state.fixtures[i] = built;
  return true;
}

/** Migrate all legacy pending fixtures (safe to call repeatedly). */
export function migrateLegacyFixtures(state, getCareer, now = Date.now()) {
  let n = 0;
  for (const fx of [...state.fixtures]) {
    if (migrateLegacyFixture(state, fx, getCareer, now)) n++;
  }
  return n;
}

// ---------------------------------------------------------------------------
// Public view
// ---------------------------------------------------------------------------

/**
 * Public fixture view for one manager. Never reveals the opponent's sealed
 * configuration, fallback, pool, or condition — only their seal status.
 */
export function fixtureView(fx, userId) {
  if (!fx) return null;
  const oppId = fx.aUserId === userId ? fx.bUserId : fx.aUserId;
  const mySealed = !!(fx.sealed && fx.sealed[userId]);
  const oppSealed = !!(fx.sealed && fx.sealed[oppId]);
  const now = Date.now();
  return {
    id: fx.id,
    season: fx.season,
    status: fx.status,
    isHome: fx.homeUserId === userId,
    clubName: fx.clubNames?.[userId] ?? null,
    oppClubName: fx.clubNames?.[oppId] ?? null,
    createdAt: fx.createdAt,
    preparationDeadline: fx.preparationDeadline,
    timeRemainingMs: fx.preparationDeadline ? Math.max(0, fx.preparationDeadline - now) : 0,
    mySealed,
    oppSealed,
    willUseFallback: !mySealed && fx.status === 'preparing',
    // Own pool for the preparation UI (engine-relevant fields only).
    myPool: (fx.pool?.[userId] ?? []).map((p) => ({
      id: p.id,
      name: p.name,
      position: p.position,
      fitness: p.fitness,
      injury: p.injury,
    })),
    // Own effective config (sealed, else the fallback that would be used).
    myConfig: (() => {
      const c = fx.sealed?.[userId] ?? fx.fallback?.[userId];
      if (!c) return null;
      const { condition: _cond, ...rest } = c;
      return rest;
    })(),
    result: fx.result,
    // Phase 50: deterministic report projection of the canonical result.
    // No configured tactics passed — Ranked reports are observed-behavior
    // only, never sealed configuration (privacy).
    report: fx.result ? buildMatchReport(fx.result) : null,
    completedVia: fx.completedVia ?? null,
    homeScore: fx.homeScore,
    awayScore: fx.awayScore,
    playedAt: fx.playedAt,
    myRatingBefore: fx.ratingBefore?.[userId] ?? null,
    myRatingAfter: fx.ratingAfter?.[userId] ?? null,
  };
}
