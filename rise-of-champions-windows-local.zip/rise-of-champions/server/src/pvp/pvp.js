// PvP friendlies: challenge another manager's club. The opponent's XI
// and tactics are snapshotted at challenge time and simulated on deep
// copies, so their real squad is untouched while away. The challenger's
// real players take match load (that's the cost of playing).
import { createRng } from '../core/rng.js';
import { newId } from '../core/ids.js';
import { simulateMatch } from '../match/engine.js';
import { careerTeamBundle, notify } from '../career/career.js';
import { recordTransaction } from '../finance/finance.js';

const WINNER_PRIZE = 25000;
const DRAW_PRIZE = 10000;
// Anti-abuse: friendlies award cash, so cap them per day to prevent
// two-account prize farming. Day boundary is server-local midnight.
export const DAILY_FRIENDLY_LIMIT = 5;

export function friendliesPlayedToday(history) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  return (history ?? []).filter((r) => r.at >= start.getTime()).length;
}

function copyPlayers(players) {
  return JSON.parse(JSON.stringify(players));
}

/**
 * Play a friendly: challengerCareer (real, mutated) vs opponentCareer
 * (snapshotted, untouched). Returns the match result + pvp record.
 */
export function playFriendly({ challenger, opponent, seed = null }) {
  if (challenger.id === opponent.id) throw new Error('cannot challenge yourself');
  if (friendliesPlayedToday(challenger.pvpHistory) >= DAILY_FRIENDLY_LIMIT) {
    throw new Error(`daily friendly limit reached (${DAILY_FRIENDLY_LIMIT}/day)`);
  }
  const rng = createRng(seed ?? `pvp:${challenger.id}:${opponent.id}:${Date.now()}`);

  const home = careerTeamBundle(challenger, challenger.playerClubId);
  const awayReal = careerTeamBundle(opponent, opponent.playerClubId);
  const away = {
    name: awayReal.name,
    players: copyPlayers(awayReal.players),
    bench: copyPlayers(awayReal.bench),
    tactics: JSON.parse(JSON.stringify(awayReal.tactics)),
  };

  const result = simulateMatch({
    home,
    away,
    seed: `pvp:${challenger.seed}:${opponent.seed}:${rng.int(0, 1e9)}`,
  });

  const chalClub = challenger.clubs[challenger.playerClubId].club;
  const oppClub = opponent.clubs[opponent.playerClubId].club;
  const outcome = result.winner === 'home' ? 'win' : result.winner === 'away' ? 'loss' : 'draw';

  // Prizes for the challenger (opponent gets notified, no squad damage).
  const prize = outcome === 'win' ? WINNER_PRIZE : outcome === 'draw' ? DRAW_PRIZE : 0;
  if (prize > 0) {
    recordTransaction(chalClub, { type: 'pvp_prize', amount: prize, description: `Friendly vs ${oppClub.name} (${outcome})` });
  }

  const record = {
    id: newId('pvp'),
    opponentClub: oppClub.name,
    score: `${result.score.home}-${result.score.away}`,
    outcome,
    prize,
    at: Date.now(),
  };
  challenger.pvpHistory = [record, ...(challenger.pvpHistory ?? [])].slice(0, 30);
  const oppRecord = { ...record, id: newId('pvp'), opponentClub: chalClub.name, outcome: outcome === 'win' ? 'loss' : outcome === 'loss' ? 'win' : 'draw', prize: 0 };
  opponent.pvpHistory = [oppRecord, ...(opponent.pvpHistory ?? [])].slice(0, 30);

  notify(challenger, `Friendly vs ${oppClub.name}: ${record.score} (${outcome}).`);
  notify(opponent, `${chalClub.name} challenged you to a friendly: ${record.score}.`);

  return { result, record };
}

/** Leaderboard entries from loaded careers: { username, clubName, points, season }. */
export function buildLeaderboard(careers, getUsername) {
  const rows = [];
  for (const career of careers.values()) {
    const entry = career.clubs[career.playerClubId];
    if (!entry) continue;
    const table = Object.values(career.league.table);
    const row = table.find((r) => r.clubId === career.playerClubId);
    rows.push({
      username: getUsername(career.userId),
      clubName: entry.club.name,
      points: row ? row.points : 0,
      season: career.season,
    });
  }
  return rows.sort((a, b) => b.points - a.points);
}
