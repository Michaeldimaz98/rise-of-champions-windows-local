// Training drills catalog (data-driven from config/training.json).
import { loadConfig } from '../core/config.js';
import { assert } from '../core/validate.js';

let defs = null;
function getDefs() {
  if (!defs) defs = loadConfig('training');
  return defs;
}

export function getCategories() {
  return [...getDefs().categories];
}

/** All drills, or filtered by category. */
export function getDrills(category = null) {
  const drills = getDefs().drills;
  if (!category) return drills.map((d) => ({ ...d }));
  return drills.filter((d) => d.category === category).map((d) => ({ ...d }));
}

export function getDrill(id) {
  const drill = getDefs().drills.find((d) => d.id === id);
  assert(drill, `unknown drill: ${id}`);
  return { ...drill };
}
