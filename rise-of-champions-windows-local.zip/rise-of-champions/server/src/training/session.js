// Training sessions: run a drill for a group of players.
// Each player gains XP (scaled by intensity, facility level, coach),
// loses fitness, and risks injury (worse when already tired).
import { loadConfig } from '../core/config.js';
import { gainXp, applyInjury } from '../players/index.js';
import { getTrainingModifiers } from '../staff/effects.js';

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function trainingDefs() {
  return loadConfig('training');
}

export function getDrillOrThrow(id) {
  const drill = trainingDefs().drills.find((d) => d.id === id);
  if (!drill) throw new Error(`unknown drill: ${id}`);
  return drill;
}

/**
 * Run one session. params:
 *   players: player objects (mutated)
 *   drillId, facilityLevel (1-5), coachBonus (default 1), rng (required)
 *   staff: staff roster from the staff module (optional; default none)
 * Returns per-player results:
 *   { playerId, xpGained, pointsApplied, fitnessLost, injury }
 */
export function runTrainingSession({ players, drillId, facilityLevel = 1, coachBonus = 1.0, xpBonus = 1.0, rng, staff = null }) {
  if (!rng) throw new Error('runTrainingSession requires rng');
  const defs = trainingDefs();
  const drill = getDrillOrThrow(drillId);
  const facilityMult = 1 + defs.facilityXpBonus * (facilityLevel - 1);
  const mods = staff
    ? getTrainingModifiers(staff, drill.category)
    : { xpMult: 1, fitnessCostMult: 1, injuryRiskMult: 1 };

  return players.map((player) => {
    const xp = drill.xp * drill.intensity * facilityMult * coachBonus * mods.xpMult * xpBonus;
    const pointsApplied = gainXp(player, xp, {
      rng,
      weights: drill.targets,
    });

    const fitnessLost = Math.round(drill.fitnessCost * drill.intensity * mods.fitnessCostMult);
    player.fitness = clamp(player.fitness - fitnessLost, 0, 100);

    // Tired players get injured more easily.
    const fatigue = 1 + (100 - player.fitness) / 100;
    const pInjury = drill.injuryRisk * drill.intensity * fatigue * mods.injuryRiskMult;
    let injury = null;
    if (rng.chance(pInjury)) {
      injury = {
        type: rng.pick(defs.injuryTypes),
        days: rng.int(1, 7),
      };
      applyInjury(player, injury.type, injury.days);
    }

    return {
      playerId: player.id,
      xpGained: Math.round(xp),
      pointsApplied,
      fitnessLost,
      injury,
    };
  });
}
