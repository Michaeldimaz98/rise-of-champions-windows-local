// Composition root. Wires modules together and exposes the app context.
// Game modules receive what they need here — they never import each other
// behind the back of this file (dependency inversion).
import { loadConfig } from './core/config.js';
import { createRng } from './core/rng.js';
import { createEventBus } from './core/eventBus.js';

export function createApp(overrides = {}) {
  const config = overrides.config ?? loadConfig('core');
  const events = overrides.events ?? createEventBus();

  return {
    config,
    events,
    /** Deterministic RNG factory. seed = hash(matchId, seasonId, matchday). */
    createRng: (seed) => createRng(seed),
  };
}
