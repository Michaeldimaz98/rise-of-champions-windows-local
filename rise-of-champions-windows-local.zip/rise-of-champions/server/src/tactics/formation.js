// Formations: 8 built-in templates + extensible custom registration.
// Slots carry pitch coordinates (x: 0=left..100=right, y: 0=own goal..100=opp)
// for validation and later 2D visualization.
import { loadConfig } from '../core/config.js';
import { assert } from '../core/validate.js';

const DEFENDERS = new Set(['DL', 'DC', 'DR']);
const MIDFIELD = new Set(['DMC', 'MC', 'ML', 'MR', 'AMC', 'AML', 'AMR']);
const LEFT_FLANK = new Set(['DL', 'ML', 'AML']);
const RIGHT_FLANK = new Set(['DR', 'MR', 'AMR']);

const custom = new Map();

function builtins() {
  return loadConfig('tactics').formations;
}

export function getFormationNames() {
  return [...Object.keys(builtins()), ...custom.keys()];
}

/** Returns a deep copy of the formation slots (safe to mutate). */
export function getFormation(name) {
  const f = builtins()[name] ?? custom.get(name);
  assert(f, `unknown formation: ${name}`);
  return f.map((s) => ({ ...s }));
}

/** Register a custom formation (extensible without touching the engine). */
export function addFormation(name, slots) {
  assert(typeof name === 'string' && name.trim().length > 0, 'formation needs a name');
  const check = validateFormation(slots);
  assert(check.legal, `illegal formation "${name}": ${check.violations.join('; ')}`);
  custom.set(name, slots.map((s) => ({ ...s })));
  return name;
}

/**
 * Validate a formation against the classic rules. Illegal formations are
 * still usable but the match engine penalizes them (possession cap).
 * Returns { legal, violations[] }.
 */
export function validateFormation(slots) {
  const violations = [];
  if (!Array.isArray(slots) || slots.length !== 11) {
    violations.push(`formation must have 11 slots, got ${slots?.length ?? 0}`);
    return { legal: false, violations };
  }
  const positions = slots.map((s) => s.position);
  if (!positions.includes('GK')) violations.push('missing goalkeeper');
  const defs = positions.filter((p) => DEFENDERS.has(p)).length;
  if (defs < 3) violations.push(`need at least 3 defenders, got ${defs}`);
  if (!positions.includes('ST')) violations.push('need at least 1 striker');
  if (!positions.some((p) => LEFT_FLANK.has(p))) violations.push('need a left-flank player');
  if (!positions.some((p) => RIGHT_FLANK.has(p))) violations.push('need a right-flank player');
  const mids = positions.filter((p) => MIDFIELD.has(p)).length;
  if (mids < 3) violations.push(`need at least 3 midfielders, got ${mids}`);
  const attacking = slots.filter((s) => s.y > 50).length;
  if (attacking < 4) violations.push(`need at least 4 players in opponent half, got ${attacking}`);
  return { legal: violations.length === 0, violations };
}
