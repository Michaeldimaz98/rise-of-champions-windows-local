// Team tactics: formation + orders + per-player arrows.
// All option lists come from config/tactics.json (data-driven).
import { loadConfig } from '../core/config.js';
import { assert, isOneOf } from '../core/validate.js';
import { getFormation } from './formation.js';

const ORDER_KEYS = [
  'mentality',
  'passing',
  'tempo',
  'pressing',
  'defensiveLine',
  'width',
  'tackling',
  'buildUp',
];
const FLAG_KEYS = ['counterAttack', 'offsideTrap', 'timeWasting'];

function defs() {
  return loadConfig('tactics');
}

export function createTactics(overrides = {}) {
  const d = defs();
  const tactics = {
    formation: '4-4-2',
    playerInstructions: {}, // playerId -> 'red' | 'blue'
  };
  for (const key of ORDER_KEYS) tactics[key] = d.defaults[key];
  for (const key of FLAG_KEYS) tactics[key] = d.defaults[key];
  if (overrides.formation) setFormation(tactics, overrides.formation);
  for (const key of [...ORDER_KEYS, ...FLAG_KEYS]) {
    if (overrides[key] !== undefined) setTactic(tactics, key, overrides[key]);
  }
  // Phase 39a: preserve/accept player instructions instead of silently wiping
  // them. Each entry is validated through setPlayerInstruction.
  if (overrides.playerInstructions && typeof overrides.playerInstructions === 'object') {
    for (const [pid, arrow] of Object.entries(overrides.playerInstructions)) {
      setPlayerInstruction(tactics, pid, arrow);
    }
  }
  return tactics;
}

export function setFormation(tactics, name) {
  getFormation(name); // throws on unknown
  tactics.formation = name;
  return tactics;
}

export function setTactic(tactics, key, value) {
  const d = defs();
  if (ORDER_KEYS.includes(key)) {
    assert(
      isOneOf(value, d[key]),
      `invalid ${key}: ${value}. Valid: ${d[key].join(', ')}`
    );
  } else if (FLAG_KEYS.includes(key)) {
    assert(typeof value === 'boolean', `${key} must be boolean`);
  } else {
    throw new Error(`unknown tactic key: ${key}`);
  }
  tactics[key] = value;
  return tactics;
}

/**
 * Per-player arrow: 'red' = attacking instruction, 'blue' = defensive.
 * Pass null to clear.
 */
export function setPlayerInstruction(tactics, playerId, arrow) {
  const d = defs();
  if (arrow == null) {
    delete tactics.playerInstructions[playerId];
    return tactics;
  }
  assert(
    isOneOf(arrow, d.playerArrows),
    `invalid arrow: ${arrow}. Valid: ${d.playerArrows.join(', ')}`
  );
  tactics.playerInstructions[playerId] = arrow;
  return tactics;
}

export { ORDER_KEYS, FLAG_KEYS };
