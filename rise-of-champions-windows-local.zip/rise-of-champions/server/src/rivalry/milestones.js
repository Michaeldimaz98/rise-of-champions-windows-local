// Rivalry milestones — data-driven, server-calculated, idempotent, restart-safe.
// Rewards are paid by the caller through the existing ledger + manager XP.
// Phase 35.
import { ensureRivalry } from './matches.js';

/** Evaluate one milestone def against one rivalry summary. */
export function rivalryMilestoneMet(def, r) {
  switch (def.id) {
    case 'r_first_meeting': return r.meetings >= 1;
    case 'r_first_win': return r.wins >= 1;
    case 'r_three_wins': return r.wins >= 3;
    case 'r_five_meetings': return r.meetings >= 5;
    case 'r_ten_goals': return r.goalsFor >= 10;
    case 'r_heated': return ['heated', 'fierce', 'historic'].includes(r.tier.id);
    default: return false;
  }
}

function unlockKey(def, r) {
  return def.scope === 'global' ? def.id : `${def.id}:${r.key}`;
}

/**
 * Check all rivalry milestones against derived rivalries.
 * Returns newly unlocked [{ def, key, rivalName }]. Idempotent via the unlock map.
 */
export function checkRivalryMilestones(career, cfg, rivalries) {
  const leg = ensureRivalry(career);
  const defs = cfg.rivalry?.milestones ?? [];
  const unlocked = [];
  for (const def of defs) {
    if (def.scope === 'global') {
      if (leg.rivalryMilestones[def.id]) continue;
      const hit = rivalries.find((r) => rivalryMilestoneMet(def, r));
      if (hit) {
        leg.rivalryMilestones[def.id] = Date.now();
        unlocked.push({ def, key: null, rivalName: hit.opponentName });
      }
    } else {
      for (const r of rivalries) {
        const k = unlockKey(def, r);
        if (leg.rivalryMilestones[k]) continue;
        if (rivalryMilestoneMet(def, r)) {
          leg.rivalryMilestones[k] = Date.now();
          unlocked.push({ def, key: r.key, rivalName: r.opponentName });
        }
      }
    }
  }
  return unlocked;
}

/** Milestone list with unlock state for the client (public-safe shape). */
export function rivalryMilestoneProgress(career, cfg) {
  const leg = ensureRivalry(career);
  return (cfg.rivalry?.milestones ?? []).map((def) => {
    const keys = Object.keys(leg.rivalryMilestones).filter((k) => k === def.id || k.startsWith(def.id + ':'));
    return {
      id: def.id,
      title: def.title,
      desc: def.desc,
      cash: def.cash,
      xp: def.xp,
      unlockedCount: keys.length,
    };
  });
}
