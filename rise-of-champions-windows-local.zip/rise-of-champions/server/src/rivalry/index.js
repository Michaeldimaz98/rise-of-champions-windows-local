// Orchestration: process one verified match into rivalry updates.
// Writes the match log, derives the rivalry, detects tier-ups, writes activity,
// checks milestones. Reward payment stays with the caller (needs ledger + XP).
// Phase 35.
export * from './matches.js';
export * from './rivalry.js';
export * from './milestones.js';
import { recordRivalryMatch, pushActivity, ensureRivalry } from './matches.js';
import { rivalriesFromMatches, rivalryFor } from './rivalry.js';
import { checkRivalryMilestones } from './milestones.js';

/**
 * Process a verified eligible match for a career.
 * Returns { rivalry, tierUp, newMilestones, activity }.
 */
export function processRivalryMatch(career, cfg, match) {
  ensureRivalry(career);
  const before = rivalryFor(career, cfg, match.opponentKey);
  const beforeTier = before?.tier.id ?? null;

  recordRivalryMatch(career, cfg, match);
  const rivalry = rivalryFor(career, cfg, match.opponentKey);
  const tierUp = beforeTier && rivalry.tier.id !== beforeTier;

  const my = match.gf > match.ga ? 'won' : match.gf < match.ga ? 'lost to' : 'drew with';
  pushActivity(career, cfg, {
    kind: 'match',
    key: rivalry.key,
    text: `Your club ${my} ${rivalry.opponentName} ${match.gf}–${match.ga}.`,
  });
  if (tierUp) {
    pushActivity(career, cfg, {
      kind: 'tier',
      key: rivalry.key,
      text: `Rivalry with ${rivalry.opponentName} reached ${rivalry.tier.label}!`,
    });
  }

  const rivalries = rivalriesFromMatches(career, cfg);
  const newMilestones = checkRivalryMilestones(career, cfg, rivalries);
  for (const { def, key, rivalName } of newMilestones) {
    pushActivity(career, cfg, {
      kind: 'milestone',
      key: key,
      text: `Rivalry milestone: ${def.title}${rivalName ? ` (${rivalName})` : ''}.`,
    });
  }

  return { rivalry, tierUp: !!tierUp, newMilestones, rivalries };
}
