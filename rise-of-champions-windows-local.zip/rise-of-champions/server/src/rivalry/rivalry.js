// Rivalry derivation: H2H, intensity, tiers — pure functions over the verified
// match log. Nothing here is stored or client-submittable.
// Phase 35.
import { ensureRivalry } from './matches.js';

/** Group a career's matches by opponent into rivalry records. */
export function rivalriesFromMatches(career, cfg) {
  ensureRivalry(career);
  const byKey = new Map();
  for (const m of career.legacy.matches) {
    if (!byKey.has(m.opponentKey)) byKey.set(m.opponentKey, []);
    byKey.get(m.opponentKey).push(m);
  }
  const out = [];
  for (const [key, list] of byKey) {
    list.sort((a, b) => a.at - b.at);
    out.push(summarizeRivalry(key, list, cfg));
  }
  out.sort((a, b) => b.intensity - a.intensity || b.meetings - a.meetings);
  return out;
}

export function rivalryFor(career, cfg, opponentKey) {
  return rivalriesFromMatches(career, cfg).find((r) => r.key === opponentKey) ?? null;
}

function summarizeRivalry(key, list, cfg) {
  let wins = 0, draws = 0, losses = 0, goalsFor = 0, goalsAgainst = 0;
  let curStreak = 0; // my current unbeaten run vs this rival (W/D count, L resets)
  let bestWinStreak = 0, curWinStreak = 0;
  for (const m of list) {
    goalsFor += m.gf;
    goalsAgainst += m.ga;
    if (m.gf > m.ga) {
      wins += 1;
      curStreak += 1;
      curWinStreak += 1;
      bestWinStreak = Math.max(bestWinStreak, curWinStreak);
    } else if (m.gf === m.ga) {
      draws += 1;
      curStreak += 1;
      curWinStreak = 0;
    } else {
      losses += 1;
      curStreak = 0;
      curWinStreak = 0;
    }
  }
  const last = list[list.length - 1];
  const intensity = computeIntensity(list, cfg.rivalry?.intensity ?? {}, bestWinStreak);
  return {
    key,
    opponentKey: key,
    opponentName: last.opponentName,
    opponentUserId: last.opponentUserId ?? null,
    meetings: list.length,
    wins,
    draws,
    losses,
    goalsFor,
    goalsAgainst,
    last5: list.slice(-5).reverse().map((m) => ({
      at: m.at, competition: m.competition, gf: m.gf, ga: m.ga,
      result: m.gf > m.ga ? 'W' : m.gf < m.ga ? 'L' : 'D',
    })),
    lastMeetingAt: last.at,
    lastResult: last.gf > last.ga ? 'W' : last.gf < last.ga ? 'L' : 'D',
    lastScore: `${last.gf}–${last.ga}`,
    streak: curStreak, // current unbeaten run
    bestWinStreak,
    intensity,
    tier: tierForIntensity(intensity, cfg.rivalry?.tiers ?? []),
  };
}

/**
 * Deterministic, bounded intensity from verified history.
 * Not a gameplay modifier — presentation/progression metadata only.
 */
export function computeIntensity(list, icfg, bestWinStreak = 0) {
  const perMeeting = icfg.perMeeting ?? 5;
  const closeBonus = icfg.closeResultBonus ?? 4;
  const winStreakBonus = icfg.winStreakBonus ?? 3;
  const maxWinStreakBonus = icfg.maxWinStreakBonus ?? 15;
  const decisiveBonus = icfg.decisiveWinBonus ?? 2;
  let score = list.length * perMeeting;
  for (const m of list) {
    const margin = Math.abs(m.gf - m.ga);
    if (margin <= 1) score += closeBonus; // draw or one-goal game
    if (margin >= 3) score += decisiveBonus; // statement win
  }
  score += Math.min(bestWinStreak * winStreakBonus, maxWinStreakBonus);
  return score;
}

export function tierForIntensity(intensity, tiers) {
  const list = Array.isArray(tiers) && tiers.length ? tiers : [{ id: 'new', minIntensity: 0, label: 'New' }];
  let cur = list[0];
  for (const t of list) {
    if (intensity >= (t.minIntensity ?? 0)) cur = t;
  }
  return { id: cur.id, label: cur.label ?? cur.id };
}
