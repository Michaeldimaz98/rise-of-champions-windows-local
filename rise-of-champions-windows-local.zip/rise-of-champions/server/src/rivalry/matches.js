// Rivalry match log — append-only record of verified competitive results.
// Only the server writes here, only for eligible competitions (config).
// Bounded; derivation (H2H, intensity) is computed on demand — no duplicate counters.
// Phase 35.
import { assert } from '../core/validate.js';

/** Field-by-field backfill for old saves (never clobbers existing data). */
export function ensureRivalry(career) {
  assert(career && typeof career === 'object', 'career required');
  if (!career.legacy || typeof career.legacy !== 'object') career.legacy = {};
  const leg = career.legacy;
  if (!Array.isArray(leg.matches)) leg.matches = [];
  if (!leg.rivalryMilestones || typeof leg.rivalryMilestones !== 'object') {
    leg.rivalryMilestones = {};
  }
  if (!Array.isArray(leg.activity)) leg.activity = [];
  return leg;
}

/**
 * Record one verified match result. Caller must only pass eligible competitions.
 * Returns the stored match record.
 */
export function recordRivalryMatch(career, cfg, {
  competition, opponentKey, opponentName, opponentUserId = null,
  gf, ga, at = Date.now(),
} = {}) {
  const rcfg = cfg.rivalry ?? {};
  assert((rcfg.eligibleCompetitions ?? []).includes(competition),
    `ineligible competition for rivalry: ${competition}`);
  assert(typeof opponentKey === 'string' && opponentKey.length > 0, 'opponentKey required');
  assert(Number.isInteger(gf) && gf >= 0, 'gf must be a non-negative int');
  assert(Number.isInteger(ga) && ga >= 0, 'ga must be a non-negative int');
  const leg = ensureRivalry(career);
  const m = {
    id: `m${at.toString(36)}${Math.floor(Math.random() * 1e6).toString(36)}`,
    at,
    competition,
    opponentKey,
    opponentName: String(opponentName ?? '').slice(0, 60),
    opponentUserId,
    gf,
    ga,
  };
  leg.matches.push(m);
  const max = rcfg.maxMatchesStored ?? 100;
  if (leg.matches.length > max) leg.matches.splice(0, leg.matches.length - max);
  return m;
}

/** Structured club activity feed (server-written only). Bounded. */
export function pushActivity(career, cfg, { kind, text, key = null, at = Date.now() } = {}) {
  assert(typeof text === 'string' && text.length > 0, 'activity text required');
  const leg = ensureRivalry(career);
  leg.activity.unshift({
    at,
    kind: kind ?? 'info',
    key,
    text: String(text).slice(0, 200),
  });
  const max = cfg.rivalry?.maxActivityStored ?? 20;
  if (leg.activity.length > max) leg.activity.length = max;
  return leg.activity;
}
