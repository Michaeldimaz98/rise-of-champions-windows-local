// Event persistence: { [eventId]: event }.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.resolve(__dirname, '../../data/events.json');

export const events = new Map();

export function loadEvents() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    for (const [id, ev] of Object.entries(raw)) events.set(id, ev);
    return events.size;
  } catch {
    return 0;
  }
}

export function persistEvents() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(events)));
  fs.renameSync(tmp, DATA_FILE);
}
