// Events (Phase 24) — DOMAIN module. Pure logic: data-driven event templates,
// lifecycle (upcoming/active/ended from timestamps), participation, scoring,
// leaderboards, and settlement with rewards. No HTTP, no DOM, no DB.
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';
import { recordTransaction } from '../finance/finance.js';
import { notify } from '../career/career.js';

export function getTemplate(cfg, templateId) {
  const t = cfg.templates.find((x) => x.id === templateId);
  assert(t, `unknown event template: ${templateId}`);
  return t;
}

export function eventStatus(ev, now = Date.now()) {
  if (now < ev.startsAt) return 'upcoming';
  if (now <= ev.endsAt) return 'active';
  return 'ended';
}

export function createEvent(cfg, { templateId, createdBy, now = Date.now() }) {
  const t = getTemplate(cfg, templateId);
  const startsAt = now;
  return {
    id: newId('evt'),
    templateId: t.id,
    name: t.name,
    description: t.description,
    scoring: { ...t.scoring },
    rewards: { ...t.rewards },
    maxParticipants: t.maxParticipants,
    createdBy,
    startsAt,
    endsAt: startsAt + t.durationDays * 86400000,
    participants: {}, // userId -> { username, score, played, joinedAt }
    rewardsPaid: false,
    createdAt: now,
  };
}

export function joinEvent(ev, { userId, username }, now = Date.now()) {
  const st = eventStatus(ev, now);
  assert(st === 'active' || st === 'upcoming', 'event is not open for joining');
  assert(!ev.participants[userId], 'already joined');
  const count = Object.keys(ev.participants).length;
  assert(count < ev.maxParticipants, 'event is full');
  ev.participants[userId] = { username, score: 0, played: 0, joinedAt: now };
  return ev;
}

/**
 * Record one career match into every ACTIVE event the user joined.
 * contribution: { goalsFor, won, played } — points come from the template's
 * scoring rule, so no per-event code paths are needed.
 */
export function recordEventProgress(events, userId, contribution, now = Date.now()) {
  const updated = [];
  for (const ev of events) {
    if (eventStatus(ev, now) !== 'active') continue;
    const p = ev.participants[userId];
    if (!p) continue;
    const metric = ev.scoring.metric;
    const pts = metricValue(contribution, metric) * ev.scoring.pointsPer;
    p.score += pts;
    p.played += contribution.played ? 1 : 0;
    updated.push({ eventId: ev.id, points: pts });
  }
  return updated;
}

function metricValue(contribution, metric) {
  if (metric === 'goalsFor') return Math.max(0, contribution.goalsFor | 0);
  if (metric === 'wins') return contribution.won ? 1 : 0;
  if (metric === 'played') return contribution.played ? 1 : 0;
  return 0;
}

/** Leaderboard: score desc, tie-break by earlier join (deterministic). */
export function eventLeaderboard(ev) {
  return Object.entries(ev.participants)
    .map(([userId, p]) => ({ userId, username: p.username, score: p.score, played: p.played, joinedAt: p.joinedAt }))
    .sort((a, b) => b.score - a.score || a.joinedAt - b.joinedAt);
}

/**
 * Settle a finished event: pay rank rewards (top-3) + participation.
 * Idempotent via ev.rewardsPaid. getCareer(userId) -> career; injected so
 * the domain stays persistence-free. Returns the payout list.
 */
export function settleEvent(ev, cfg, { getCareer, now = Date.now() }) {
  assert(eventStatus(ev, now) === 'ended', 'event has not ended yet');
  assert(!ev.rewardsPaid, 'rewards already paid');
  const board = eventLeaderboard(ev);
  const payouts = [];
  board.forEach((row, i) => {
    const rank = i + 1;
    const amount = rank <= 3 ? (ev.rewards[String(rank)] ?? 0) : (ev.rewards.participation ?? 0);
    if (amount <= 0) return;
    const career = getCareer(row.userId);
    if (!career) return;
    const claims = Array.isArray(career._eventRewardClaims) ? career._eventRewardClaims : [];
    // Persisted in the same atomic career file as the reward, bridging events.json crashes.
    if (claims.includes(ev.id)) return;
    const club = career.clubs[career.playerClubId].club;
    recordTransaction(club, {
      type: 'event_reward',
      amount,
      description: `Event "${ev.name}" — ${rank <= 3 ? `rank ${rank}` : 'participation'}`,
    });
    notify(career, `🎪 Event "${ev.name}" ended: you finished #${rank} (+${amount.toLocaleString()}).`);
    claims.push(ev.id);
    career._eventRewardClaims = claims;
    payouts.push({ userId: row.userId, username: row.username, rank, amount });
  });
  ev.rewardsPaid = true;
  return payouts;
}

export function publicEvent(ev, myUserId = null, now = Date.now()) {
  const board = eventLeaderboard(ev);
  const myRank = myUserId ? board.findIndex((r) => r.userId === myUserId) + 1 : 0;
  return {
    id: ev.id,
    templateId: ev.templateId,
    name: ev.name,
    description: ev.description,
    scoring: ev.scoring,
    status: eventStatus(ev, now),
    startsAt: ev.startsAt,
    endsAt: ev.endsAt,
    participantCount: board.length,
    maxParticipants: ev.maxParticipants,
    rewards: ev.rewards,
    rewardsPaid: ev.rewardsPaid,
    joined: myUserId ? !!ev.participants[myUserId] : false,
    myScore: myUserId && ev.participants[myUserId] ? ev.participants[myUserId].score : null,
    myRank: myRank || null,
    leaderboard: board.slice(0, 20),
  };
}
