// Squad management: registration, starting XI, bench, captain,
// set-piece takers. The squad stores player ids; player objects are
// passed in only where their state matters (availability).
import { loadConfig } from '../core/config.js';
import { newId } from '../core/ids.js';
import { ValidationError, assert } from '../core/validate.js';

function squadCfg() {
  return loadConfig('squad');
}

export function createSquad(clubId) {
  return {
    id: newId('squad'),
    clubId,
    players: [], // all registered player ids (reserves = not in XI/bench)
    lineup: [], // 11 starter ids
    bench: [], // up to 7 substitute ids
    captainId: null,
    setPieces: { penalty: null, freeKick: null, corner: null },
  };
}

function mustBeRegistered(squad, playerId, what = 'player') {
  assert(
    squad.players.includes(playerId),
    `${what} ${playerId} is not registered in the squad`
  );
}

function unique(ids, what) {
  assert(
    new Set(ids).size === ids.length,
    `${what} contains duplicate players`
  );
}

/** Register a player into the squad pool (starts as reserve). */
export function registerPlayer(squad, playerId) {
  assert(!squad.players.includes(playerId), `player ${playerId} already registered`);
  squad.players.push(playerId);
  return squad;
}

/** Remove a player from everywhere (transfer out / release). */
export function removePlayer(squad, playerId) {
  squad.players = squad.players.filter((id) => id !== playerId);
  squad.lineup = squad.lineup.filter((id) => id !== playerId);
  squad.bench = squad.bench.filter((id) => id !== playerId);
  if (squad.captainId === playerId) squad.captainId = null;
  for (const key of Object.keys(squad.setPieces)) {
    if (squad.setPieces[key] === playerId) squad.setPieces[key] = null;
  }
  return squad;
}

/** Set the starting XI: exactly 11 unique registered ids. */
export function setLineup(squad, playerIds) {
  const cfg = squadCfg();
  assert(
    playerIds.length === cfg.lineupSize,
    `lineup must have exactly ${cfg.lineupSize} players, got ${playerIds.length}`
  );
  unique(playerIds, 'lineup');
  for (const id of playerIds) mustBeRegistered(squad, id, 'lineup player');
  squad.lineup = [...playerIds];
  // Captain must stay in the XI.
  if (squad.captainId && !squad.lineup.includes(squad.captainId)) {
    squad.captainId = null;
  }
  return squad;
}

/** Set substitutes: up to benchSize unique registered ids, none in the XI. */
export function setBench(squad, playerIds) {
  const cfg = squadCfg();
  assert(
    playerIds.length <= cfg.benchSize,
    `bench holds at most ${cfg.benchSize} players, got ${playerIds.length}`
  );
  unique(playerIds, 'bench');
  for (const id of playerIds) {
    mustBeRegistered(squad, id, 'bench player');
    assert(!squad.lineup.includes(id), `bench player ${id} is already in the lineup`);
  }
  squad.bench = [...playerIds];
  return squad;
}

/** Captain must be in the starting XI. */
export function setCaptain(squad, playerId) {
  mustBeRegistered(squad, playerId, 'captain');
  assert(squad.lineup.includes(playerId), 'captain must be in the starting XI');
  squad.captainId = playerId;
  return squad;
}

/** Set-piece takers must be registered (usually from the XI). */
export function setSetPieceTakers(squad, { penalty, freeKick, corner }) {
  for (const [key, id] of Object.entries({ penalty, freeKick, corner })) {
    if (id == null) continue;
    mustBeRegistered(squad, id, `set-piece taker (${key})`);
    squad.setPieces[key] = id;
  }
  return squad;
}

/** Reserves: registered players neither in the XI nor on the bench. */
export function getReserves(squad) {
  const used = new Set([...squad.lineup, ...squad.bench]);
  return squad.players.filter((id) => !used.has(id));
}

/** Availability for selection: not injured and has fitness left. */
export function isAvailable(player) {
  return !player.injury && player.fitness > 0;
}

export { ValidationError };
