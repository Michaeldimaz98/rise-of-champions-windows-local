export * from './squad.js';
