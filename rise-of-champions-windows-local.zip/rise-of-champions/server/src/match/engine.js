// Match engine: deterministic possession-based simulation.
// Result is NEVER overall-only: position compatibility, formation,
// tactics, chemistry, fitness, morale, form, home advantage, momentum
// and randomness all feed in. Same seed + same inputs => identical result.
//
// simulateMatch mutates the input players (fitness load, morale, form,
// injuries) and returns a full MatchResult with event feed + stats.
//
// Phase 38: the engine is resumable. createMatch() builds an explicit match
// state; playMatchSegment()/applyHalftimeBreak()/runShootout()/finalizeMatch()
// advance it. simulateMatch() is a thin wrapper that runs the full sequence,
// preserving the exact historical behavior (same rng order, same events).
import { loadConfig } from '../core/config.js';
import { createRng } from '../core/rng.js';
import {
  applyMatchLoad,
  adjustMorale,
  updateForm,
  applyInjury,
} from '../players/condition.js';
import { groupForPosition } from '../players/attributes.js';
import { getFormation, validateFormation } from '../tactics/formation.js';

let cfg = null;
function getCfg() {
  if (!cfg) cfg = loadConfig('match');
  return cfg;
}

// Phase 39a: resolve a player's instruction arrow from tactics.
// Returns 'red' | 'blue' | null. Tactics remain the baseline; the instruction is
// a local per-player preference stored as tactics.playerInstructions[playerId].
function instructionOf(tactics, playerId) {
  const v = tactics?.playerInstructions?.[playerId] ?? null;
  return v === 'red' || v === 'blue' ? v : null;
}

// Phase 39a: decision weight multiplier for an instruction arrow and weight kind
// ('scorer' | 'assist' | 'tackle'). Falls back to 1 when unconfigured. All
// effects flow through the existing deterministic RNG via pickWeighted.
function instructionWeight(tactics, playerId, kind) {
  const iw = getCfg().instruction?.[instructionOf(tactics, playerId)];
  const w = iw?.[kind];
  return typeof w === 'number' && w > 0 ? w : 1;
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function compatibility(playerPos, slotPos) {
  const c = getCfg().compatibility;
  if (playerPos === slotPos) return c.same;
  if (playerPos === 'GK' || slotPos === 'GK') return c.gkMismatch;
  try {
    if (groupForPosition(playerPos) === groupForPosition(slotPos)) return c.sameGroup;
  } catch { /* unknown position */ }
  return c.other;
}

function avg(arr) {
  return arr.reduce((s, v) => s + v, 0) / Math.max(1, arr.length);
}

/** Effective ratings from XI + tactics (extracted for live recalculation). */
function computeTeamEff(players, tactics) {
  const c = getCfg();
  const slots = getFormation(tactics.formation);
  const illegal = !validateFormation(slots).legal;
  const ment = c.mentality[tactics.mentality] ?? c.mentality.Balanced;
  const pressMid = c.pressingMid[tactics.pressing] ?? 1;
  const instrCfg = c.instruction ?? {};

  let att = 0, mid = 0, def = 0, gk = 0, compat = 0;
  players.forEach((p, i) => {
    const slot = slots[i % slots.length];
    const k = compatibility(p.position, slot.position);
    compat += k;
    const a = p.attributes;
    // Phase 39a: per-player instruction is a LOCAL positional tendency shift, not a
    // team-wide buff. 'red' (attacking) reallocates the player's contribution toward
    // attack at the cost of defense; 'blue' (defensive) does the opposite. Team
    // tactics (mentality etc.) remain the baseline and apply on top.
    const iw = instrCfg[instructionOf(tactics, p.id)] ?? null;
    const attW = iw?.att ?? 1;
    const defW = iw?.def ?? 1;
    att += k * attW * (a.Shooting * 0.3 + a.Finishing * 0.35 + a.Dribbling * 0.15 + a.Speed * 0.2);
    mid += k * (a.Passing * 0.3 + a.Vision * 0.25 + a.BallControl * 0.2 + a.Stamina * 0.15 + a.WorkRate * 0.1);
    def += k * defW * (a.Tackling * 0.3 + a.Positioning * 0.25 + a.Heading * 0.15 + a.Strength * 0.2 + a.Speed * 0.1);
    if (slot.position === 'GK') {
      gk = k * (a.Reflexes * 0.25 + a.Diving * 0.2 + a.Handling * 0.2 + a.GKPositioning * 0.15 + a.OneOnOne * 0.1 + a.Concentration * 0.1);
    }
  });
  const n = players.length;
  return {
    eff: {
      att: (att / n) * ment.att,
      mid: (mid / n) * ment.mid * pressMid,
      def: (def / n) * ment.def,
      gk,
    },
    compat: compat / n,
    illegal,
  };
}

/** Build a team's effective ratings from XI + tactics. */
function buildTeam(side) {
  const { eff, compat, illegal } = computeTeamEff(side.players, side.tactics);
  return {
    eff,
    compat,
    illegal,
    shortHanded: 1, // multiplied down on red cards / unreplaced injuries
    players: [...side.players],
    bench: [...(side.bench ?? [])],
    tactics: side.tactics,
    name: side.name,
  };
}

/**
 * Recompute a live team's effectiveness after tactical changes.
 * Preserves shortHanded (red cards / unreplaced injuries).
 * Phase 38.
 */
export function recalcTeamEff(team) {
  const { eff, compat, illegal } = computeTeamEff(team.players, team.tactics);
  team.eff = eff;
  team.compat = compat;
  team.illegal = illegal;
  return team;
}

function pickWeighted(rng, items, weightFn) {
  let total = 0;
  for (const it of items) total += Math.max(0, weightFn(it));
  let roll = rng.float() * total;
  for (const it of items) {
    roll -= Math.max(0, weightFn(it));
    if (roll <= 0) return it;
  }
  return items[items.length - 1];
}

function newStats() {
  return { possession: 0, shots: 0, onTarget: 0, corners: 0, fouls: 0, offsides: 0, saves: 0, yellow: 0, red: 0 };
}

/** Pure possession probability (home share). Exported for testing. */
export function calcPossessionProb(midH, midA, { homeIllegal = false, awayIllegal = false, momentum = 0 } = {}) {
  const c = getCfg();
  const p = c.possession;
  let prob =
    0.5 + (midH - midA) * p.midWeight + p.homeBonus + (momentum / 100) * p.momentumWeight;
  prob = clamp(prob, 0.15, 0.85);
  if (homeIllegal) prob = Math.min(prob, p.illegalCap);
  if (awayIllegal) prob = Math.max(prob, 1 - p.illegalCap);
  return prob;
}

// ---------------------------------------------------------------------------
// Resumable match state (Phase 38).
// ---------------------------------------------------------------------------

/**
 * Create an explicit, resumable match state. All simulation helpers below
 * operate on this state object. The RNG call order is identical to the
 * historical simulateMatch, so behavior is preserved exactly.
 */
function createMatchState({ home, away, seed, knockout = false }) {
  const c = getCfg();
  const rng = createRng(seed);
  const m = {
    c, rng, knockout, seed,
    homeInput: home, awayInput: away,
    H: buildTeam(home), A: buildTeam(away),
    events: [],
    stats: { home: newStats(), away: newStats() },
    ratings: new Map(), // playerId -> { rating, goals, assists, player }
    yellows: new Map(), // playerId -> count
    minutes: new Map(), // playerId -> minutes played
    momentum: c.momentum.startHome, // >0 favors home
    scoreH: 0, scoreA: 0,
    minute: 0,
    // Phase 43: possession is REAL state (not a per-tick coin flip).
    // 'home' | 'away' — who controls the ball at the start of the tick.
    // Home kicks off (deterministic, football-sensible).
    poss: 'home',
    // Phase 45: transition state. Set ONLY when a team wins the ball via
    // open-play turnover (failed retention check). { team, ticks } — the
    // team that won possession and how many of THEIR attacking ticks remain
    // in the transition window. Null when no transition is active.
    // Engine-internal, deterministic, never client-submitted.
    transition: null,
    penalties: null,
    winner: null,
    finalized: false,
  };
  for (const t of [m.H, m.A]) {
    for (const p of t.players) {
      m.ratings.set(p.id, { rating: 6.5, goals: 0, assists: 0, player: p });
      m.minutes.set(p.id, 0);
    }
  }
  return m;
}

function emit(m, minute, type, team, player = null, detail = '') {
  m.events.push({
    minute,
    type,
    team, // 'home' | 'away' | null
    playerId: player?.id ?? null,
    playerName: player?.name ?? null,
    detail,
  });
}

function bump(m, player, d) {
  const r = m.ratings.get(player.id);
  if (r) r.rating = clamp(Math.round((r.rating + d) * 10) / 10, 1, 10);
}

function teamOf(m, t) {
  return t === m.H ? 'home' : 'away';
}
function other(m, t) {
  return t === m.H ? m.A : m.H;
}

function pickScorer(m, team) {
  // Forwards/mids score most: weight by attacking output.
  // Phase 39a: 'red' (attacking instruction) increases a player's scoring
  // involvement; 'blue' (defensive) decreases it. Decision preference only.
  const cands = team.players.filter((p) => p.position !== 'GK');
  return pickWeighted(m.rng, cands, (p) => {
    const a = p.attributes;
    const w = a.Finishing * 0.4 + a.Shooting * 0.3 + a.Positioning * 0.2 + a.Heading * 0.1;
    return w * instructionWeight(team.tactics, p.id, 'scorer');
  });
}

function pickAssistant(m, team, scorer) {
  const cands = team.players.filter((p) => p.id !== scorer.id && p.position !== 'GK');
  return pickWeighted(m.rng, cands, (p) =>
    (p.attributes.Passing * 0.5 + p.attributes.Vision * 0.5) * instructionWeight(team.tactics, p.id, 'assist'));
}

function addGoal(m, minute, team, scorer, assisted) {
  const c = m.c;
  if (team === m.H) m.scoreH++; else m.scoreA++;
  const r = m.ratings.get(scorer.id);
  r.goals++;
  bump(m, scorer, 1.2);
  let detail = `${scorer.name} scores`;
  if (assisted && m.rng.chance(0.55)) {
    const a = pickAssistant(m, team, scorer);
    m.ratings.get(a.id).assists++;
    bump(m, a, 0.8);
    detail += ` (assist: ${a.name})`;
  }
  emit(m, minute, 'goal', teamOf(m, team), scorer, detail);
  m.momentum = clamp(m.momentum + (team === m.H ? c.momentum.goal : -c.momentum.goal), -100, 100);
}

function resolveChance(m, minute, atk, def) {
  const c = m.c;
  // Phase 55: offside trap. If the defending team has it enabled, the trap is
  // attempted BEFORE the chance becomes a shot, on the existing seeded RNG
  // stream (consumed only when the trap is on and an eligible chance occurs).
  // Success: emit the existing 'offside' event and cancel the chance — no
  // shot, no xG, no goal. Failure: the defensive line is broken — apply a
  // bounded xG bonus for the exposure, then resolve the chance exactly once.
  // Set pieces never call resolveChance, so they are excluded by construction.
  // Passing-style counterplay (P54 design): Long/Direct balls over the top are
  // harder to trap; Short/Mixed play into it. Data-driven, bounded, O(1),
  // no new mutable state, no new event type.
  let trapFailed = false;
  const otCfg = c.offsideTrap ?? {};
  if (def.tactics?.offsideTrap === true) {
    const styleAdj = otCfg.styleAdj?.[atk.tactics?.passing] ?? 0;
    const pSuccess = clamp((otCfg.baseSuccess ?? 0.35) + styleAdj, 0, otCfg.maxSuccess ?? 0.95);
    if (m.rng.chance(pSuccess)) {
      m.stats[teamOf(m, atk)].offsides++;
      emit(m, minute, 'offside', teamOf(m, atk), null, 'Offside — caught by the trap');
      return;
    }
    trapFailed = true;
  }
  const atkEff = { ...atk.eff };
  const defEff = { ...def.eff };
  for (const k of ['att', 'mid', 'def']) {
    atkEff[k] *= atk.shortHanded;
    defEff[k] *= def.shortHanded;
  }
  let xg = c.xg.base + (atkEff.att - defEff.def) * c.xg.perDiff;
  if (def.tactics.defensiveLine === 'High') xg += c.xg.highLineBonus;
  if (def.tactics.defensiveLine === 'Deep') xg += c.xg.deepLineMalus;
  // Phase 55: failed trap — the line was broken, so the chance is better.
  // Applied exactly once, before the clamp so c.xg.max still bounds it.
  if (trapFailed) xg += otCfg.failXgBonus ?? 0.06;
  xg = clamp(xg, 0.02, c.xg.max);

  const scorer = pickScorer(m, atk);
  const keeper = def.players.find((p) => p.position === 'GK') ?? def.players[0];
  m.stats[teamOf(m, atk)].shots++;
  const s = c.shot;
  const keeperMod = s.keeperModBase - defEff.gk / s.keeperModDiv;
  const roll = m.rng.float();
  if (roll < xg * keeperMod) {
    m.stats[teamOf(m, atk)].onTarget++;
    addGoal(m, minute, atk, scorer, true);
  } else if (roll < xg * keeperMod + s.saveShare) {
    m.stats[teamOf(m, atk)].onTarget++;
    m.stats[teamOf(m, def)].saves++;
    bump(m, keeper, 0.25);
    emit(m, minute, 'save', teamOf(m, def), keeper, `${keeper.name} saves from ${scorer.name}`);
  } else if (roll < xg * keeperMod + s.saveShare + s.blockShare) {
    emit(m, minute, 'block', teamOf(m, def), null, `Blocked effort from ${scorer.name}`);
    if (m.rng.chance(s.cornerAfterBlock)) takeCorner(m, minute, atk, def);
  } else {
    emit(m, minute, 'miss', teamOf(m, atk), scorer, `${scorer.name} misses the target`);
  }
}

function takeCorner(m, minute, atk, def) {
  const c = m.c;
  m.stats[teamOf(m, atk)].corners++;
  const taker = pickWeighted(m.rng, atk.players.filter((p) => p.position !== 'GK'),
    (p) => p.attributes.Crossing + p.attributes.SetPieces);
  if (m.rng.chance(c.setPieces.cornerGoal)) {
    const scorer = pickWeighted(m.rng, atk.players, (p) => p.attributes.Heading * 0.6 + p.attributes.Finishing * 0.4);
    addGoal(m, minute, atk, scorer, false);
    m.events[m.events.length - 1].type = 'goal';
    m.events[m.events.length - 1].detail += ' (corner)';
  } else {
    emit(m, minute, 'corner', teamOf(m, atk), taker, `Corner taken by ${taker.name}`);
  }
}

function takeFreeKick(m, minute, atk, def) {
  const c = m.c;
  const taker = pickWeighted(m.rng, atk.players.filter((p) => p.position !== 'GK'),
    (p) => p.attributes.SetPieces * 0.7 + p.attributes.Shooting * 0.3);
  m.stats[teamOf(m, atk)].shots++;
  const pGoal = c.setPieces.freeKickGoal * (0.7 + taker.attributes.SetPieces / 200);
  if (m.rng.chance(pGoal)) {
    m.stats[teamOf(m, atk)].onTarget++;
    addGoal(m, minute, atk, taker, false);
  } else if (m.rng.chance(0.4)) {
    m.stats[teamOf(m, atk)].onTarget++;
    m.stats[teamOf(m, def)].saves++;
    emit(m, minute, 'save', teamOf(m, def), null, `Free kick from ${taker.name} saved`);
  } else {
    emit(m, minute, 'freekick', teamOf(m, atk), taker, `Free kick: ${taker.name}`);
  }
}

function takePenalty(m, minute, atk, def) {
  const c = m.c;
  const taker = pickWeighted(m.rng, atk.players.filter((p) => p.position !== 'GK'),
    (p) => p.attributes.Finishing * 0.6 + p.attributes.Composure * 0.4);
  const keeper = def.players.find((p) => p.position === 'GK');
  m.stats[teamOf(m, atk)].shots++;
  m.stats[teamOf(m, atk)].onTarget++;
  if (m.rng.chance(c.setPieces.penaltyGoal)) {
    addGoal(m, minute, atk, taker, false);
  } else {
    m.stats[teamOf(m, def)].saves++;
    bump(m, taker, -0.8);
    if (keeper) bump(m, keeper, 0.8);
    emit(m, minute, 'penalty-miss', teamOf(m, atk), taker, `${taker.name} misses the penalty!`);
    m.momentum = clamp(m.momentum + (atk === m.H ? c.momentum.missedPenalty : -c.momentum.missedPenalty), -100, 100);
  }
}

function maybeCard(m, minute, atk, def) {
  const c = m.c;
  const tackMap = c.cards.tackling;
  const mult = tackMap[def.tactics.tackling] ?? 1;
  const avgAggr = avg(def.players.map((p) => p.attributes.Aggression));
  const p = c.cards.basePerTick * mult * (0.8 + avgAggr / 150);
  if (!m.rng.chance(p)) return;
  // Phase 39a: 'blue' (defensive instruction) means more defensive involvement,
  // hence more tackle attempts and more card exposure (the trade-off); 'red'
  // means less defensive involvement.
  const culprit = pickWeighted(m.rng, def.players.filter((p) => p.position !== 'GK'),
    (p) => (p.attributes.Tackling * 0.4 + p.attributes.Aggression * 0.6) * instructionWeight(def.tactics, p.id, 'tackle'));
  m.stats[teamOf(m, def)].fouls++;
  const count = (m.yellows.get(culprit.id) ?? 0) + 1;
  m.yellows.set(culprit.id, count);
  if (count >= 2) {
    m.stats[teamOf(m, def)].red++;
    bump(m, culprit, -2.5);
    def.shortHanded *= c.shortHanded;
    def.players = def.players.filter((p) => p.id !== culprit.id);
    emit(m, minute, 'red', teamOf(m, def), culprit, `${culprit.name} sent off (second yellow)`);
    m.momentum = clamp(m.momentum + (def === m.H ? c.momentum.redCard : -c.momentum.redCard), -100, 100);
  } else {
    m.stats[teamOf(m, def)].yellow++;
    bump(m, culprit, -0.6);
    emit(m, minute, 'yellow', teamOf(m, def), culprit, `${culprit.name} booked`);
  }
}

function maybeInjury(m, minute, team) {
  const c = m.c;
  const avgFit = avg(team.players.map((p) => p.fitness));
  const p = c.injury.basePerTick * (0.7 + (100 - avgFit) / 120);
  if (!m.rng.chance(p)) return;
  const victim = m.rng.pick(team.players.filter((p) => p.position !== 'GK'));
  const types = ['Hamstring', 'Ankle Sprain', 'Knee Knock', 'Muscle Strain'];
  applyInjury(victim, m.rng.pick(types), m.rng.int(2, 14));
  bump(m, victim, -0.3);
  // Auto-sub if a bench player is available.
  const sub = team.bench.find((b) => !b.injury && b.fitness > 0);
  if (sub) {
    team.players = team.players.map((p) => (p.id === victim.id ? sub : p));
    team.bench = team.bench.filter((b) => b.id !== sub.id);
    if (!m.ratings.has(sub.id)) {
      m.ratings.set(sub.id, { rating: 6.5, goals: 0, assists: 0, player: sub });
      m.minutes.set(sub.id, 0);
    }
    emit(m, minute, 'sub', teamOf(m, team), sub, `${sub.name} replaces injured ${victim.name}`);
  } else {
    team.shortHanded *= c.shortHanded;
    team.players = team.players.filter((p) => p.id !== victim.id);
  }
  emit(m, minute, 'injury', teamOf(m, team), victim, `${victim.name} injured`);
}

function playTick(m, minute) {
  const c = m.c;
  m.momentum *= c.momentum.decay;
  // Phase 45: capture the transition object identity at tick start so the
  // end-of-tick consumption only advances a pre-existing window.
  const transAtStart = m.transition;
  // Phase 43: possession is REAL state (m.poss). The team with the ball
  // attacks. No per-tick coin flip — transitions happen via progression
  // resolution at the end of the tick.
  const atk = m.poss === 'home' ? m.H : m.A;
  const def = m.poss === 'home' ? m.A : m.H;
  m.stats[teamOf(m, atk)].possession++;

  const scoreBefore = m.scoreH + m.scoreA;
  const shotsBefore = m.stats.home.shots + m.stats.away.shots;

  const momTeam = atk === m.H ? m.momentum : -m.momentum;
  // Phase 41: tempo (Slow/Normal/Fast) modifies chance frequency. Fast tempo
  // creates a more open game (more chances for whoever has possession);
  // Slow tempo tightens it. Bounded multiplier, data-driven, deterministic.
  // Applied to the ATTACKING team's tempo — both sides benefit when attacking.
  const tempoMult = c.tempo?.[atk.tactics?.tempo] ?? 1;
  // Phase 44: passing (Short/Mixed/Direct/Long) affects progression behavior.
  // Short: safer retention, standard chance rate (patient buildup).
  // Long: lower retention, higher chance opportunity per possession (direct).
  // Data-driven, bounded. Modifies existing pChance, does not duplicate it.
  const passCfg = c.passing?.[atk.tactics?.passing] ?? { retain: 0, chance: 1 };
  // Phase 45: counter-attack is a TRANSITION behavior, not a permanent buff.
  // - If the attacking team won the ball via open-play turnover within the
  //   transition window and has counterAttack enabled: the break is played
  //   direct by definition, so transitionChance REPLACES the passing chance
  //   modifier (no stacking with Long/Direct — anti-double-dip).
  // - If counterAttack is enabled but there is no active transition: the team
  //   sits deeper and commits fewer players forward in settled possession
  //   (settledChance < 1). This is the cost that makes it a real choice.
  // - If counterAttack is disabled: pure Phase 44 behavior.
  const caCfg = c.counterAttack ?? {};
  const inTransition =
    m.transition !== null &&
    m.transition.team === m.poss &&
    m.transition.ticks > 0;
  // Effective style multiplier for chance generation. During a counter-attack
  // transition the break is direct by definition, so transitionChance replaces
  // the passing chance modifier (never stacks with it).
  // Phase 56: width as transition geometry (P54 redesign). When the P45
  // transition bonus applies, it is modulated by width — and ONLY there:
  // - own width: Wide sharpens your break (1.06), Narrow blunts it (0.94);
  // - defender width: a Wide defender leaves space to break into (1.04
  //   vulnerability), a Narrow defender stays compact (0.96 resistance).
  // Settled play is untouched by construction. Normal/Normal = exactly 1.0,
  // so the P45 baseline is bit-identical (IEEE754: x*1.0 === x) with zero
  // extra RNG draws. No direct xG modification — the delta flows through the
  // existing pChance architecture. O(1), no new state.
  const wCfg = c.width ?? {};
  const widthTransitionMult =
    (wCfg.transitionOwn?.[atk.tactics?.width] ?? 1) *
    (wCfg.transitionVs?.[def.tactics?.width] ?? 1);
  const styleChanceMult = atk.tactics?.counterAttack === true
    ? (inTransition
        ? (caCfg.transitionChance ?? 1) * widthTransitionMult
        : (passCfg.chance ?? 1) * (caCfg.settledChance ?? 1))
    : (passCfg.chance ?? 1);
  const pChance =
    c.chance.basePerPossession *
    (0.5 + (atk.eff.att * atk.shortHanded) / c.chance.attWeight) *
    (1 + momTeam / c.chance.momentumDivisor) *
    tempoMult *
    styleChanceMult;
  // Phase 46: time-wasting. A team that is leading late in the match and has
  // timeWasting enabled dawdles when IT has the ball: on deterministic waste
  // ticks the attacking opportunity (chance, set pieces, offside) is skipped.
  // Possession transition, cards and injuries still resolve — the game goes
  // on, just with fewer meaningful actions. Derived per-tick from
  // (score, minute, tactics): no new persisted state, no new RNG draws,
  // no xG modification. Eligibility ends the moment the lead is gone.
  const twCfg = c.timeWasting ?? {};
  const twLeader = m.scoreH > m.scoreA ? 'home' : m.scoreA > m.scoreH ? 'away' : null;
  const wasting =
    twLeader !== null &&
    minute >= (twCfg.fromMinute ?? 75) &&
    m.poss === twLeader &&
    (twLeader === 'home' ? m.H : m.A).tactics?.timeWasting === true &&
    minute % (twCfg.wasteEvery ?? 3) === 0;
  if (wasting) {
    emit(m, minute, 'timewasting', twLeader, null,
      `${(twLeader === 'home' ? m.H : m.A).name} take an age over the restart`);
  }
  if (!wasting) {
    if (m.rng.chance(pChance)) resolveChance(m, minute, atk, def);

    const sp = c.setPieces;
    if (m.rng.chance(sp.cornerPerTick)) takeCorner(m, minute, atk, def);
    else if (m.rng.chance(sp.freeKickPerTick)) takeFreeKick(m, minute, atk, def);
    else if (m.rng.chance(sp.penaltyPerTick)) takePenalty(m, minute, atk, def);

    if (m.rng.chance(c.offsidePerTick)) {
      m.stats[teamOf(m, atk)].offsides++;
      emit(m, minute, 'offside', teamOf(m, atk), null, 'Offside');
    }
  }

  maybeCard(m, minute, atk, def);
  maybeInjury(m, minute, atk);
  // Phase 43: possession transition (progression resolution).
  // The ball changes hands for a football reason, not a coin flip:
  // - Goal scored → conceding team kicks off.
  // - Shot taken (saved/blocked/missed) → defending team restarts.
  // - Otherwise → retention check: can the attacker keep the ball?
  //   Based on midfield quality differential. Pressing flows through
  //   def.eff.mid (pressingMid multiplier in computeTeamEff).
  const scored = (m.scoreH + m.scoreA) > scoreBefore;
  const shotTaken = (m.stats.home.shots + m.stats.away.shots) > shotsBefore;
  if (scored || shotTaken) {
    m.poss = m.poss === 'home' ? 'away' : 'home';
    // Phase 45: goal/shot restarts are structured, not open-play transitions —
    // they end any active transition window.
    m.transition = null;
  } else {
    const pc = c.possessionState ?? {};
    // Phase 44: passing modifies retention. Short = safer (+retain),
    // Long = riskier (-retain). Bounded by existing clamp.
    const passRetain = c.passing?.[atk.tactics?.passing]?.retain ?? 0;
    const pRetain = clamp(
      (pc.retainBase ?? 0.55) +
        ((atk.eff.mid * atk.shortHanded) - (def.eff.mid * def.shortHanded)) *
        (pc.retainPerMidDiff ?? 0.012) +
        passRetain,
      pc.retainMin ?? 0.25,
      pc.retainMax ?? 0.85
    );
    if (!m.rng.chance(pRetain)) {
      m.poss = m.poss === 'home' ? 'away' : 'home'; // turnover
      // Phase 45: open-play turnover — the winner gets a bounded transition
      // window. m.poss already flipped, so it names the new possessor.
      // A new turnover supersedes any previous window.
      m.transition = { team: m.poss, ticks: caCfg.transitionWindow ?? 3 };
      // Phase 48 (presentation only): authoritative counter-attack event.
      // Fires exactly when a CA-enabled team wins an open-play turnover.
      // No RNG consumed, no gameplay effect — pure event emission at a
      // deterministic point. Reveals only the football-observable fact that
      // the team launched a quick break (mirrors the Phase 46 timewasting
      // event precedent); never ticks, multipliers, or sealed config.
      const winner = m.poss === 'home' ? m.H : m.A;
      if (winner.tactics?.counterAttack === true) {
        emit(m, minute, 'counter', m.poss, null,
          `${winner.name} break forward on the counter`);
      }
    }
  }
  // Phase 45: consume one tick of the transition window, but only if the
  // window already existed at the START of this tick (identity check).
  // A window created by a turnover during THIS tick is not decremented yet,
  // so the winner gets exactly `transitionWindow` attacking ticks.
  // A new turnover overwrites the object (identity differs → no decrement).
  // Goal/shot restarts clear it. Expiry is automatic — never permanent.
  if (m.transition !== null && m.transition === transAtStart && m.transition.ticks > 0) {
    m.transition.ticks -= 1;
    if (m.transition.ticks <= 0) m.transition = null;
  }
  for (const p of [...m.H.players, ...m.A.players]) {
    m.minutes.set(p.id, (m.minutes.get(p.id) ?? 0) + 1);
  }
}

// ---------------------------------------------------------------------------
// Segment API (Phase 38). Each function advances the explicit match state.
// ---------------------------------------------------------------------------

/** Simulate minutes [fromMinute, toMinute] inclusive. */
export function playMatchSegment(m, fromMinute, toMinute) {
  for (let min = fromMinute; min <= toMinute; min++) playTick(m, min);
  m.minute = toMinute;
  return m;
}

export function emitKickoff(m) {
  emit(m, 0, 'kickoff', null, null, `${m.H.name} vs ${m.A.name} kicks off`);
  return m;
}

export function applyHalftimeBreak(m) {
  emit(m, 45, 'halftime', null, null, 'Half time');
  m.momentum *= m.c.momentum.halftimeFactor;
  // Phase 45: the break ends any active transition window.
  m.transition = null;
  return m;
}

export function emitExtraTime(m) {
  emit(m, 90, 'extratime', null, null, 'Extra time');
  // Phase 47: a transition must not survive a period break (mirrors halftime).
  m.transition = null;
  return m;
}

export function applyExtraTimeBreak(m) {
  m.momentum *= m.c.momentum.halftimeFactor;
  // Phase 47: a transition must not survive a period break (mirrors halftime).
  m.transition = null;
  return m;
}

export function emitFulltime(m) {
  emit(m, 121, 'fulltime', null, null,
    `Full time: ${m.H.name} ${m.scoreH} - ${m.scoreA} ${m.A.name}`);
  return m;
}

function shootout(m) {
  const order = ['home', 'away'];
  const picks = {
    home: [...m.H.players].filter((p) => p.position !== 'GK')
      .sort((a, b) => (b.attributes.Finishing + b.attributes.Composure) - (a.attributes.Finishing + a.attributes.Composure)).slice(0, 5),
    away: [...m.A.players].filter((p) => p.position !== 'GK')
      .sort((a, b) => (b.attributes.Finishing + b.attributes.Composure) - (a.attributes.Finishing + a.attributes.Composure)).slice(0, 5),
  };
  const keeperOf = { home: m.H.players.find((p) => p.position === 'GK'), away: m.A.players.find((p) => p.position === 'GK') };
  const scored = { home: 0, away: 0 };
  let suddenDeath = false;
  const take = (side, kicker) => {
    const pGoal = 0.7 + (kicker.attributes.Finishing - 70) / 400;
    const scoredIt = m.rng.chance(pGoal);
    if (scoredIt) scored[side]++;
    const r = m.ratings.get(kicker.id);
    if (r) bump(m, kicker, scoredIt ? 0.5 : -0.5);
    emit(m, 121, 'shootout', side, kicker,
      `${kicker.name} ${scoredIt ? 'scores' : 'misses'} (${scored.home}-${scored.away})`);
  };
  for (let round = 0; round < 5; round++) {
    for (const side of order) {
      take(side, picks[side][round]);
      const remaining = 4 - round;
      // early decision
      if (scored.home > scored.away + remaining + (order.indexOf(side) === 0 ? 1 : 0)) break;
      if (scored.away > scored.home + remaining + (order.indexOf(side) === 1 ? 1 : 0)) break;
    }
    if (scored.home !== scored.away && round >= 2) {
      const rem = 4 - round;
      if (Math.abs(scored.home - scored.away) > rem) break;
    }
  }
  let sd = 0;
  while (scored.home === scored.away && sd < 10) {
    suddenDeath = true;
    sd++;
    for (const side of order) {
      const kicker = picks[side][sd % 5];
      const before = { ...scored };
      take(side, kicker);
      if (scored.home !== scored.away && before.home === before.away) break;
    }
    if (scored.home !== scored.away) break;
  }
  return { scored, winner: scored.home > scored.away ? 'home' : 'away', suddenDeath };
}

/** Run the penalty shootout segment (knockout draws only). */
export function playShootout(m) {
  m.penalties = shootout(m);
  m.winner = m.penalties.winner;
  m.minute = 121;
  return m;
}

/**
 * Finalize: post-match fitness load, morale, form (exactly once) + result.
 * Returns the historical MatchResult shape.
 */
export function finalizeMatch(m) {
  if (m.finalized) throw new Error('match already finalized');
  m.finalized = true;
  const { H, A } = m;
  // ---- post-match: fitness load, morale, form ----
  for (const t of [H, A]) {
    const result = m.winner === 'draw' ? 'draw' : (t === H ? 'home' : 'away') === m.winner ? 'win' : 'loss';
    for (const p of t.players) {
      applyMatchLoad(p, m.minutes.get(p.id) ?? 90);
      adjustMorale(p, result === 'win' ? 8 : result === 'draw' ? 2 : -5);
      const r = m.ratings.get(p.id);
      if (r) updateForm(p, Math.round(r.rating));
    }
  }

  const totalPoss = m.stats.home.possession + m.stats.away.possession || 1;
  m.stats.home.possession = Math.round((m.stats.home.possession / totalPoss) * 100);
  m.stats.away.possession = 100 - m.stats.home.possession;

  const playerRatings = {};
  for (const [id, r] of m.ratings) {
    playerRatings[id] = {
      rating: Math.round(r.rating * 10) / 10,
      goals: r.goals,
      assists: r.assists,
      name: r.player.name,
      team: H.players.includes(r.player) || m.homeInput.players.includes(r.player) ? 'home' : 'away',
    };
  }

  return {
    home: H.name,
    away: A.name,
    score: { home: m.scoreH, away: m.scoreA },
    winner: m.winner,
    penalties: m.penalties,
    events: m.events,
    stats: m.stats,
    playerRatings,
    seed: m.seed,
  };
}

/**
 * Historical full-match simulation. Thin wrapper over the segment API —
 * identical rng order, events, and results as before Phase 38.
 */
export function simulateMatch({ home, away, seed, knockout = false }) {
  const m = createMatchState({ home, away, seed, knockout });
  emitKickoff(m);
  playMatchSegment(m, 1, 45);
  applyHalftimeBreak(m);
  playMatchSegment(m, 46, 90);

  let winner = m.scoreH === m.scoreA ? 'draw' : m.scoreH > m.scoreA ? 'home' : 'away';

  if (knockout && winner === 'draw') {
    emitExtraTime(m);
    playMatchSegment(m, 91, 105);
    applyExtraTimeBreak(m);
    playMatchSegment(m, 106, 120);
    if (m.scoreH === m.scoreA) {
      playShootout(m);
      winner = m.winner;
    } else {
      winner = m.scoreH > m.scoreA ? 'home' : 'away';
    }
  }
  m.winner = winner;
  emitFulltime(m);
  return finalizeMatch(m);
}

// ---------------------------------------------------------------------------
// Snapshot / restore (Phase 38 persistence).
// ---------------------------------------------------------------------------

function snapTeam(t) {
  return {
    name: t.name,
    ids: t.players.map((p) => p.id),
    bench: t.bench.map((p) => p.id),
    tactics: JSON.parse(JSON.stringify(t.tactics)),
    shortHanded: t.shortHanded,
    // Phase 49: team.eff/compat/illegal are authoritative MUTABLE runtime
    // state (recomputed on subs/tactical changes via recalcTeamEff). They are
    // NOT safely re-derivable: a red card / unreplaced injury shrinks the XI
    // while the live eff keeps its pre-change value, so recomputing at
    // restore time yields a different eff and a divergent continuation.
    // Persist the exact values; restore them verbatim.
    eff: { ...t.eff },
    compat: t.compat,
    illegal: t.illegal,
  };
}

/** Serializable snapshot of a live match. */
export function snapshotMatch(m) {
  return {
    v: 1,
    seed: m.seed,
    knockout: m.knockout,
    minute: m.minute,
    scoreH: m.scoreH,
    scoreA: m.scoreA,
    momentum: m.momentum,
    poss: m.poss, // Phase 43: possession state survives save/load
    transition: m.transition === null ? null : { team: m.transition.team, ticks: m.transition.ticks }, // Phase 45
    rngState: m.rng.getState(),
    events: m.events,
    stats: m.stats,
    ratings: [...m.ratings].map(([id, r]) => [id, { rating: r.rating, goals: r.goals, assists: r.assists }]),
    yellows: [...m.yellows],
    minutes: [...m.minutes],
    home: snapTeam(m.H),
    away: snapTeam(m.A),
    penalties: m.penalties,
    winner: m.winner,
  };
}

/**
 * Restore a match from a snapshot.
 * getPlayer(side, id) -> player object ('home' | 'away').
 */
export function restoreMatch(snap, getPlayer) {
  const c = getCfg();
  const rng = createRng(snap.seed);
  rng.setState(snap.rngState);
  const m = {
    c, rng, knockout: snap.knockout, seed: snap.seed,
    homeInput: null, awayInput: null,
    H: null, A: null,
    events: snap.events,
    stats: snap.stats,
    ratings: new Map(),
    yellows: new Map(snap.yellows),
    minutes: new Map(snap.minutes),
    momentum: snap.momentum,
    scoreH: snap.scoreH, scoreA: snap.scoreA,
    minute: snap.minute,
    poss: snap.poss ?? 'home', // Phase 43: backward compat for old saves
    transition: snap.transition === undefined ? null // Phase 45: backward compat
      : (snap.transition === null ? null : { team: snap.transition.team, ticks: snap.transition.ticks }),
    penalties: snap.penalties,
    winner: snap.winner,
    finalized: false,
  };
  for (const [key, side, tag] of [['H', snap.home, 'home'], ['A', snap.away, 'away']]) {
    const players = side.ids.map((id) => getPlayer(tag, id));
    const bench = side.bench.map((id) => getPlayer(tag, id));
    if (players.some((p) => !p) || bench.some((p) => !p)) {
      throw new Error(`restoreMatch: missing player for ${tag}`);
    }
    const team = buildTeam({ name: side.name, players, bench, tactics: side.tactics });
    team.shortHanded = side.shortHanded;
    // Phase 49: restore the exact authoritative effective state when present.
    // Old snapshots (pre-Phase 49) lack these fields — fall back to the
    // recomputed values from buildTeam (previous behavior, backward compat).
    if (side.eff !== undefined) team.eff = { ...side.eff };
    if (side.compat !== undefined) team.compat = side.compat;
    if (side.illegal !== undefined) team.illegal = side.illegal;
    m[key] = team;
  }
  for (const [id, r] of snap.ratings) {
    const player = getPlayer('home', id) ?? getPlayer('away', id);
    m.ratings.set(id, { ...r, player });
  }
  return m;
}

/** Exposed for the live module (creates a fresh resumable match). */
export function createMatch(opts) {
  return createMatchState(opts);
}
