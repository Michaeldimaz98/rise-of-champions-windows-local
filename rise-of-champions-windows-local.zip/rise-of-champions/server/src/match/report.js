// Match report projection (Phase 50).
//
// Deterministic, read-only interpretation of the authoritative
// finalizeMatch result. Pure function: no engine changes, no RNG, no
// mutation, no resimulation. Derived presentation values only.
//
// Privacy: configured tactics are included ONLY when explicitly passed
// (career, own + AI opponent). Ranked calls buildMatchReport(result)
// without tactics, so the projection never carries sealed configuration.
export function buildMatchReport(result, opts = {}) {
  const {
    home, away,
    score = { home: 0, away: 0 },
    winner = 'draw',
    penalties = null,
    events = [],
    stats = null,
  } = result ?? {};
  const tactics = opts.tactics ?? {};

  const ofType = (type) => events.filter((e) => e.type === type);
  const bySide = (list, side) => list.filter((e) => e.team === side);

  const counterEvents = ofType('counter');
  const twEvents = ofType('timewasting');
  const goalEvents = ofType('goal');
  const redEvents = ofType('red');

  const st = stats ?? { home: {}, away: {} };
  const num = (side, key) => st[side]?.[key] ?? 0;

  // ---- summary: authoritative facts only
  const summary = {
    home, away,
    score: { home: score.home, away: score.away },
    winner,
    penalties: penalties ? {
      home: penalties.scored?.home ?? 0,
      away: penalties.scored?.away ?? 0,
    } : null,
    possession: { home: num('home', 'possession'), away: num('away', 'possession') },
    shots: { home: num('home', 'shots'), away: num('away', 'shots') },
    onTarget: { home: num('home', 'onTarget'), away: num('away', 'onTarget') },
    corners: { home: num('home', 'corners'), away: num('away', 'corners') },
    fouls: { home: num('home', 'fouls'), away: num('away', 'fouls') },
    yellow: { home: num('home', 'yellow'), away: num('away', 'yellow') },
    red: { home: num('home', 'red'), away: num('away', 'red') },
  };

  // ---- tactical: observed behavior (event conservation) + configured
  // passing only when explicitly provided. Counts are derived by filtering
  // the authoritative events — never by a second detection algorithm.
  const tacticalSide = (side) => {
    const counters = bySide(counterEvents, side);
    const tws = bySide(twEvents, side);
    const t = { team: side === 'home' ? home : away };
    if (tactics[side]?.passing !== undefined) t.passing = tactics[side].passing;
    t.counterAttacks = counters.length;
    t.counterMinutes = counters.map((e) => e.minute);
    t.timeWasting = tws.length;
    t.timeWastingMinutes = tws.map((e) => e.minute);
    return t;
  };
  const tactical = { home: tacticalSide('home'), away: tacticalSide('away') };

  // ---- turning points: goals + red cards, engine order preserved
  // (events are already chronological; no re-sorting).
  const turningPoints = events
    .filter((e) => e.type === 'goal' || e.type === 'red')
    .map((e) => ({
      minute: e.minute,
      type: e.type,
      team: e.team,
      label: e.detail || e.type,
    }));

  // ---- narrative: deterministic templates, fixed order.
  // Level 1 (facts) and Level 2 (deterministic aggregation) only.
  // No causal claims, no punditry.
  const narrative = [];
  const name = (side) => (side === 'home' ? home : away);

  // Possession.
  const possH = num('home', 'possession'), possA = num('away', 'possession');
  const possDiff = possH - possA;
  if (Math.abs(possDiff) >= 10) {
    const leader = possDiff > 0 ? 'home' : 'away';
    narrative.push(
      `${name(leader)} controlled more of the possession (${Math.max(possH, possA)}%).`
    );
  } else {
    narrative.push('Possession was evenly shared.');
  }

  // Chances.
  const shH = num('home', 'shots'), shA = num('away', 'shots');
  if (Math.abs(shH - shA) > 2) {
    const leader = shH > shA ? 'home' : 'away';
    narrative.push(
      `${name(leader)} created more chances (${Math.max(shH, shA)} shots to ${Math.min(shH, shA)}).`
    );
  } else {
    narrative.push('Both teams created a similar number of chances.');
  }

  // Goals in order, with score-state context (lead / equalizer / extension).
  // Derived purely from the chronological goal events.
  let gh = 0, ga = 0;
  for (const g of goalEvents) {
    const homeScored = g.team === 'home';
    const wasLeading = homeScored ? gh > ga : ga > gh;
    if (homeScored) gh++; else ga++;
    const nowLeading = homeScored ? gh > ga : ga > gh;
    if (gh === ga) {
      narrative.push(`At ${g.minute}', ${name(g.team)} equalized.`);
    } else if (nowLeading && !wasLeading) {
      narrative.push(`At ${g.minute}', ${name(g.team)} took the lead.`);
    } else if (nowLeading) {
      narrative.push(`At ${g.minute}', ${name(g.team)} extended the lead.`);
    } else {
      narrative.push(`At ${g.minute}', ${name(g.team)} scored.`);
    }
  }
  if (goalEvents.length === 0) {
    narrative.push('Neither team found the net.');
  }

  // Counter-attacks (observed).
  for (const side of ['home', 'away']) {
    const n = tactical[side].counterAttacks;
    if (n > 0) narrative.push(`${name(side)} recorded ${n} counter-attack${n === 1 ? '' : 's'}.`);
  }

  // Time-wasting (observed).
  for (const side of ['home', 'away']) {
    const n = tactical[side].timeWasting;
    if (n > 0) narrative.push(`${name(side)} slowed the tempo late on.`);
  }

  // Configured passing styles (only when explicitly provided — never Ranked).
  // A configuration fact, not a causal claim.
  for (const side of ['home', 'away']) {
    const p = tactical[side].passing;
    if (p) narrative.push(`${name(side)} used a ${p} passing style.`);
  }

  // Red cards (observed).
  for (const side of ['home', 'away']) {
    const n = bySide(redEvents, side).length;
    if (n === 1) narrative.push(`${name(side)} finished with 10 men.`);
    else if (n > 1) narrative.push(`${name(side)} finished with ${11 - n} men.`);
  }

  // Penalties.
  if (penalties) {
    narrative.push(
      `The tie was decided on penalties (${penalties.scored?.home ?? 0}–${penalties.scored?.away ?? 0}).`
    );
  }

  return { summary, tactical, turningPoints, narrative };
}
