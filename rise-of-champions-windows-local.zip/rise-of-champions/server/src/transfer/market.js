// Transfer market state: listings, offers, history, window flag.
import { newId } from '../core/ids.js';
import { assert, checkIntRange } from '../core/validate.js';
import { loadConfig } from '../core/config.js';

export function createTransferMarket({ windowOpen = true } = {}) {
  return {
    windowOpen,
    listings: new Map(), // id -> listing
    offers: new Map(), // id -> offer
    history: [], // completed transfers
  };
}

function transferCfg() {
  return loadConfig('transfer');
}

/** Put a player up for sale. */
export function listForSale(market, { playerId, sellerClubId, askingPrice }) {
  assert(playerId && sellerClubId, 'playerId and sellerClubId required');
  assert(Number.isFinite(askingPrice) && askingPrice > 0, 'askingPrice must be positive');
  for (const l of market.listings.values()) {
    assert(!(l.playerId === playerId && l.status === 'active'), 'player already listed');
  }
  const listing = {
    id: newId('listing'),
    playerId,
    sellerClubId,
    askingPrice: Math.round(askingPrice),
    status: 'active',
    createdAt: Date.now(),
  };
  market.listings.set(listing.id, listing);
  return listing;
}

export function delist(market, listingId) {
  const listing = market.listings.get(listingId);
  assert(listing, `unknown listing: ${listingId}`);
  assert(listing.status === 'active', 'only active listings can be removed');
  listing.status = 'withdrawn';
  return listing;
}

/** Make an offer on an active listing. */
export function makeOffer(market, { listingId, fromClubId, fee, wageOffer, years }) {
  const cfg = transferCfg();
  const listing = market.listings.get(listingId);
  assert(listing, `unknown listing: ${listingId}`);
  assert(listing.status === 'active', 'listing is not active');
  assert(market.windowOpen, 'transfer window is closed');
  assert(fromClubId !== listing.sellerClubId, 'cannot buy your own player');
  assert(Number.isFinite(fee) && fee > 0, 'fee must be positive');
  checkIntRange(years, cfg.minContractYears, cfg.maxContractYears, 'contract years');
  assert(Number.isFinite(wageOffer) && wageOffer > 0, 'wageOffer must be positive');

  const offer = {
    id: newId('offer'),
    listingId,
    fromClubId,
    fee: Math.round(fee),
    wageOffer: Math.round(wageOffer),
    years,
    status: 'pending',
    createdAt: Date.now(),
  };
  market.offers.set(offer.id, offer);
  return offer;
}

/**
 * Seller AI evaluates an offer: accept / counter / reject.
 * Deterministic-ish: rng only used for flavor, thresholds are fixed.
 */
export function evaluateOffer(market, offerId, rng = null) {
  const cfg = transferCfg().negotiation;
  const offer = market.offers.get(offerId);
  assert(offer, `unknown offer: ${offerId}`);
  assert(offer.status === 'pending', 'offer already answered');
  const listing = market.listings.get(offer.listingId);
  const ratio = offer.fee / listing.askingPrice;

  if (ratio >= cfg.acceptAt) {
    offer.status = 'accepted';
    return { decision: 'accepted', offer };
  }
  if (ratio >= cfg.counterAt) {
    const counterFee = Math.round(listing.askingPrice * cfg.counterOfferFactor);
    const counter = {
      id: newId('offer'),
      listingId: offer.listingId,
      fromClubId: listing.sellerClubId, // seller counters
      toClubId: offer.fromClubId,
      fee: counterFee,
      wageOffer: offer.wageOffer,
      years: offer.years,
      status: 'counter',
      counters: offer.id,
      createdAt: Date.now(),
    };
    offer.status = 'countered';
    market.offers.set(counter.id, counter);
    return { decision: 'counter', offer, counter };
  }
  offer.status = 'rejected';
  return { decision: 'rejected', offer };
}

/** Buyer answers a seller counter-offer. */
export function answerCounter(market, counterId, accept) {
  const counter = market.offers.get(counterId);
  assert(counter, `unknown offer: ${counterId}`);
  assert(counter.status === 'counter', 'not a counter-offer');
  counter.status = accept ? 'accepted' : 'rejected';
  return counter;
}
