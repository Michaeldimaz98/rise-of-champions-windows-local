// Completing transfers: money moves, player changes squads, contract signed.
import { assert } from '../core/validate.js';
import { removePlayer, registerPlayer } from '../squad/squad.js';

/**
 * Execute an accepted offer.
 *   market, offerId (status 'accepted')
 *   playersById: Map playerId -> player object (mutated)
 *   squadsById: Map clubId -> squad object (mutated)
 *   clubsById: Map clubId -> club object { id, cash, ... } (mutated)
 */
export function completeTransfer(market, offerId, { playersById, squadsById, clubsById }) {
  const offer = market.offers.get(offerId);
  assert(offer, `unknown offer: ${offerId}`);
  assert(offer.status === 'accepted', `offer is ${offer.status}, not accepted`);
  const listing = market.listings.get(offer.listingId);
  assert(listing.status === 'active', 'listing is not active');

  const buyerClubId = offer.fromClubId;
  const sellerClubId = listing.sellerClubId;
  const buyer = clubsById.get(buyerClubId);
  const seller = clubsById.get(sellerClubId);
  assert(buyer && seller, 'buyer or seller club not found');
  assert(buyer.cash >= offer.fee, `insufficient funds: need ${offer.fee}, have ${buyer.cash}`);

  const player = playersById.get(listing.playerId);
  assert(player, `player not found: ${listing.playerId}`);

  // Money.
  buyer.cash -= offer.fee;
  seller.cash += offer.fee;

  // Squads: out of seller XI/bench/reserves, into buyer's registered pool.
  const sellerSquad = squadsById.get(sellerClubId);
  const buyerSquad = squadsById.get(buyerClubId);
  if (sellerSquad) removePlayer(sellerSquad, player.id);
  if (buyerSquad) registerPlayer(buyerSquad, player.id);

  // New contract.
  player.wage = offer.wageOffer;
  player.contract = {
    ...player.contract,
    yearsLeft: offer.years,
    salary: offer.wageOffer,
    signingBonus: 0,
  };
  player.morale = Math.min(100, (player.morale ?? 70) + 10); // new-club bounce

  listing.status = 'sold';
  offer.status = 'completed';

  const record = {
    playerId: player.id,
    playerName: player.name,
    fromClubId: sellerClubId,
    toClubId: buyerClubId,
    fee: offer.fee,
    wage: offer.wageOffer,
    years: offer.years,
    at: Date.now(),
  };
  market.history.push(record);
  return record;
}

/**
 * Sign a free agent (no selling club, no fee).
 * player must not be registered in any squad in squadsById.
 */
export function signFreeAgent(market, { playerId, clubId, wage, years, playersById, squadsById, clubsById }) {
  assert(market.windowOpen, 'transfer window is closed');
  const player = playersById.get(playerId);
  assert(player, `player not found: ${playerId}`);
  for (const squad of squadsById.values()) {
    assert(!squad.players.includes(playerId), 'player is already registered at a club');
  }
  const club = clubsById.get(clubId);
  assert(club, 'club not found');
  const squad = squadsById.get(clubId);
  assert(squad, 'squad not found');

  registerPlayer(squad, playerId);
  player.wage = Math.round(wage);
  player.contract = { ...player.contract, yearsLeft: years, salary: Math.round(wage), signingBonus: 0 };
  player.morale = Math.min(100, (player.morale ?? 70) + 10);

  const record = {
    playerId: player.id,
    playerName: player.name,
    fromClubId: null,
    toClubId: clubId,
    fee: 0,
    wage: Math.round(wage),
    years,
    at: Date.now(),
  };
  market.history.push(record);
  return record;
}
