// Continental Champions: seasonal continental competition for top league clubs.
// Competition layer only: qualification, group stage, standings, knockout, final.
// Match simulation reuses the existing match engine (group: draws allowed;
// knockout: ET + penalties, same as the career cup).
// Rewards/trophies/milestones/records/prestige reuse Phase 32-36 infrastructure.
// Phase 37.
import { createRng } from '../core/rng.js';
import { simulateMatch } from '../match/engine.js';
import { buildMatchReport } from '../match/report.js';
import { loadConfig } from '../core/config.js';
import { assert } from '../core/validate.js';
import { careerTeamBundle, notify } from '../career/career.js';
import { recordTransaction } from '../finance/finance.js';
import { checkMilestones, applyMilestoneRewards } from '../legacy/milestones.js';
import { pushActivity } from '../rivalry/matches.js';

export const COMP_NAME = 'Continental Champions';

function slots() {
  return loadConfig('competition').continental?.slots ?? 4;
}

/** Field-by-field backfill for old saves. Never creates a competition by itself. */
export function ensureContinental(career) {
  assert(career && typeof career === 'object', 'career required');
  if (!Array.isArray(career.continentalHistory)) career.continentalHistory = [];
  return career.continental ?? null;
}

/**
 * Build the season's continental competition from validated league standings.
 * Called at season rollover: `standings` is the COMPLETED season's final table
 * (server-side), `season` is the NEW season number.
 * Archives any previous competition into continentalHistory (bounded).
 */
export function qualifyContinental(career, standings, season) {
  assert(career && typeof career === 'object', 'career required');
  assert(Array.isArray(standings) && standings.length >= slots(), 'standings too small');
  assert(Number.isInteger(season) && season >= 1, 'season required');
  ensureContinental(career);
  if (career.continental) archiveContinental(career);

  const qualifiers = standings.slice(0, slots()).map((r) => r.clubId);
  assert(new Set(qualifiers).size === qualifiers.length, 'qualifiers must be unique');

  // Seeded draw order for the group (stable input, Fisher-Yates).
  const rng = createRng(`${career.seed}:continental:s${season}:draw`);
  const ordered = [...qualifiers].sort();
  for (let i = ordered.length - 1; i > 0; i--) {
    const j = Math.floor(rng.float() * (i + 1));
    [ordered[i], ordered[j]] = [ordered[j], ordered[i]];
  }

  career.continental = {
    competition: COMP_NAME,
    season,
    status: 'group', // group -> knockout -> complete
    qualifiers,
    champion: null,
    runnerUp: null,
    finalized: false,
    qualificationPaid: false,
    group: {
      name: 'Group A',
      fixtures: roundRobin(ordered, season),
    },
    knockout: { fixtures: [] },
  };
  return career.continental;
}

/** Single round-robin: 4 teams -> 3 matchdays x 2 fixtures (circle method). */
function roundRobin(ids, season) {
  const teams = [...ids];
  const fixtures = [];
  let matchday = 1;
  for (let round = 0; round < teams.length - 1; round++) {
    for (let i = 0; i < teams.length / 2; i++) {
      const home = teams[i];
      const away = teams[teams.length - 1 - i];
      if (home === away) continue;
      fixtures.push({
        id: `cont-s${season}-g${matchday}-f${i}`,
        matchday,
        home,
        away,
        status: 'pending',
        homeScore: null,
        awayScore: null,
      });
    }
    // rotate (keep first fixed)
    teams.splice(1, 0, teams.pop());
    matchday++;
  }
  return fixtures;
}

function archiveContinental(career) {
  const c = career.continental;
  career.continentalHistory.push({
    season: c.season,
    status: c.status,
    champion: c.champion,
    championName: c.champion ? career.clubs[c.champion]?.club.name ?? null : null,
    runnerUp: c.runnerUp,
    playerRun: playerContinentalRun(career, c),
  });
  const max = 12;
  if (career.continentalHistory.length > max) {
    career.continentalHistory.splice(0, career.continentalHistory.length - max);
  }
}

/** How far the player's club got: Champions / Final / Group Stage / null. */
export function playerContinentalRun(career, cont = career.continental) {
  if (!cont) return null;
  if (cont.champion === career.playerClubId) return 'Champions';
  const kf = cont.knockout.fixtures[0];
  if (kf && (kf.home === career.playerClubId || kf.away === career.playerClubId)) {
    return cont.status === 'complete' ? 'Final' : 'Final';
  }
  if (cont.qualifiers.includes(career.playerClubId)) return 'Group Stage';
  return null;
}

/**
 * Group standings, derived from played fixtures. Tiebreakers (deterministic):
 * points -> goal difference -> goals for -> head-to-head points -> seeded order.
 * Returns [{ clubId, p, w, d, l, gf, ga, gd, pts }].
 */
export function continentalStandings(career, cont = career.continental) {
  assert(cont, 'no continental competition');
  const table = new Map();
  for (const id of cont.qualifiers) {
    table.set(id, { clubId: id, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0 });
  }
  for (const f of cont.group.fixtures) {
    if (f.status !== 'played') continue;
    const h = table.get(f.home);
    const t = table.get(f.away);
    if (!h || !t) continue;
    h.p++; t.p++;
    h.gf += f.homeScore; h.ga += f.awayScore;
    t.gf += f.awayScore; t.ga += f.homeScore;
    if (f.homeScore > f.awayScore) { h.w++; t.l++; h.pts += 3; }
    else if (f.homeScore < f.awayScore) { t.w++; h.l++; t.pts += 3; }
    else { h.d++; t.d++; h.pts++; t.pts++; }
  }
  for (const row of table.values()) row.gd = row.gf - row.ga;

  // Head-to-head points among a tied subset, from played group fixtures.
  const h2hPoints = (ids) => {
    const pts = new Map(ids.map((id) => [id, 0]));
    for (const f of cont.group.fixtures) {
      if (f.status !== 'played') continue;
      if (!pts.has(f.home) || !pts.has(f.away)) continue;
      if (f.homeScore > f.awayScore) pts.set(f.home, pts.get(f.home) + 3);
      else if (f.homeScore < f.awayScore) pts.set(f.away, pts.get(f.away) + 3);
      else { pts.set(f.home, pts.get(f.home) + 1); pts.set(f.away, pts.get(f.away) + 1); }
    }
    return pts;
  };

  const rows = [...table.values()];
  // Seeded fallback order (deterministic, last resort).
  const seedOrder = new Map([...cont.qualifiers].sort().map((id, i) => [id, i]));
  rows.sort((a, b) => {
    if (b.pts !== a.pts) return b.pts - a.pts;
    if (b.gd !== a.gd) return b.gd - a.gd;
    if (b.gf !== a.gf) return b.gf - a.gf;
    // head-to-head among clubs tied on pts/gd/gf
    const tied = rows.filter((r) => r.pts === a.pts && r.gd === a.gd && r.gf === a.gf)
      .map((r) => r.clubId);
    if (tied.length > 1) {
      const hp = h2hPoints(tied);
      if (hp.get(b.clubId) !== hp.get(a.clubId)) return hp.get(b.clubId) - hp.get(a.clubId);
    }
    return seedOrder.get(a.clubId) - seedOrder.get(b.clubId);
  });
  return rows;
}

/** The player's next pending fixture (group or final), or null. */
export function playerContinentalFixture(career) {
  const cont = ensureContinental(career);
  if (!cont || cont.status === 'complete') return null;
  const pool = cont.status === 'group' ? cont.group.fixtures : cont.knockout.fixtures;
  return pool.find((f) => f.status === 'pending'
    && (f.home === career.playerClubId || f.away === career.playerClubId)) ?? null;
}

/**
 * Play the current matchday: simulates every pending fixture of the lowest
 * incomplete group matchday (player's + AI), or the final (knockout mode).
 * Idempotent: played fixtures are skipped.
 * Returns { results, playerResult, champion }.
 */
export function playContinental(career, opts = {}) {
  const deferPlayer = !!opts.deferPlayer;
  const cont = ensureContinental(career);
  assert(cont, 'no continental competition — qualify via the league first');
  assert(cont.status !== 'complete', 'continental is already complete');
  const results = [];
  let playerResult = null;
  let deferredFixture = null;

  if (cont.status === 'group') {
    const pending = cont.group.fixtures.filter((f) => f.status === 'pending');
    assert(pending.length > 0, 'no pending group fixtures');
    const matchday = Math.min(...pending.map((f) => f.matchday));
    for (const f of cont.group.fixtures.filter((x) => x.matchday === matchday && x.status === 'pending')) {
      const isPlayer = f.home === career.playerClubId || f.away === career.playerClubId;
      if (isPlayer && deferPlayer) {
        deferredFixture = f;
        continue;
      }
      const home = careerTeamBundle(career, f.home);
      const away = careerTeamBundle(career, f.away);
      const result = simulateMatch({
        home,
        away,
        seed: `${career.seed}:continental:s${cont.season}:${f.id}`,
        knockout: false, // group stage: draws allowed
      });
      applyContinentalGroupResult(f, result);
      results.push({ fixtureId: f.id, home: f.home, away: f.away, score: result.score });
      if (isPlayer) {
        // Phase 51: same shared report projection as every other flow.
        playerResult = {
          fixture: { ...f },
          result,
          report: buildMatchReport(result, { tactics: { home: home.tactics, away: away.tactics } }),
        };
      }
    }
    if (deferPlayer) {
      return { results, playerResult: null, deferredFixture, champion: null, deferred: true };
    }
    progressContinentalGroup(career, cont);
  } else {
    // Knockout: the final, ET + penalties like the career cup.
    const f = cont.knockout.fixtures[0];
    assert(f && f.status === 'pending', 'no pending final');
    const isPlayer = f.home === career.playerClubId || f.away === career.playerClubId;
    if (isPlayer && deferPlayer) {
      return { results, playerResult: null, deferredFixture: f, champion: null, deferred: true };
    }
    const home = careerTeamBundle(career, f.home);
    const away = careerTeamBundle(career, f.away);
    const result = simulateMatch({
      home,
      away,
      seed: `${career.seed}:continental:s${cont.season}:${f.id}`,
      knockout: true,
    });
    applyContinentalFinalResult(f, result);
    results.push({ fixtureId: f.id, home: f.home, away: f.away, score: result.score, winner: f.winner });
    if (isPlayer) {
      playerResult = {
        fixture: { ...f },
        result,
        report: buildMatchReport(result, { tactics: { home: home.tactics, away: away.tactics } }),
      };
    }
    cont.champion = f.winner;
    cont.runnerUp = f.winner === f.home ? f.away : f.home;
    cont.status = 'complete';
  }
  return { results, playerResult, champion: cont.champion };
}

/** Apply a group-stage result to a fixture (shared by instant + live). */
export function applyContinentalGroupResult(f, result) {
  f.homeScore = result.score.home;
  f.awayScore = result.score.away;
  f.status = 'played';
  return f;
}

/** Apply the final result to a fixture (shared by instant + live). */
export function applyContinentalFinalResult(f, result) {
  assert(result.winner === 'home' || result.winner === 'away', 'final must produce a winner');
  f.homeScore = result.score.home;
  f.awayScore = result.score.away;
  f.winner = result.winner === 'home' ? f.home : f.away;
  f.status = 'played';
  return f;
}

/** Group complete -> top 2 to the final (extracted for live completion). */
export function progressContinentalGroup(career, cont) {
  if (cont.group.fixtures.every((f) => f.status === 'played')) {
    const table = continentalStandings(career, cont);
    const [first, second] = table;
    cont.knockout.fixtures = [{
      id: `cont-s${cont.season}-final`,
      round: 'Final',
      home: first.clubId,
      away: second.clubId,
      status: 'pending',
      homeScore: null,
      awayScore: null,
      winner: null,
    }];
    cont.status = 'knockout';
  }
  return cont;
}

/**
 * Complete a deferred (live) continental fixture. Applies the live result,
 * then runs group progression / finalization. Idempotent per fixture.
 * Phase 38.
 */
export function completeContinentalFixture(career, fixtureId, result) {
  const cont = ensureContinental(career);
  assert(cont, 'no continental competition');
  const isGroup = cont.status === 'group';
  const fixtures = isGroup ? cont.group.fixtures : cont.knockout.fixtures;
  const f = fixtures.find((x) => x.id === fixtureId);
  if (!f) throw new Error('continental fixture not found');
  if (f.status === 'played') {
    const playerSide = f.home === career.playerClubId ? 'home' : 'away';
    return {
      playerResult: {
        fixture: { ...f },
        result,
        report: buildMatchReport(result, {
          tactics: { [playerSide]: career.clubs[career.playerClubId].tactics },
        }),
      },
      champion: cont.champion ?? null,
      alreadyCompleted: true,
    };
  }
  if (isGroup) {
    applyContinentalGroupResult(f, result);
    progressContinentalGroup(career, cont);
  } else {
    applyContinentalFinalResult(f, result);
    cont.champion = f.winner;
    cont.runnerUp = f.winner === f.home ? f.away : f.home;
    cont.status = 'complete';
  }
  const isPlayer = f.home === career.playerClubId || f.away === career.playerClubId;
  // Phase 51: report from the authoritative live result; player's own
  // configured tactics (synced) for their side only.
  const playerSide = f.home === career.playerClubId ? 'home' : 'away';
  const report = buildMatchReport(result, {
    tactics: { [playerSide]: career.clubs[career.playerClubId].tactics },
  });
  return {
    playerResult: isPlayer ? { fixture: { ...f }, result, report } : null,
    champion: cont.champion ?? null,
    alreadyCompleted: false,
  };
}

/**
 * Pay the one-time qualification reward when the player's club qualifies.
 * Idempotent via cont.qualificationPaid. Also fires the qualification activity
 * and milestone check. Returns the amount paid (0 when not qualified).
 */
export function awardQualificationReward(career, cfg) {
  const cont = career.continental;
  if (!cont || cont.qualificationPaid) return 0;
  cont.qualificationPaid = true;
  if (!cont.qualifiers.includes(career.playerClubId)) return 0;
  const amount = cfg.continentalRewards?.qualification ?? 0;
  const club = career.clubs[career.playerClubId].club;
  if (amount > 0) {
    recordTransaction(club, {
      type: 'continental_prize',
      amount,
      description: `Continental Champions qualification (Season ${cont.season})`,
    });
  }
  pushActivity(career, cfg, {
    kind: 'continental',
    key: `continental:s${cont.season}:qualified`,
    text: `Qualified for the Continental Champions (Season ${cont.season})!`,
  });
  notify(career, `🌍 You qualified for the Continental Champions (Season ${cont.season})!`);
  const unlocked = checkMilestones(career, cfg);
  applyMilestoneRewards(career, unlocked);
  return amount;
}

/** Public-safe continental view. Names only, no economy internals. */
export function continentalView(career) {  const cont = ensureContinental(career);
  if (!cont) {
    return {
      competition: COMP_NAME,
      qualified: false,
      season: career.season,
      message: 'Finish in the league top 4 to qualify for the Continental Champions.',
      history: career.continentalHistory.slice().reverse(),
    };
  }
  const nameOf = (id) => career.clubs[id]?.club.name ?? '?';
  const table = continentalStandings(career, cont).map((r) => ({ ...r, name: nameOf(r.clubId) }));
  const fx = (f) => ({
    id: f.id,
    matchday: f.matchday ?? null,
    round: f.round ?? null,
    home: nameOf(f.home),
    away: nameOf(f.away),
    homeScore: f.homeScore,
    awayScore: f.awayScore,
    winner: f.winner ? nameOf(f.winner) : null,
    status: f.status,
    involvesPlayer: f.home === career.playerClubId || f.away === career.playerClubId,
  });
  const pf = playerContinentalFixture(career);
  return {
    competition: COMP_NAME,
    qualified: true,
    playerQualified: cont.qualifiers.includes(career.playerClubId),
    season: cont.season,
    status: cont.status,
    champion: cont.champion ? nameOf(cont.champion) : null,
    playerRun: playerContinentalRun(career, cont),
    group: { name: cont.group.name, table, fixtures: cont.group.fixtures.map(fx) },
    knockout: cont.knockout.fixtures.map(fx),
    playerFixture: pf ? {
      id: pf.id,
      round: cont.status === 'group' ? `Matchday ${pf.matchday}` : 'Final',
      home: nameOf(pf.home),
      away: nameOf(pf.away),
    } : null,
    history: career.continentalHistory.slice().reverse(),
  };
}
