// Season engine: advance matchdays, season rollover.
import { createRng } from '../core/rng.js';
import { simulateMatch } from '../match/engine.js';
import { buildMatchReport } from '../match/report.js';
import {
  applyFixtureResult,
  getStandings,
  getTopScorers,
  applySeasonEnd,
  createLeague,
} from '../competition/league.js';
import { careerTeamBundle, notify } from './career.js';
import { processWeek, processMatchday, awardPrizeMoney } from '../finance/finance.js';
import { applyDailyRecovery } from '../staff/effects.js';
import { tickContracts, getExpiring } from '../contracts/contracts.js';
import { reviewBoard, newSeasonBoard, generateSeasonExpectations } from '../club/board.js';
import { ageOneYear } from '../players/progression.js';
import { youthIntake } from '../youth/youth.js';
import { removePlayer, registerPlayer } from '../squad/squad.js';
import { ensureCup } from '../cup/career.js';
import { qualifyContinental, awardQualificationReward } from '../continental/career.js';
import { loadConfig } from '../core/config.js';

const liveopsCfgSeason = loadConfig('liveops');

function entryPlayers(career, clubId) {
  return career.clubs[clubId].squad.players.map((id) => career.players[id]);
}

/**
 * Play the next matchday for the whole league.
 * Returns { matchday, playerResult, results }.
 * playerResult is the full match-engine result of the player's fixture
 * (null if the player has a bye).
 *
 * Phase 38: with { deferPlayer: true }, the player's fixture is NOT simulated.
 * AI fixtures are simulated + applied, the player's gate income is still
 * processed (keeping rng order identical), and the player's fixture is
 * returned as `deferredFixture` for a live match. The matchday is completed
 * via completeLiveMatchday() once the live match finishes.
 */
export function advanceMatchday(career, opts = {}) {
  const deferPlayer = !!opts.deferPlayer;
  const league = career.league;
  const md = league.currentMatchday + 1;
  const fixtures = league.fixtures.filter((f) => f.matchday === md);
  const rng = createRng(`${career.seed}:season:${career.season}`);

  let playerResult = null;
  let playerReport = null;
  let deferredFixture = null;
  const results = [];
  for (const fixture of fixtures) {
    const isPlayer = fixture.home === career.playerClubId || fixture.away === career.playerClubId;
    if (isPlayer && deferPlayer) {
      // Gate income now (rng draw stays in the same position as the
      // instant path); the match itself is deferred to a live match.
      const entry = career.clubs[fixture.home];
      const attendance = Math.round(
        4000 + entry.club.reputation * 120 + rng.int(-500, 1500)
      );
      processMatchday(entry.club, entry.facilities, attendance);
      deferredFixture = fixture;
      continue;
    }
    const home = careerTeamBundle(career, fixture.home);
    const away = careerTeamBundle(career, fixture.away);
    const result = simulateMatch({
      home,
      away,
      seed: `${career.seed}:s${career.season}:m${md}:${fixture.home}v${fixture.away}`,
    });
    applyFixtureResult(league, fixture, result);
    results.push({ fixture, score: result.score, winner: result.winner });
    if (isPlayer) {
      playerResult = result;
      // Phase 50: deterministic report projection (read-only, no gameplay).
      // Both bundles' configured tactics are known here (career only).
      playerReport = buildMatchReport(result, {
        tactics: { home: home.tactics, away: away.tactics },
      });
    }
    // Home gate income.
    const entry = career.clubs[fixture.home];
    const attendance = Math.round(
      4000 + entry.club.reputation * 120 + rng.int(-500, 1500)
    );
    processMatchday(entry.club, entry.facilities, attendance);
  }

  if (deferPlayer) {
    // The matchday is NOT advanced yet; weekly economy, recovery, AI
    // transfers and the season-end check run in completeLiveMatchday().
    return { matchday: md, playerResult: null, results, deferredFixture, deferred: true };
  }

  league.currentMatchday = md;

  // Weekly economy + recovery for the player's club.
  const pc = career.clubs[career.playerClubId];
  const week = processWeek(pc.club, {
    players: entryPlayers(career, career.playerClubId),
    staffRoster: pc.staff,
  });
  applyDailyRecovery(entryPlayers(career, career.playerClubId), pc.staff, rng, pc.facilities);

  // AI transfer activity: maybe buy the player's listed players.
  aiTransferActivity(career, rng);

  let seasonEnd = null;
  if (!league.fixtures.some((f) => f.matchday > md)) {
    league.complete = true;
    seasonEnd = endSeason(career, rng);
  }
  return { matchday: md, playerResult, playerReport, results, week, seasonEnd };
}

/**
 * Complete a deferred (live) league matchday. Applies the live match result
 * to the player's fixture, then runs the weekly economy, recovery, AI
 * transfers and season-end check — the same steps advanceMatchday performs
 * after simulating. Idempotent: if already completed for this matchday,
 * returns { alreadyCompleted: true } without re-applying.
 * Phase 38.
 */
export function completeLiveMatchday(career, result, matchday = null) {
  const league = career.league;
  const md = matchday ?? league.currentMatchday + 1;
  // Phase 51: report from the authoritative live result. Player's own
  // configured tactics (synced from the live match) for their side only;
  // opponent behavior stays observed-only.
  const playerSideOf = (fx) => (fx.home === career.playerClubId ? 'home' : 'away');
  const liveReport = (fx) => buildMatchReport(result, {
    tactics: { [playerSideOf(fx)]: career.clubs[career.playerClubId].tactics },
  });
  if (league.liveCompletedMatchday === md) {
    const fx = league.fixtures.find((f) => f.matchday === md
      && (f.home === career.playerClubId || f.away === career.playerClubId));
    return { matchday: md, playerResult: result, playerReport: fx ? liveReport(fx) : null, results: [], week: null, seasonEnd: null, alreadyCompleted: true };
  }
  // Guard: don't complete a matchday that was already advanced past.
  if (md <= league.currentMatchday) {
    const fx = league.fixtures.find((f) => f.matchday === md
      && (f.home === career.playerClubId || f.away === career.playerClubId));
    return { matchday: md, playerResult: result, playerReport: fx ? liveReport(fx) : null, results: [], week: null, seasonEnd: null, alreadyCompleted: true };
  }
  const fixture = league.fixtures.find((f) => f.matchday === md
    && (f.home === career.playerClubId || f.away === career.playerClubId));
  if (!fixture) throw new Error('no deferred player fixture for this matchday');

  applyFixtureResult(league, fixture, result);
  const results = [{ fixture, score: result.score, winner: result.winner }];

  // Weekly economy + recovery for the player's club (same as advanceMatchday).
  const rng = createRng(`${career.seed}:season:${career.season}:live`);
  const pc = career.clubs[career.playerClubId];
  const week = processWeek(pc.club, {
    players: entryPlayers(career, career.playerClubId),
    staffRoster: pc.staff,
  });
  applyDailyRecovery(entryPlayers(career, career.playerClubId), pc.staff, rng, pc.facilities);
  aiTransferActivity(career, rng);

  league.currentMatchday = md;
  league.liveCompletedMatchday = md;

  let seasonEnd = null;
  if (!league.fixtures.some((f) => f.matchday > md)) {
    league.complete = true;
    seasonEnd = endSeason(career, rng);
  }
  return { matchday: md, playerResult: result, playerReport: liveReport(fixture), results, week, seasonEnd };
}

function aiTransferActivity(career, rng) {
  const market = career.market;
  if (!market.windowOpen) return;
  const playerClubId = career.playerClubId;
  for (const listing of market.listings.values()) {
    if (listing.status !== 'active' || listing.sellerClubId !== playerClubId) continue;
    if (!rng.chance(0.12)) continue;
    // An AI club meets the asking price.
    const buyers = Object.values(career.clubs).filter(
      (c) => !c.isPlayer && c.club.cash >= listing.askingPrice
    );
    if (buyers.length === 0) continue;
    const buyerEntry = rng.pick(buyers);
    const player = career.players[listing.playerId];
    buyerEntry.club.cash -= listing.askingPrice;
    career.clubs[playerClubId].club.cash += listing.askingPrice;
    removePlayer(career.clubs[playerClubId].squad, player.id);
    registerPlayer(buyerEntry.squad, player.id);
    player.wage = Math.round(player.wage * 1.2);
    player.contract = { ...player.contract, salary: player.wage };
    listing.status = 'sold';
    market.history.push({
      playerId: player.id,
      playerName: player.name,
      fromClubId: playerClubId,
      toClubId: buyerEntry.club.id,
      fee: listing.askingPrice,
      wage: player.wage,
      years: 3,
      at: Date.now(),
    });
    notify(career, `${buyerEntry.club.name} bought ${player.name} for ${listing.askingPrice.toLocaleString()}.`);
  }
}

function endSeason(career, rng) {
  const league = career.league;
  const standings = getStandings(league);
  const playerRow = standings.find((r) => r.clubId === career.playerClubId);
  const position = standings.indexOf(playerRow) + 1;

  // Prize money + board review for the player.
  const prize = awardPrizeMoney(career.clubs[career.playerClubId].club, 'league', position);
  const pc = career.clubs[career.playerClubId];
  const review = reviewBoard(pc.board, { finalPosition: position });

  // Promotion/relegation flavor (single league: level/reputation shifts).
  const clubsById = new Map(
    Object.values(career.clubs).map((c) => [c.club.id, { club: c.club }])
  );
  const movement = applySeasonEnd(league, clubsById, { promote: 2, relegate: 2 });

  // Age, contracts, youth intake for the player club.
  const allPlayers = Object.values(career.players);
  for (const p of allPlayers) ageOneYear(p, rng);
  const expiredCount = tickContracts(allPlayers).length;
  const expiring = getExpiring(entryPlayers(career, career.playerClubId)).length;
  const playersById = new Map(Object.entries(career.players));
  const intake = youthIntake({
    academy: pc.academy,
    club: pc.club,
    facilities: pc.facilities,
    rng,
    playersById,
  });
  for (const p of intake) career.players[p.id] = p;

  notify(career, `Season ${career.season} over: you finished ${position}${ordinal(position)}. Prize: ${prize.toLocaleString()}.`);

  // Phase 32: lightweight season history for the season presentation screen.
  career.seasonHistory = career.seasonHistory ?? [];
  career.seasonHistory.push({
    season: career.season,
    position,
    played: playerRow.played ?? 0,
    won: playerRow.won ?? 0,
    drawn: playerRow.drawn ?? 0,
    lost: playerRow.lost ?? 0,
    points: playerRow.points ?? 0,
    goalsFor: playerRow.gf ?? 0,
    prize,
  });
  if (review.status === 'sacked') {
    notify(career, 'The board has SACKED you. Start a new career to continue.');
  } else {
    notify(career, `Board confidence: ${review.confidence}% (${review.status}). ${expiredCount} contracts expired, ${expiring} expiring, ${intake.length} youth prospects arrived.`);
  }

  // New season.
  career.season += 1;
  newSeasonBoard(pc.board);
  generateSeasonExpectations(pc.board, pc.club);
  career.league = createLeague({
    name: 'Liga Nusantara',
    clubs: Object.values(career.clubs).map((c) => ({ id: c.club.id })),
    season: career.season,
  });

  // Phase 36: archive the old cup, start a fresh cup for the new season.
  ensureCup(career);

  // Phase 37: qualify the top 4 of the completed league season for the new
  // season's Continental Champions; pay the one-time qualification reward.
  qualifyContinental(career, standings, career.season);
  awardQualificationReward(career, liveopsCfgSeason);

  return { position, prize, review, movement, intake: intake.length, gameOver: review.status === 'sacked' };
}

function ordinal(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return (s[(v - 20) % 10] || s[v] || s[0]);
}

export function getTable(career) {
  return getStandings(career.league);
}

export function getScorers(career, limit = 10) {
  return getTopScorers(career.league, limit);
}
