// Career: the game world. Everything is plain JSON (no Maps) so the
// whole career serializes for the save system (Phase 19).
import { createRng } from '../core/rng.js';
import { newId } from '../core/ids.js';
import { createClub } from '../club/club.js';
import { createBoard, generateSeasonExpectations } from '../club/board.js';
import { generatePlayer } from '../players/player.js';
import { createSquad, registerPlayer, setLineup } from '../squad/squad.js';
import { createTactics } from '../tactics/tactics.js';
import { createStaffRoster } from '../staff/staff.js';
import { createFacilities } from '../facilities/facilities.js';
import { createYouthAcademy } from '../youth/youth.js';
import { createTransferMarket } from '../transfer/market.js';
import { createLeague } from '../competition/league.js';

// Fictional clubs. All original, no real-world likeness.
const AI_CLUB_NAMES = [
  'Garuda Sakti FC',
  'Nusantara United',
  'Samudra Biru FC',
  'Khatulistiwa FC',
  'Cendrawasih FC',
  'Komodo Dragons',
  'Borneo Timur FC',
  'Sriwijaya Muda',
  'Maluku Pearl FC',
  'Toraja Highland',
];

const AI_SQUAD_TEMPLATE = [
  'GK', 'GK',
  'DL', 'DC', 'DC', 'DR', 'DL', 'DC',
  'ML', 'MC', 'MC', 'MR', 'MC',
  'ST', 'ST', 'ST', 'ML', 'MR',
];

function makeClubEntry(rng, name, { isPlayer = false, overallRange = [58, 72] } = {}) {
  const club = createClub({ name, level: 3, reputation: isPlayer ? 55 : 40 + rng.int(0, 30) });
  const squad = createSquad(club.id);
  const playerObjs = AI_SQUAD_TEMPLATE.map((position) =>
    generatePlayer(rng, { position, ageRange: [19, 33], overallRange })
  );
  for (const p of playerObjs) registerPlayer(squad, p.id);
  autoPickLineup(playerObjs, squad);
  return {
    club,
    squad,
    playerObjs, // full objects; moved to career.players at finalize
    tactics: createTactics(),
    staff: createStaffRoster(),
    facilities: createFacilities(),
    academy: createYouthAcademy(),
    board: createBoard(),
    isPlayer,
  };
}

/** Best GK + 10 best outfielders by overall. */
export function autoPickLineup(playerObjs, squad) {
  const sorted = [...playerObjs].sort((a, b) => b.overall - a.overall);
  const gk = sorted.find((p) => p.position === 'GK') ?? sorted[0];
  const rest = sorted.filter((p) => p.position !== 'GK' && p.id !== gk.id).slice(0, 10);
  const xi = [gk.id, ...rest.map((p) => p.id)];
  // Fallback: fill short XI with anyone remaining (thin squads).
  for (const p of sorted) {
    if (xi.length >= 11) break;
    if (!xi.includes(p.id)) xi.push(p.id);
  }
  setLineup(squad, xi);
  return squad;
}

export function createCareer({ clubName, seed = null } = {}) {
  if (!clubName || !clubName.trim()) throw new Error('clubName required');
  const careerSeed = seed ?? `career-${Date.now().toString(36)}`;
  const rng = createRng(careerSeed);

  const playerEntry = makeClubEntry(rng, clubName.trim(), { isPlayer: true, overallRange: [62, 74] });
  generateSeasonExpectations(playerEntry.board, playerEntry.club);

  const aiNames = [...AI_CLUB_NAMES].sort(() => rng.float() - 0.5).slice(0, 7);
  const aiEntries = aiNames.map((name) => makeClubEntry(rng, name));

  const clubs = {};
  const players = {};
  for (const entry of [playerEntry, ...aiEntries]) {
    const { playerObjs, ...rest } = entry;
    clubs[entry.club.id] = rest;
    for (const p of playerObjs) players[p.id] = p;
  }

  const league = createLeague({
    name: 'Liga Nusantara',
    clubs: Object.values(clubs).map((c) => ({ id: c.club.id })),
    season: 1,
  });

  return {
    id: newId('career'),
    seed: careerSeed,
    season: 1,
    playerClubId: playerEntry.club.id,
    clubs,
    players,
    league,
    market: createTransferMarket({ windowOpen: true }),
    scouts: [],
    notifications: [
      { id: newId('notif'), text: 'Welcome to Rise of Champions! Check your squad and play matchday 1.', at: Date.now() },
    ],
    createdAt: Date.now(),
  };
}

/** Team bundle for the match engine: { name, players, bench, tactics }. */
export function careerTeamBundle(career, clubId) {
  const entry = career.clubs[clubId];
  if (entry.squad.lineup.length !== 11) {
    autoPickLineup(entry.squad.players.map((id) => career.players[id]), entry.squad);
  }
  return {
    name: entry.club.name,
    players: entry.squad.lineup.map((id) => career.players[id]),
    bench: entry.squad.bench.map((id) => career.players[id]),
    tactics: entry.tactics,
  };
}

export function notify(career, text) {
  career.notifications.unshift({ id: newId('notif'), text, at: Date.now() });
  career.notifications = career.notifications.slice(0, 50);
  return career;
}
