// Objectives (Phase 32) — DOMAIN module. Pure logic: data-driven daily/weekly
// objectives with period-scoped progress. Progress is derived server-side from
// career stats via a per-period baseline snapshot — the client never submits
// progress. Claims are idempotent. No HTTP, no DOM, no DB.
import { assert } from '../core/validate.js';

const DAY = 86400000;

/** Period key: 'YYYY-MM-DD' for daily, Monday 'YYYY-MM-DD' for weekly. */
export function periodKey(period, now = Date.now()) {
  const d = new Date(now);
  if (period === 'daily') return d.toISOString().slice(0, 10);
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dow = (monday.getUTCDay() + 6) % 7; // Mon=0
  monday.setUTCDate(monday.getUTCDate() - dow);
  return monday.toISOString().slice(0, 10);
}

export function periodEnd(period, now = Date.now()) {
  const d = new Date(now);
  if (period === 'daily') {
    return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) + DAY;
  }
  const monday = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const dow = (monday.getUTCDay() + 6) % 7;
  monday.setUTCDate(monday.getUTCDate() - dow + 7);
  return monday.getTime();
}

/** Metric values read from a career (server-derived). */
export function metricValues(career) {
  const s = career?.stats ?? {};
  return {
    matches_played: s.played ?? 0,
    matches_won: s.wins ?? 0,
    goals_scored: s.goalsFor ?? 0,
    trainings_done: s.trainings ?? 0,
    transfers_done: s.signings ?? 0,
    facilities_upgraded: s.facilitiesUpgraded ?? 0,
  };
}

function blankPeriod() {
  return { key: null, baseline: {}, items: {} };
}

/**
 * Ensure the user's period state is current. On period rollover the baseline
 * snapshots current metric values so progress measures only this period.
 * state: { [userId]: { daily, weekly } } (mutated). Returns the period state.
 */
export function ensurePeriod(state, userId, period, metrics, now = Date.now()) {
  const key = periodKey(period, now);
  let user = state[userId];
  if (!user) user = state[userId] = { daily: blankPeriod(), weekly: blankPeriod() };
  let ps = user[period];
  if (!ps || ps.key !== key) {
    ps = user[period] = { key, baseline: { ...metrics }, items: {} };
  }
  return ps;
}

export function objectiveProgress(def, ps, metrics) {
  const base = ps.baseline[def.metric] ?? 0;
  const cur = metrics[def.metric] ?? 0;
  return Math.min(def.target, Math.max(0, cur - base));
}

export function objectiveView(def, ps, metrics) {
  const item = ps.items[def.id] ?? {};
  const progress = objectiveProgress(def, ps, metrics);
  return {
    id: def.id,
    title: def.title,
    desc: def.desc,
    metric: def.metric,
    target: def.target,
    cash: def.cash,
    progress,
    completed: progress >= def.target,
    claimed: !!item.claimed,
  };
}

/**
 * Claim a completed objective. Idempotent: throws if not completed or already
 * claimed. Returns the definition (caller pays the reward + grants XP).
 */
export function claimObjective(defs, ps, objId, metrics) {
  const def = defs.find((d) => d.id === objId);
  assert(def, `unknown objective: ${objId}`);
  const progress = objectiveProgress(def, ps, metrics);
  assert(progress >= def.target, 'objective not completed yet');
  const item = ps.items[def.id] ?? (ps.items[def.id] = {});
  assert(!item.claimed, 'objective already claimed');
  item.claimed = true;
  item.claimedAt = Date.now();
  return def;
}
