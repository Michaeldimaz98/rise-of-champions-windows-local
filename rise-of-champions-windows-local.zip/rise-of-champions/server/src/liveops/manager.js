// Manager progression + reward track (Phase 32) — DOMAIN module. Pure logic:
// XP ledger, level thresholds, level-up detection, free reward track claims.
// XP is granted only from server-validated events; levels only increase.
// No HTTP, no DOM, no DB.
import { assert } from '../core/validate.js';

export function blankManager() {
  return { xp: 0, level: 1, history: [], trackClaimed: {} };
}

export function levelForXp(cfg, xp) {
  let level = 1;
  for (const l of cfg.managerLevels) {
    if (xp >= l.xpRequired) level = l.level;
  }
  return level;
}

export function xpForNextLevel(cfg, xp) {
  for (const l of cfg.managerLevels) {
    if (xp < l.xpRequired) return { level: l.level, xpRequired: l.xpRequired };
  }
  return null; // max level
}

/**
 * Grant XP. Returns { xp, level, leveledUp: [newLevels] }.
 * Caller pays level rewards + sends inbox (idempotent: level only rises).
 */
export function grantXp(mgr, cfg, amount, source, now = Date.now()) {
  assert(Number.isFinite(amount) && amount > 0, 'xp amount must be positive');
  const before = levelForXp(cfg, mgr.xp);
  mgr.xp += Math.round(amount);
  const after = levelForXp(cfg, mgr.xp);
  const leveledUp = [];
  for (let l = before + 1; l <= after; l++) leveledUp.push(l);
  mgr.level = after;
  mgr.history.unshift({ at: now, source, amount: Math.round(amount) });
  mgr.history = mgr.history.slice(0, 20);
  return { xp: mgr.xp, level: mgr.level, leveledUp };
}

export function trackView(cfg, mgr) {
  return cfg.rewardTrack.map((t) => ({
    level: t.level,
    xpRequired: t.xpRequired,
    cash: t.cash,
    reached: mgr.xp >= t.xpRequired,
    claimed: !!mgr.trackClaimed[t.level],
  }));
}

/** Claim one reward-track level. Idempotent. Returns the track def. */
export function claimTrackLevel(cfg, mgr, level) {
  const def = cfg.rewardTrack.find((t) => t.level === level);
  assert(def, `unknown track level: ${level}`);
  assert(mgr.xp >= def.xpRequired, 'track level not reached yet');
  assert(!mgr.trackClaimed[level], 'track reward already claimed');
  mgr.trackClaimed[level] = Date.now();
  return def;
}
