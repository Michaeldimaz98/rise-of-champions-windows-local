// Live-ops persistence (Phase 32).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FILES = {
  objectives: path.resolve(__dirname, '../../data/objectives.json'),
  manager: path.resolve(__dirname, '../../data/manager.json'),
  inbox: path.resolve(__dirname, '../../data/inbox.json'),
};

export const objectiveState = {}; // userId -> { daily, weekly }
export const managerState = {}; // userId -> { xp, level, history, trackClaimed }
export const inboxState = {}; // userId -> [messages]

function loadInto(file, target) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    for (const [k, v] of Object.entries(raw)) target[k] = v;
    return Object.keys(target).length;
  } catch {
    return 0;
  }
}

function persistTo(file, target) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(target));
  fs.renameSync(tmp, file);
}

export function loadLiveops() {
  loadInto(FILES.objectives, objectiveState);
  loadInto(FILES.manager, managerState);
  loadInto(FILES.inbox, inboxState);
}

export function persistObjectives() { persistTo(FILES.objectives, objectiveState); }
export function persistManager() { persistTo(FILES.manager, managerState); }
export function persistInbox() { persistTo(FILES.inbox, inboxState); }
