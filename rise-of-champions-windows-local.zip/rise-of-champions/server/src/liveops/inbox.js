// Inbox (Phase 32) — DOMAIN module. Pure logic: persistent per-account message
// list with read state, types, and expiry. One user's messages are only ever
// touched via their own userId. No HTTP, no DOM, no DB.
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';

const MAX_MESSAGES = 100;

export function sendInbox(state, userId, { type, title, body, expiresDays = 30 }, now = Date.now()) {
  assert(type && title, 'inbox message needs type and title');
  let list = state[userId];
  if (!list) list = state[userId] = [];
  pruneExpired(list, now);
  list.unshift({
    id: newId('msg'),
    type,
    title,
    body: body ?? '',
    at: now,
    read: false,
    expiresAt: now + expiresDays * 86400000,
  });
  if (list.length > MAX_MESSAGES) list.length = MAX_MESSAGES;
  return list[0];
}

export function pruneExpired(list, now = Date.now()) {
  for (let i = list.length - 1; i >= 0; i--) {
    if (list[i].expiresAt <= now) list.splice(i, 1);
  }
  return list;
}

export function listInbox(state, userId, now = Date.now()) {
  const list = state[userId] ?? [];
  pruneExpired(list, now);
  return {
    messages: list.map((m) => ({ ...m })),
    unreadCount: list.filter((m) => !m.read).length,
  };
}

export function markRead(state, userId, msgId) {
  const list = state[userId] ?? [];
  const msg = list.find((m) => m.id === msgId);
  assert(msg, 'message not found');
  msg.read = true;
  return msg;
}

export function markAllRead(state, userId) {
  const list = state[userId] ?? [];
  let n = 0;
  for (const m of list) if (!m.read) { m.read = true; n++; }
  return n;
}
