// Shop / monetization (Phase 25) — DOMAIN module. Pure logic: product catalog,
// orders, entitlements (VIP + boosts), and grant application. No HTTP, no DOM.
// Payment charging is delegated to a provider (mock by default).
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';
import { recordTransaction } from '../finance/finance.js';
import { notify } from '../career/career.js';

const DAY = 86400000;

export function getProduct(cfg, productId) {
  const p = cfg.products.find((x) => x.id === productId);
  assert(p, `unknown product: ${productId}`);
  return p;
}

/** Entitlements shape: { vipUntil: ts|null, boosts: { training_xp: ts } } */
export function blankEntitlements() {
  return { vipUntil: null, boosts: {} };
}

export function vipActive(ent, now = Date.now()) {
  return !!ent && !!ent.vipUntil && ent.vipUntil > now;
}

export function boostActive(ent, boostId, now = Date.now()) {
  return !!ent && !!ent.boosts && (ent.boosts[boostId] ?? 0) > now;
}

/** Effective training XP multiplier from VIP + active boosts. */
export function trainingXpMult(ent, cfg, now = Date.now()) {
  let mult = 1;
  if (vipActive(ent, now)) {
    const vip = cfg.products.find((p) => p.type === 'vip');
    mult *= vip?.vipXpMult ?? 1;
  }
  if (boostActive(ent, 'training_xp', now)) {
    const b = cfg.products.find((p) => p.type === 'boost' && p.boostId === 'training_xp');
    mult *= b?.mult ?? 1;
  }
  return mult;
}

export function vipDailyBonus(ent, cfg, now = Date.now()) {
  if (!vipActive(ent, now)) return 0;
  const vip = cfg.products.find((p) => p.type === 'vip');
  return vip?.vipDailyBonus ?? 0;
}

export function createOrder({ userId, username, productId }, cfg, now = Date.now()) {
  const p = getProduct(cfg, productId);
  return {
    id: newId('ord'),
    userId,
    username,
    productId: p.id,
    productName: p.name,
    amountIdr: p.priceIdr,
    status: 'pending', // pending -> completed | failed
    txId: null,
    createdAt: now,
  };
}

/**
 * Apply a paid order's grant. Idempotent: throws unless status is 'pending'.
 * ctx: { getCareer(userId)->career|null, getEnt()->ent, now }.
 * Career is required for cash/heal grants; VIP/boost are account-level.
 */
export function completeOrder(order, product, ctx) {
  assert(order.status === 'pending', `order ${order.id} already ${order.status}`);
  const now = ctx.now ?? Date.now();
  const granted = { productId: product.id, type: product.type };

  if (product.type === 'vip') {
    const ent = ctx.getEnt();
    ent.vipUntil = Math.max(now, ent.vipUntil ?? 0) + product.days * DAY;
    granted.until = ent.vipUntil;
    ctx.saveEnt(ent);
  } else if (product.type === 'boost') {
    const ent = ctx.getEnt();
    ent.boosts[product.boostId] = Math.max(now, ent.boosts[product.boostId] ?? 0) + product.days * DAY;
    granted.until = ent.boosts[product.boostId];
    ctx.saveEnt(ent);
  } else if (product.type === 'cash' || product.type === 'heal') {
    const career = ctx.getCareer(order.userId);
    assert(career, 'create a career first to use this product');
    if (product.type === 'cash') {
      const club = career.clubs[career.playerClubId].club;
      recordTransaction(club, {
        type: 'shop_purchase',
        amount: product.cash,
        description: `Shop: ${product.name}`,
      });
      granted.cash = product.cash;
      notify(career, `🛒 ${product.name}: +${product.cash.toLocaleString()} cash.`);
    } else {
      let healed = 0;
      for (const pid of Object.keys(career.players)) {
        const pl = career.players[pid];
        if (pl.injury) { pl.injury = null; healed++; }
      }
      granted.healed = healed;
      notify(career, `🛒 ${product.name}: ${healed} player(s) healed.`);
    }
    ctx.saveCareer(career);
  } else {
    throw new Error(`unsupported product type: ${product.type}`);
  }

  order.status = 'completed';
  order.completedAt = now;
  return granted;
}

export function publicEntitlements(ent, cfg, now = Date.now()) {
  const e = ent ?? blankEntitlements();
  return {
    vip: vipActive(e, now),
    vipUntil: e.vipUntil,
    boosts: Object.fromEntries(
      Object.entries(e.boosts ?? {})
        .filter(([, until]) => until > now)
        .map(([id, until]) => [id, until])
    ),
    trainingXpMult: trainingXpMult(e, cfg, now),
  };
}
