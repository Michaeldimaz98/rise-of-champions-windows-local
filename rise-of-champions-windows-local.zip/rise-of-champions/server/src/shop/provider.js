// Payment provider (Phase 25).
// MOCK implementation: every charge succeeds instantly. No real money moves.
// To go live, replace `charge` with a real PSP adapter (Xendit/Midtrans/Stripe)
// behind the same interface: charge(order) -> { ok, txId } | throws.
// The shop domain never touches money directly; only completed orders grant.
export async function charge(order) {
  return {
    ok: true,
    txId: `mock_${order.id}_${Date.now().toString(36)}`,
    chargedAt: Date.now(),
    provider: 'mock',
  };
}
