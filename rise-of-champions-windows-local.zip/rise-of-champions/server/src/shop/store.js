// Shop persistence: orders and entitlements.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ORDERS_FILE = path.resolve(__dirname, '../../data/orders.json');
const ENT_FILE = path.resolve(__dirname, '../../data/entitlements.json');

export const orders = new Map(); // orderId -> order
export const entitlements = new Map(); // userId -> entitlements

function loadFile(file, map) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    for (const [k, v] of Object.entries(raw)) map.set(k, v);
    return map.size;
  } catch {
    return 0;
  }
}

function persistFile(file, map) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(map)));
  fs.renameSync(tmp, file);
}

export function loadShop() {
  loadFile(ORDERS_FILE, orders);
  loadFile(ENT_FILE, entitlements);
  return { orders: orders.size, entitlements: entitlements.size };
}

export function persistOrders() {
  persistFile(ORDERS_FILE, orders);
}

export function persistEntitlements() {
  persistFile(ENT_FILE, entitlements);
}
