// Reminder dedupe (Phase 33) — DOMAIN module. Pure logic: idempotent,
// server-time-based reminder keys. Same key is never sent twice (per account).
// Keys expire after a TTL so the store stays bounded. No HTTP, no DOM, no DB.
import { assert } from '../core/validate.js';

export const REMINDER_TTL_MS = 90 * 86400000; // 90 days

/** userState: { [key]: sentAt } */
export function reminderDue(userState, key, now = Date.now()) {
  assert(key, 'reminder key required');
  pruneReminders(userState, now);
  return !(userState[key] > 0);
}

export function markReminder(userState, key, now = Date.now()) {
  assert(key, 'reminder key required');
  userState[key] = now;
  pruneReminders(userState, now);
  return userState;
}

export function pruneReminders(userState, now = Date.now()) {
  for (const [k, at] of Object.entries(userState)) {
    if (now - at > REMINDER_TTL_MS) delete userState[k];
  }
  return userState;
}

/** Reminder key builders — deterministic, season/event/account scoped. */
export const seasonEndingKey = (seasonNumber, userId, windowH) =>
  `ranked-season-${seasonNumber}-ending-${windowH}h-${userId}`;
export const eventEndingKey = (eventId, userId) => `event-${eventId}-ending-${userId}`;
export const eventSettledKey = (eventId, userId) => `event-${eventId}-settled-${userId}`;

/** True when `endsAt` is within `windowMs` in the future (server time). */
export function withinWindow(endsAt, windowMs, now = Date.now()) {
  return endsAt > now && endsAt - now <= windowMs;
}
