// Season/reminder persistence (Phase 33).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FILE = path.resolve(__dirname, '../../data/reminders.json');

export const reminderState = {}; // userId -> { [key]: sentAt }

export function loadReminders() {
  try {
    const raw = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    for (const [k, v] of Object.entries(raw)) reminderState[k] = v;
    return Object.keys(reminderState).length;
  } catch {
    return 0;
  }
}

export function persistReminders() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(reminderState));
  fs.renameSync(tmp, FILE);
}
