// Seasonal competition (Phase 33) — DOMAIN module. Pure logic for ranked-PvP
// season finalization: verify, snapshot standings, pay tier rewards (via the
// existing rolloverSeason domain function), record history, notify.
// Idempotent: finalizedSeasons guard makes repeat/concurrent calls safe.
// No HTTP, no DOM, no DB.
import { assert } from '../core/validate.js';
import { seasonEnded, rolloverSeason, tierFor } from '../pvp/competitive.js';

const MAX_HISTORY = 12;

/** Final standings snapshot, rank 1..N, only managers who played >= 1 match. */
export function snapshotStandings(state) {
  return Object.entries(state.ratings ?? {})
    .map(([userId, e]) => ({
      userId,
      username: e.username ?? '?',
      rating: e.rating,
      tier: tierFor(e.rating),
      w: e.w ?? 0,
      d: e.d ?? 0,
      l: e.l ?? 0,
    }))
    .filter((r) => r.w + r.d + r.l > 0)
    .sort((a, b) => b.rating - a.rating)
    .map((r, i) => ({ rank: i + 1, ...r }));
}

export function isFinalized(state, seasonNumber) {
  return !!(state.finalizedSeasons ?? {})[seasonNumber];
}

/**
 * Finalize a ranked season. deps:
 *   getCareer(userId) -> career|null
 *   applyReward(career, amount, text)
 *   notifyUser(userId, {type,title,body})  — inbox
 *   now
 * Returns { season, standings, rewards }. Safe to call repeatedly.
 */
export function finalizeRankedSeason(state, seasonNumber, deps) {
  const { getCareer, applyReward, notifyUser, now = Date.now() } = deps;
  assert(!isFinalized(state, seasonNumber), 'season already finalized');
  assert(state.season && state.season.number === seasonNumber, 'unknown season');
  assert(seasonEnded(state), 'season has not ended yet');

  const standings = snapshotStandings(state);
  // Existing domain rollover: pays tier rewards, soft-resets ratings,
  // advances the season. Synchronous => atomic in the Node event loop.
  const rewards = rolloverSeason(state, { getCareer, applyReward });

  state.finalizedSeasons = state.finalizedSeasons ?? {};
  state.finalizedSeasons[seasonNumber] = now;
  state.seasonHistory = state.seasonHistory ?? [];
  state.seasonHistory.unshift({
    season: seasonNumber,
    endedAt: now,
    standings,
    rewards: rewards.map((r) => ({ userId: r.userId, tier: r.tier, amount: r.amount })),
  });
  if (state.seasonHistory.length > MAX_HISTORY) state.seasonHistory.length = MAX_HISTORY;

  const byUser = new Map(rewards.map((r) => [r.userId, r]));
  for (const s of standings) {
    const r = byUser.get(s.userId);
    notifyUser(s.userId, {
      type: 'season',
      title: `Ranked Season ${seasonNumber} complete`,
      body: r
        ? `Final rank #${s.rank} (${s.tier}, ${s.rating} rating). Reward: +${r.amount.toLocaleString()} cash.`
        : `Final rank #${s.rank} (${s.tier}, ${s.rating} rating).`,
    });
  }
  // New-season notice to everyone who participated.
  for (const s of standings) {
    notifyUser(s.userId, {
      type: 'season',
      title: `Ranked Season ${state.season.number} has begun`,
      body: 'Ratings soft-reset. Climb the leaderboard for new tier rewards.',
    });
  }
  return { season: seasonNumber, standings, rewards };
}

/** Standings for a season: live state for current, snapshot for past seasons. */
export function seasonStandings(state, seasonNumber) {
  if (state.season && state.season.number === seasonNumber) return snapshotStandings(state);
  const h = (state.seasonHistory ?? []).find((x) => x.season === seasonNumber);
  assert(h, 'unknown season');
  return h.standings;
}

/** One account's result in a past season (private view). */
export function mySeasonResult(state, seasonNumber, userId) {
  const h = (state.seasonHistory ?? []).find((x) => x.season === seasonNumber);
  if (!h) return null;
  const row = h.standings.find((s) => s.userId === userId) ?? null;
  const reward = h.rewards.find((r) => r.userId === userId) ?? null;
  return row ? { ...row, rewardAmount: reward ? reward.amount : 0, endedAt: h.endedAt } : null;
}
