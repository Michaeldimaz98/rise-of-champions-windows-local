// Live competition adapters (Phase 38).
// Each competition exposes start (defer the player's fixture, resolve the
// rest of the world) and finish (apply the live result). The live match
// itself is competition-agnostic (server/src/live/match.js).
//
// Phase 39b: ranked is no longer a live competition. Ranked uses the sealed
// tactical duel model (pvp/sealed.js) — async and symmetric.
import { advanceMatchday, completeLiveMatchday } from '../career/season.js';
import { ensureCup, playCupRound, completeCupTie } from '../cup/career.js';
import { playContinental, completeContinentalFixture } from '../continental/career.js';
import { careerTeamBundle } from '../career/career.js';
import { startLive, hasActiveLive } from './match.js';

const COMPETITIONS = ['league', 'cup', 'continental'];

export function isLiveCompetition(c) {
  return COMPETITIONS.includes(c);
}

/**
 * Start a live match for the player's next fixture in `competition`.
 * Performs the competition's world side effects (AI fixtures) and defers
 * the player's fixture to the live match.
 */
export function startLiveCompetition(career, competition, deps = {}) {
  if (!isLiveCompetition(competition)) throw new Error(`unknown competition: ${competition}`);
  if (hasActiveLive(career)) {
    throw new Error('a live match is already in progress — finish or abandon it first');
  }
  switch (competition) {
    case 'league': {
      const out = advanceMatchday(career, { deferPlayer: true });
      const fx = out.deferredFixture;
      if (!fx) throw new Error('no league fixture to play live');
      const playerSide = fx.home === career.playerClubId ? 'home' : 'away';
      startLive(career, {
        competition: 'league',
        home: careerTeamBundle(career, fx.home),
        away: careerTeamBundle(career, fx.away),
        seed: `${career.seed}:s${career.season}:m${out.matchday}:${fx.home}v${fx.away}`,
        knockout: false,
        playerSide,
        playerClubId: career.playerClubId,
        meta: { matchday: out.matchday, home: fx.home, away: fx.away },
      });
      return { competition, matchday: out.matchday };
    }
    case 'cup': {
      ensureCup(career);
      const out = playCupRound(career, { deferPlayer: true });
      const fx = out.deferredFixture;
      if (!fx) throw new Error('no cup tie to play live');
      const playerSide = fx.home === career.playerClubId ? 'home' : 'away';
      startLive(career, {
        competition: 'cup',
        home: careerTeamBundle(career, fx.home),
        away: careerTeamBundle(career, fx.away),
        seed: `${career.seed}:cup:s${career.season}:${fx.id}`,
        knockout: true,
        playerSide,
        playerClubId: career.playerClubId,
        meta: { fixtureId: fx.id, round: fx.round },
      });
      return { competition };
    }
    case 'continental': {
      const out = playContinental(career, { deferPlayer: true });
      const fx = out.deferredFixture;
      if (!fx) throw new Error('no continental fixture to play live');
      const isFinal = fx.round === 'Final';
      const playerSide = fx.home === career.playerClubId ? 'home' : 'away';
      startLive(career, {
        competition: 'continental',
        home: careerTeamBundle(career, fx.home),
        away: careerTeamBundle(career, fx.away),
        seed: `${career.seed}:continental:s${career.season}:${fx.id}`,
        knockout: isFinal,
        playerSide,
        playerClubId: career.playerClubId,
        meta: { fixtureId: fx.id, isFinal },
      });
      return { competition };
    }
    default:
      throw new Error(`unknown competition: ${competition}`);
  }
}

/**
 * Apply a finished live match result to its competition.
 * Idempotent per competition (safe to retry after an interrupted finish).
 */
export function finishLiveCompetition(career, result, deps = {}) {
  const lm = career.liveMatch;
  if (!lm || !lm.finished || !result) throw new Error('no finished live match to complete');
  const meta = lm.meta ?? {};
  switch (lm.competition) {
    case 'league':
      return { competition: 'league', out: completeLiveMatchday(career, result, meta.matchday ?? null) };
    case 'cup':
      return { competition: 'cup', out: completeCupTie(career, meta.fixtureId, result) };
    case 'continental':
      return { competition: 'continental', out: completeContinentalFixture(career, meta.fixtureId, result) };
    default:
      throw new Error(`unknown competition: ${lm.competition}`);
  }
}
