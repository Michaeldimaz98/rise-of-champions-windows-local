// Live Match Management (Phase 38).
//
// A control layer over the resumable match engine (server/src/match/engine.js).
// The engine remains the sole simulation source of truth; this module adds:
//   - lifecycle (ready -> live -> halftime -> live -> fulltime, + ET/shootout)
//   - 15-minute segments (continue)
//   - manager commands: tactics, formation, substitution, player instruction
//   - persistence (snapshot on career.liveMatch + in-memory context)
// Server-authoritative: the client only sends commands; score/events/winner
// are derived server-side by the engine.
import {
  createMatch,
  emitKickoff,
  playMatchSegment,
  applyHalftimeBreak,
  emitExtraTime,
  applyExtraTimeBreak,
  playShootout,
  emitFulltime,
  finalizeMatch,
  snapshotMatch,
  restoreMatch,
  recalcTeamEff,
} from '../match/engine.js';
import { setTactic, setFormation, setPlayerInstruction, ORDER_KEYS, FLAG_KEYS } from '../tactics/tactics.js';
import { loadConfig } from '../core/config.js';

const MAX_SUBS = loadConfig('match').live?.maxSubs ?? 5;

// In-memory live contexts (career.id -> ctx). Survives across requests in the
// same process; the snapshot on career.liveMatch survives server restarts.
const contexts = new Map();

export function maxSubs() {
  return MAX_SUBS;
}

/** Field-by-field migration for career.liveMatch (never clobbers). */
export function ensureLiveMatch(career) {
  if (!career.liveMatch) return null;
  const lm = career.liveMatch;
  if (lm.subsUsed == null) lm.subsUsed = 0;
  if (lm.finished == null) lm.finished = false;
  if (!lm.phase) lm.phase = 'ready';
  if (lm.minute == null) lm.minute = 0;
  return lm;
}

export function hasActiveLive(career) {
  const lm = ensureLiveMatch(career);
  return !!lm && !lm.finished && lm.phase !== 'fulltime';
}

/**
 * Ensure the manager has bench options for live substitutions.
 * If the bench is empty, fill it from reserves (up to 7) and persist to
 * the squad — so live and instant paths see the same bench (deterministic).
 */
export function ensureLiveBench(career, bundle, clubId) {
  if (bundle.bench.length > 0) return bundle;
  const entry = career.clubs[clubId];
  if (!entry) return bundle;
  const used = new Set([...bundle.players.map((p) => p.id)]);
  const reserves = entry.squad.players
    .map((id) => career.players[id])
    .filter((p) => p && !used.has(p.id) && !p.injury && p.fitness > 0)
    .slice(0, 7);
  bundle.bench = reserves;
  entry.squad.bench = reserves.map((p) => p.id);
  return bundle;
}

/**
 * Start a live match. opts:
 *   competition: 'league' | 'cup' | 'continental' | 'ranked'
 *   home, away: team bundles ({ name, players, bench, tactics })
 *   seed, knockout
 *   playerSide: 'home' | 'away'
 *   playerClubId: career club entry id (null for ranked? no — ranked has it)
 *   meta: competition-specific finish data (plain JSON)
 *   oppBundle: for ranked — persisted opponent snapshot { players, bench, tactics, name }
 */
export function startLive(career, opts) {
  if (hasActiveLive(career)) {
    throw new Error('a live match is already in progress — finish or abandon it first');
  }
  // Ensure the manager has bench options (auto-fill from reserves if empty).
  if (opts.playerClubId) {
    const playerBundle = opts.playerSide === 'home' ? opts.home : opts.away;
    ensureLiveBench(career, playerBundle, opts.playerClubId);
  }
  const m = createMatch({ home: opts.home, away: opts.away, seed: opts.seed, knockout: !!opts.knockout });
  emitKickoff(m);

  const record = {
    id: `live-${career.id}-${Date.now()}`,
    competition: opts.competition,
    season: career.season,
    playerSide: opts.playerSide,
    playerClubId: opts.playerClubId ?? null,
    knockout: !!opts.knockout,
    phase: 'ready',
    minute: 0,
    subsUsed: 0,
    finished: false,
    meta: opts.meta ?? {},
    oppBundle: opts.oppBundle ?? null,
    engine: snapshotMatch(m),
  };
  career.liveMatch = record;
  const ctx = { career, m, record };
  contexts.set(career.id, ctx);
  syncTacticsToCareer(ctx);
  return ctx;
}

function getPlayerResolver(ctx) {
  const career = ctx.career;
  const oppPlayers = new Map();
  if (ctx.record.oppBundle) {
    for (const p of [...ctx.record.oppBundle.players, ...ctx.record.oppBundle.bench]) {
      oppPlayers.set(p.id, p);
    }
  }
  const oppSide = ctx.record.playerSide === 'home' ? 'away' : 'home';
  return (side, id) => {
    if (ctx.record.oppBundle && side === oppSide) return oppPlayers.get(id) ?? null;
    return career.players[id] ?? null;
  };
}

/** Get the live context, restoring from snapshot if needed (server restart). */
export function getLiveContext(career) {
  const record = ensureLiveMatch(career);
  if (!record || record.finished) return null;
  let ctx = contexts.get(career.id);
  if (ctx && ctx.record === record) return ctx;
  // Restore from snapshot.
  const m = restoreMatch(record.engine, getPlayerResolver({ career, record }));
  ctx = { career, m, record };
  contexts.set(career.id, ctx);
  syncTacticsToCareer(ctx);
  return ctx;
}

/** Drop the in-memory context (after finish/abandon). */
export function clearLiveContext(careerId) {
  contexts.delete(careerId);
}

function managerTeam(ctx) {
  return ctx.record.playerSide === 'home' ? ctx.m.H : ctx.m.A;
}

function managerSideTag(ctx) {
  return ctx.record.playerSide;
}

/** Keep the career's stored tactics in sync with live changes. */
function syncTacticsToCareer(ctx) {
  const { career, record } = ctx;
  if (!record.playerClubId) return;
  const entry = career.clubs[record.playerClubId];
  if (!entry) return;
  entry.tactics = managerTeam(ctx).tactics;
}

function persist(ctx) {
  ctx.record.engine = snapshotMatch(ctx.m);
}

function assertCanCommand(ctx) {
  const phase = ctx.record.phase;
  if (phase === 'fulltime' || ctx.record.finished) {
    const e = new Error('match is fulltime — commands rejected');
    e.code = 'MATCH_FULLTIME';
    throw e;
  }
}

// ---------------------------------------------------------------------------
// Segments
// ---------------------------------------------------------------------------

function finishLive(ctx) {
  const m = ctx.m;
  if (!m.winner) {
    m.winner = m.scoreH === m.scoreA ? 'draw' : m.scoreH > m.scoreA ? 'home' : 'away';
  }
  emitFulltime(m);
  const before = ctx.record.engine.events.length;
  const result = finalizeMatch(m);
  ctx.record.phase = 'fulltime';
  ctx.record.minute = 121;
  ctx.record.finished = true;
  ctx.record.result = result; // stored for the /finish step (retry-safe)
  persist(ctx);
  const newEvents = m.events.slice(before);
  return { view: liveView(ctx), newEvents, finished: true, result };
}

/**
 * Advance one segment. Returns { view, newEvents, finished, result? }.
 * When finished, result is the engine MatchResult (finalize runs once).
 */
export function continueLive(career) {
  const ctx = getLiveContext(career);
  if (!ctx) throw new Error('no active live match');
  assertCanCommand(ctx);
  const m = ctx.m;
  const rec = ctx.record;
  const before = m.events.length;

  if (rec.phase === 'ready') {
    playMatchSegment(m, 1, 15);
    rec.minute = 15;
    rec.phase = 'live';
  } else if (rec.phase === 'halftime') {
    playMatchSegment(m, 46, 60);
    rec.minute = 60;
    rec.phase = 'live';
  } else if (rec.phase === 'et_break') {
    playMatchSegment(m, 91, 105);
    applyExtraTimeBreak(m);
    rec.minute = 105;
    rec.phase = 'live';
  } else if (rec.phase === 'shootout') {
    playShootout(m);
    rec.minute = 121;
    return finishLive(ctx);
  } else if (rec.phase === 'live') {
    if (rec.minute === 15) {
      playMatchSegment(m, 16, 30);
      rec.minute = 30;
    } else if (rec.minute === 30) {
      playMatchSegment(m, 31, 45);
      applyHalftimeBreak(m);
      rec.minute = 45;
      rec.phase = 'halftime';
    } else if (rec.minute === 60) {
      playMatchSegment(m, 61, 75);
      rec.minute = 75;
    } else if (rec.minute === 75) {
      playMatchSegment(m, 76, 90);
      rec.minute = 90;
      if (m.knockout && m.scoreH === m.scoreA) {
        emitExtraTime(m);
        rec.phase = 'et_break';
      } else {
        return finishLive(ctx);
      }
    } else if (rec.minute === 105) {
      playMatchSegment(m, 106, 120);
      rec.minute = 120;
      if (m.scoreH === m.scoreA) {
        rec.phase = 'shootout';
      } else {
        return finishLive(ctx);
      }
    } else {
      throw new Error(`invalid live minute ${rec.minute}`);
    }
  } else {
    throw new Error(`invalid live phase ${rec.phase}`);
  }

  persist(ctx);
  const newEvents = m.events.slice(before);
  return { view: liveView(ctx), newEvents, finished: false };
}

/**
 * Abandon: fast-forward the remainder instantly from the current state,
 * then finish normally. Never leaves a fixture unresolved.
 */
export function abandonLive(career) {
  const ctx = getLiveContext(career);
  if (!ctx) throw new Error('no active live match');
  assertCanCommand(ctx);
  const m = ctx.m;
  const rec = ctx.record;
  // Fast-forward from the current position using the same segment path.
  while (rec.phase !== 'fulltime') {
    const out = continueLive(career);
    if (out.finished) return out;
  }
  throw new Error('unreachable');
}

// ---------------------------------------------------------------------------
// Manager commands
// ---------------------------------------------------------------------------

const TACTIC_KEYS = [...ORDER_KEYS, ...FLAG_KEYS];

/**
 * Change tactics live. patch: { mentality: 'Attacking', pressing: 'High', ... }.
 * Validated via setTactic (config-driven); recomputes team effectiveness.
 */
export function applyTactics(career, patch) {
  const ctx = getLiveContext(career);
  if (!ctx) throw new Error('no active live match');
  assertCanCommand(ctx);
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) {
    throw new Error('invalid tactics patch');
  }
  const team = managerTeam(ctx);
  const applied = {};
  for (const [key, value] of Object.entries(patch)) {
    if (!TACTIC_KEYS.includes(key)) throw new Error(`unknown tactic key: ${key}`);
    setTactic(team.tactics, key, value); // throws on invalid value
    applied[key] = value;
  }
  if (Object.keys(applied).length === 0) throw new Error('empty tactics patch');
  recalcTeamEff(team);
  syncTacticsToCareer(ctx);
  persist(ctx);
  return { view: liveView(ctx), applied };
}

/** Change formation live (validated name; recomputes effectiveness). */
export function applyFormation(career, formation) {
  const ctx = getLiveContext(career);
  if (!ctx) throw new Error('no active live match');
  assertCanCommand(ctx);
  if (typeof formation !== 'string' || !formation) throw new Error('invalid formation');
  const team = managerTeam(ctx);
  setFormation(team.tactics, formation); // throws on unknown
  recalcTeamEff(team);
  syncTacticsToCareer(ctx);
  persist(ctx);
  return { view: liveView(ctx), formation };
}

/**
 * Live substitution. Validates ownership (both players must belong to the
 * manager's side), field/bench status, sub limit, and player availability.
 */
export function applySubstitution(career, { playerOut, playerIn }) {
  const ctx = getLiveContext(career);
  if (!ctx) throw new Error('no active live match');
  assertCanCommand(ctx);
  if (!playerOut || !playerIn) throw new Error('playerOut and playerIn required');
  if (playerOut === playerIn) throw new Error('cannot substitute a player for themselves');
  if (ctx.record.subsUsed >= MAX_SUBS) {
    const e = new Error(`substitution limit reached (${MAX_SUBS})`);
    e.code = 'SUB_LIMIT';
    throw e;
  }
  const team = managerTeam(ctx);
  const side = managerSideTag(ctx);
  const outP = team.players.find((p) => p.id === playerOut);
  const inP = team.bench.find((p) => p.id === playerIn);
  if (!outP) {
    const e = new Error('playerOut is not on the field (or not your player)');
    e.code = 'INVALID_SUB';
    throw e;
  }
  if (!inP) {
    const e = new Error('playerIn is not on your bench');
    e.code = 'INVALID_SUB';
    throw e;
  }
  // Ownership: both must resolve to the manager's club players (or ranked self).
  // The team arrays only ever contain the manager's players, but verify
  // against the career to reject forged cross-club ids.
  if (ctx.record.oppBundle) {
    // Ranked: manager's players are the career's; opponent is the snapshot.
    if (!ctx.career.players[outP.id] || !ctx.career.players[inP.id]) {
      const e = new Error('substitution players must be your own');
      e.code = 'INVALID_SUB';
      throw e;
    }
  } else {
    const clubId = ctx.record.playerClubId;
    const entry = ctx.career.clubs[clubId];
    const squadIds = new Set([...entry.squad.players, ...entry.squad.lineup, ...entry.squad.bench]);
    if (!squadIds.has(outP.id) || !squadIds.has(inP.id)) {
      const e = new Error('substitution players must be your own');
      e.code = 'INVALID_SUB';
      throw e;
    }
  }
  if (inP.injury || !(inP.fitness > 0)) {
    const e = new Error('playerIn is not available (injured/unfit)');
    e.code = 'INVALID_SUB';
    throw e;
  }

  team.players = team.players.map((p) => (p.id === outP.id ? inP : p));
  team.bench = team.bench.filter((p) => p.id !== inP.id);
  if (!ctx.m.ratings.has(inP.id)) {
    ctx.m.ratings.set(inP.id, { rating: 6.5, goals: 0, assists: 0, player: inP });
    ctx.m.minutes.set(inP.id, 0);
  }
  ctx.record.subsUsed += 1;
  // Emit a sub event at the current minute.
  const m = ctx.m;
  const before = m.events.length;
  const ev = {
    minute: ctx.record.minute,
    type: 'sub',
    team: side,
    playerId: inP.id,
    playerName: inP.name,
    detail: `${inP.name} replaces ${outP.name} (manager substitution)`,
  };
  m.events.push(ev);
  recalcTeamEff(team);
  persist(ctx);
  return { view: liveView(ctx), newEvents: m.events.slice(before), subsUsed: ctx.record.subsUsed };
}

/**
 * Per-player instruction ('red' = attacking, 'blue' = defensive, null = clear).
 * Stored on tactics; validated to the manager's own players.
 */
export function applyInstruction(career, { playerId, arrow }) {
  const ctx = getLiveContext(career);
  if (!ctx) throw new Error('no active live match');
  assertCanCommand(ctx);
  if (!playerId) throw new Error('playerId required');
  const team = managerTeam(ctx);
  const owned = team.players.some((p) => p.id === playerId) || team.bench.some((p) => p.id === playerId);
  if (!owned) throw new Error('not your player');
  setPlayerInstruction(team.tactics, playerId, arrow ?? null); // throws on invalid arrow
  syncTacticsToCareer(ctx);
  persist(ctx);
  return { view: liveView(ctx), playerId, arrow: arrow ?? null };
}

// ---------------------------------------------------------------------------
// Views
// ---------------------------------------------------------------------------

function teamLineupView(ctx, team, tag) {
  const slots = team.players.map((p) => {
    const r = ctx.m.ratings.get(p.id);
    return {
      id: p.id, name: p.name, position: p.position,
      rating: r ? Math.round(r.rating * 10) / 10 : 6.5,
      goals: r?.goals ?? 0,
      yellow: (ctx.m.yellows.get(p.id) ?? 0) > 0,
      injured: !!p.injury,
    };
  });
  const bench = team.bench.map((p) => ({
    id: p.id, name: p.name, position: p.position, injured: !!p.injury, fitness: Math.round(p.fitness ?? 0),
  }));
  return {
    name: team.name, tag,
    tactics: { ...team.tactics },
    lineup: slots,
    bench,
  };
}

/** Public-safe live state (no hidden data, no opponent internals beyond XI). */
export function liveView(ctxOrCareer) {
  const ctx = ctxOrCareer?.m ? ctxOrCareer : getLiveContext(ctxOrCareer);
  if (!ctx) return { active: false };
  const m = ctx.m;
  const rec = ctx.record;
  const totalPoss = m.stats.home.possession + m.stats.away.possession || 1;
  return {
    active: true,
    id: rec.id,
    competition: rec.competition,
    season: rec.season,
    phase: rec.phase,
    minute: rec.minute,
    knockout: rec.knockout,
    playerSide: rec.playerSide,
    score: { home: m.scoreH, away: m.scoreA },
    momentum: Math.round(m.momentum),
    subsUsed: rec.subsUsed,
    subsRemaining: MAX_SUBS - rec.subsUsed,
    maxSubs: MAX_SUBS,
    home: teamLineupView(ctx, m.H, 'home'),
    away: teamLineupView(ctx, m.A, 'away'),
    events: m.events,
    stats: {
      home: { ...m.stats.home, possession: Math.round((m.stats.home.possession / totalPoss) * 100) },
      away: { ...m.stats.away, possession: Math.round((m.stats.away.possession / totalPoss) * 100) },
    },
    penalties: m.penalties,
    winner: m.winner,
    finished: rec.finished,
  };
}

export { TACTIC_KEYS };
