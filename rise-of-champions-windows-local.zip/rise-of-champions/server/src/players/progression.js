// Player progression: XP -> attribute growth, aging, decline, retirement.
// Growth is capped by potential (never unlimited) and scaled by age,
// morale, and headroom. All functions mutate the player and return it.
import { loadConfig } from '../core/config.js';
import { getPlayerDefs, allAttributes, calcOverall, groupForPosition } from './attributes.js';

let cfg = null;
function getCfg() {
  if (!cfg) cfg = loadConfig('progression');
  return cfg;
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function band(value, bands) {
  const hit = bands.find(([lo, hi]) => value >= lo && value <= hi);
  return hit ? hit[2] : 1;
}

function weightedPick(rng, weights) {
  const entries = Object.entries(weights);
  let total = 0;
  for (const [, w] of entries) total += w;
  let roll = rng.float() * total;
  for (const [attr, w] of entries) {
    roll -= w;
    if (roll <= 0) return attr;
  }
  return entries[entries.length - 1][0];
}

/**
 * Apply raw growth points: distributed to attributes weighted by the
 * player's position group (or `weightsOverride`, e.g. a training drill's
 * target attributes). Returns the number of attribute points applied.
 */
export function applyGrowth(player, points, rng, weightsOverride = null) {
  let remaining = Math.floor(points);
  if (rng.chance(points - remaining)) remaining += 1;
  const weights =
    weightsOverride ??
    getPlayerDefs().overallWeights[groupForPosition(player.position)];
  let applied = 0;
  let guard = 0;
  while (remaining > 0 && guard++ < 1000) {
    const attr = weightedPick(rng, weights);
    if (player.attributes[attr] < 99) {
      player.attributes[attr] += 1;
      remaining -= 1;
      applied += 1;
    }
  }
  player.overall = calcOverall(player.attributes, player.position);
  return applied;
}

/**
 * Give XP (from training or matches). Growth slows as overall approaches
 * potential and with age; high morale boosts it. `weights` optionally
 * overrides the attribute distribution (training drills). Returns points applied.
 */
export function gainXp(player, xp, { quality = 1, rng, weights = null } = {}) {
  if (!rng) throw new Error('gainXp requires rng');
  const c = getCfg();
  player.experience += Math.max(0, Math.round(xp));
  const headroom = clamp((player.potential - player.overall) / 20, 0, 1);
  if (headroom <= 0) return 0;
  const ageF = band(player.age, c.ageFactorBands);
  const moraleF = 0.7 + (player.morale / 100) * 0.6;
  const points = xp * c.trainingXpToPoints * quality * ageF * moraleF * headroom;
  return applyGrowth(player, points, rng, weights);
}

/** Retirement roll for the player's current age. */
export function maybeRetire(player, rng) {
  const c = getCfg();
  const [minAge, maxAge] = c.retirementAge;
  if (player.age < minAge) return false;
  if (player.age >= maxAge) return true;
  return rng.chance(c.retirementChance[String(player.age)] ?? 0.5);
}

function applyDecline(player, rng) {
  const c = getCfg();
  const physical = getPlayerDefs().attributes.physical;
  const [lo, hi] = c.decline.physicalPerYear;
  for (const a of physical) {
    player.attributes[a] = Math.max(1, player.attributes[a] - rng.int(lo, hi));
  }
  for (const a of allAttributes()) {
    if (physical.includes(a)) continue;
    if (rng.chance(c.decline.otherChance)) {
      player.attributes[a] = Math.max(1, player.attributes[a] - 1);
    }
  }
  player.overall = calcOverall(player.attributes, player.position);
}

/**
 * Age the player one year (season rollover). Returns true if retired.
 * Physical decline starts at decline.startAge.
 */
export function ageOneYear(player, rng) {
  player.age += 1;
  if (maybeRetire(player, rng)) return true;
  if (player.age >= getCfg().decline.startAge) applyDecline(player, rng);
  return false;
}
