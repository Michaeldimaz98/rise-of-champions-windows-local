// Player condition dynamics: fitness, morale, form, injuries.
// Pure functions that mutate the player and return it.
import { loadConfig } from '../core/config.js';
import { checkIntRange } from '../core/validate.js';

let cfg = null;
function getCfg() {
  if (!cfg) cfg = loadConfig('progression');
  return cfg;
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

/** Fitness cost of playing minutes; high stamina reduces the cost. */
export function applyMatchLoad(player, minutes) {
  const c = getCfg();
  const staminaMod = 1.2 - player.attributes.Stamina / 250; // 0.8..1.16
  const cost = minutes * c.matchFitnessCost * staminaMod;
  player.fitness = clamp(Math.round(player.fitness - cost), 0, 100);
  return player;
}

/** Recover fitness by resting. ~6% per 3 hours like the genre standard. */
export function rest(player, hours) {
  player.fitness = clamp(
    Math.round(player.fitness + hours * getCfg().restPerHour),
    0,
    100
  );
  return player;
}

export function adjustMorale(player, delta) {
  player.morale = clamp(Math.round(player.morale + delta), 0, 100);
  return player;
}

/** Rolling form: rating 1..10 nudges the 0..100 form value. */
export function updateForm(player, rating) {
  const r = checkIntRange(rating, 1, 10, 'rating');
  const norm = ((r - 1) / 9) * 100;
  player.form = clamp(Math.round(player.form * 0.7 + norm * 0.3), 0, 100);
  return player;
}

export function applyInjury(player, type, days) {
  player.injury = { type, daysLeft: Math.max(1, Math.round(days)) };
  return player;
}

/** Advance injury recovery by one day; clears when healed. */
export function tickInjury(player) {
  if (!player.injury) return player;
  player.injury.daysLeft -= 1;
  if (player.injury.daysLeft <= 0) player.injury = null;
  return player;
}
