// Attribute definitions & overall calculation. Weights live in
// config/players.json (data-driven); code normalizes them so the config
// never needs perfect sums.
import { loadConfig } from '../core/config.js';

let defs = null;

export function getPlayerDefs() {
  if (!defs) defs = loadConfig('players');
  return defs;
}

export function allAttributes() {
  const a = getPlayerDefs().attributes;
  return [...a.technical, ...a.mental, ...a.physical, ...a.goalkeeper];
}

export function groupForPosition(position) {
  const groups = getPlayerDefs().positionGroups;
  for (const [group, positions] of Object.entries(groups)) {
    if (positions.includes(position)) return group;
  }
  throw new Error(`unknown position: ${position}`);
}

/** Weighted overall (1-99) for a position group. Missing attrs default to 50. */
export function calcOverall(attributes, position) {
  const group = groupForPosition(position);
  const weights = getPlayerDefs().overallWeights[group];
  let sum = 0;
  let wsum = 0;
  for (const [attr, w] of Object.entries(weights)) {
    sum += (attributes[attr] ?? 50) * w;
    wsum += w;
  }
  const raw = wsum > 0 ? sum / wsum : 50;
  return Math.max(1, Math.min(99, Math.round(raw)));
}

/** Attribute map with every attribute set to `value`. */
export function blankAttributes(value = 50) {
  const out = {};
  for (const a of allAttributes()) out[a] = value;
  return out;
}
