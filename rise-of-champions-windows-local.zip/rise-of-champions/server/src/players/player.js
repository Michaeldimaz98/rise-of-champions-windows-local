// Player entity: factory, fictional generation, market value.
// All balancing coefficients come from config/players.json.
import { loadConfig } from '../core/config.js';
import { newId } from '../core/ids.js';
import {
  ValidationError,
  assert,
  checkIntRange,
  checkName,
  isOneOf,
} from '../core/validate.js';
import {
  getPlayerDefs,
  allAttributes,
  blankAttributes,
  calcOverall,
} from './attributes.js';

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

export function createPlayer(data = {}) {
  const defs = getPlayerDefs();

  const name = checkName(data.name, 'player name');
  const position = data.position;
  assert(isOneOf(position, defs.positions), `unknown position: ${position}`);

  const [ageMin, ageMax] = defs.ageRange;
  const age = checkIntRange(data.age ?? 22, ageMin, ageMax, 'age');

  const attributes = { ...blankAttributes(), ...(data.attributes ?? {}) };
  for (const a of allAttributes()) {
    attributes[a] = checkIntRange(attributes[a], 1, 99, `attribute ${a}`);
  }

  // Overall is ALWAYS derived from attributes — never passed in — so the
  // invariant overall == calcOverall(attributes, position) always holds.
  const overall = calcOverall(attributes, position);
  const potential = checkIntRange(
    data.potential ?? overall,
    overall,
    99,
    'potential'
  );

  const personality = data.personality ?? 'Professional';
  assert(
    isOneOf(personality, defs.personalities),
    `unknown personality: ${personality}`
  );

  const wage =
    data.wage ?? playerWage({ overall, potential, age });

  return {
    id: data.id ?? newId('player'),
    name,
    age,
    nationality: data.nationality ?? 'Indonesian',
    position,
    attributes,
    overall,
    potential,
    morale: checkIntRange(data.morale ?? 70, 0, 100, 'morale'),
    fitness: checkIntRange(data.fitness ?? 100, 0, 100, 'fitness'),
    form: checkIntRange(data.form ?? 50, 0, 100, 'form'),
    chemistry: checkIntRange(data.chemistry ?? 50, 0, 100, 'chemistry'),
    injury: data.injury ?? null, // null | { type, daysLeft }
    experience: checkIntRange(data.experience ?? 0, 0, 9999, 'experience'),
    personality,
    wage,
    contract: {
      yearsLeft: data.contract?.yearsLeft ?? 3,
      salary: data.contract?.salary ?? wage,
      signingBonus: data.contract?.signingBonus ?? 0,
      releaseClause: data.contract?.releaseClause ?? null,
      role: data.contract?.role ?? 'Squad Player',
    },
  };
}

/**
 * Generate a fictional player using a seeded RNG.
 * opts: { position, nationality, age | ageRange, overall | overallRange }
 */
export function generatePlayer(rng, opts = {}) {
  const defs = getPlayerDefs();
  const names = loadConfig('names');

  const position = opts.position ?? rng.pick(defs.positions);
  const nationality =
    opts.nationality ?? rng.pick(Object.keys(names));
  const pool = names[nationality] ?? names.English;
  const name = `${rng.pick(pool.first)} ${rng.pick(pool.last)}`;

  const age =
    opts.age ?? rng.int(...(opts.ageRange ?? [18, 34]));
  const targetOverall =
    opts.overall ?? rng.int(...(opts.overallRange ?? [55, 80]));

  const attributes = {};
  for (const a of allAttributes()) {
    attributes[a] = clamp(Math.round(targetOverall + rng.int(-8, 8)), 1, 99);
  }
  const overall = calcOverall(attributes, position);
  const potBonus =
    age <= 21 ? rng.int(5, 18) : age <= 25 ? rng.int(2, 10) : rng.int(0, 4);
  const potential = clamp(overall + potBonus, overall, 99);

  return createPlayer({
    name,
    age,
    nationality,
    position,
    attributes,
    potential,
    personality: rng.pick(defs.personalities),
  });
}

/** Market value in cash. Exponential in overall; young high-potential players cost more. */
export function playerValue(player) {
  const defs = getPlayerDefs();
  const { scale, growth } = defs.marketValue;
  const base = scale * Math.exp(growth * player.overall);
  const band = defs.ageMultiplierBands.find(
    ([lo, hi]) => player.age >= lo && player.age <= hi
  );
  const ageMult = band ? band[2] : 0.5;
  const potMult =
    1 + Math.max(0, player.potential - player.overall) / 100;
  return Math.round(base * ageMult * potMult);
}

/** Weekly wage derived from market value (tunable via config). */
export function playerWage(player) {
  const defs = getPlayerDefs();
  return Math.max(100, Math.round(playerValue(player) * defs.marketValue.salaryRate));
}

export { ValidationError };
