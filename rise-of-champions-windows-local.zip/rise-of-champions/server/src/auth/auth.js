// Auth: user accounts with scrypt password hashing + bearer sessions.
// Persisted to server/data/users.json so accounts survive restarts.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
let DATA_FILE = path.resolve(__dirname, '../../data/users.json');

/** Test hook: point the store at a temp file. */
export function setAuthDataFile(p) {
  DATA_FILE = p;
  store = null;
}

const SESSION_TTL_MS = 30 * 24 * 3600 * 1000;

let store = null;
function getStore() {
  if (store) return store;
  try {
    store = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch {
    store = { users: {}, byName: {}, sessions: {} };
  }
  return store;
}

function persist() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(getStore()));
  fs.renameSync(tmp, DATA_FILE);
}

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function checkUsername(username) {
  assert(typeof username === 'string', 'username required');
  const u = username.trim();
  assert(/^[a-zA-Z0-9_]{3,20}$/.test(u), 'username must be 3-20 chars (letters, numbers, _)');
  return u;
}

export function registerUser({ username, password }) {
  const name = checkUsername(username);
  assert(typeof password === 'string' && password.length >= 6 && password.length <= 128,
    'password must be 6-128 chars');
  const s = getStore();
  const key = name.toLowerCase();
  assert(!s.byName[key], 'username already taken');
  const salt = crypto.randomBytes(16).toString('hex');
  const user = {
    id: newId('user'),
    username: name,
    salt,
    hash: hashPassword(password, salt),
    createdAt: Date.now(),
  };
  s.users[user.id] = user;
  s.byName[key] = user.id;
  persist();
  return publicUser(user);
}

export function loginUser({ username, password }) {
  const s = getStore();
  const id = s.byName[String(username).toLowerCase()];
  const user = id ? s.users[id] : null;
  assert(user, 'invalid username or password');
  const hash = hashPassword(password, user.salt);
  const ok = crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(user.hash, 'hex'));
  assert(ok, 'invalid username or password');
  const token = crypto.randomBytes(32).toString('hex');
  s.sessions[token] = { userId: user.id, createdAt: Date.now() };
  persist();
  return { user: publicUser(user), token };
}

export function logoutUser(token) {
  const s = getStore();
  if (token && s.sessions[token]) {
    delete s.sessions[token];
    persist();
  }
  return true;
}

/** Returns the public user for a valid, non-expired token, else null. */
export function getUserByToken(token) {
  if (!token) return null;
  const s = getStore();
  const sess = s.sessions[token];
  if (!sess) return null;
  if (Date.now() - sess.createdAt > SESSION_TTL_MS) {
    delete s.sessions[token];
    persist();
    return null;
  }
  const user = s.users[sess.userId];
  return user ? publicUser(user) : null;
}

export function getUserById(id) {
  const user = getStore().users[id];
  return user ? publicUser(user) : null;
}

export function getUserByName(username) {
  const s = getStore();
  const id = s.byName[String(username).toLowerCase()];
  return id ? publicUser(s.users[id]) : null;
}

function publicUser(user) {
  return { id: user.id, username: user.username, createdAt: user.createdAt };
}
