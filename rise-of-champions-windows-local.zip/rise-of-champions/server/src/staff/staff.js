// Staff roster: hire/fire coaches & physios. One member per role (MVP).
import { newId } from '../core/ids.js';
import { assert, checkIntRange, checkName } from '../core/validate.js';
import { loadConfig } from '../core/config.js';

export function staffCfg() {
  return loadConfig('staff');
}

export function createStaffRoster() {
  return { members: [] };
}

export function hireStaff(roster, { name, role, level = 1, wage = null }) {
  const cfg = staffCfg();
  checkName(name, 'staff name');
  assert(cfg.roles.includes(role), `unknown staff role: ${role}`);
  checkIntRange(level, 1, 5, 'staff level');
  assert(
    !roster.members.some((m) => m.role === role),
    `role ${role} already filled (max ${cfg.maxPerRole})`
  );
  const member = {
    id: newId('staff'),
    name,
    role,
    level,
    wage: wage ?? cfg.wages[String(level)],
  };
  roster.members.push(member);
  return member;
}

export function fireStaff(roster, staffId) {
  const i = roster.members.findIndex((m) => m.id === staffId);
  assert(i >= 0, `unknown staff: ${staffId}`);
  const [removed] = roster.members.splice(i, 1);
  return removed;
}

export function getStaffByRole(roster, role) {
  return roster.members.find((m) => m.role === role) ?? null;
}

export function staffLevel(roster, role) {
  return getStaffByRole(roster, role)?.level ?? 0;
}
