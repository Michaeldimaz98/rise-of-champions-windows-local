// Staff effects: how coaches/physios modify training and recovery.
import { rest, tickInjury } from '../players/condition.js';
import { medicalHealChance } from '../facilities/effects.js';
import { staffCfg, staffLevel } from './staff.js';

/**
 * Multipliers for a training session.
 * drillCategory lets the GoalkeepingCoach apply only to GK drills.
 */
export function getTrainingModifiers(roster, drillCategory = null) {
  const fx = staffCfg().effects;
  const hc = staffLevel(roster, 'HeadCoach');
  const ac = staffLevel(roster, 'AssistantCoach');
  const gk = staffLevel(roster, 'GoalkeepingCoach');
  const fc = staffLevel(roster, 'FitnessCoach');
  const physio = staffLevel(roster, 'Physio');

  let xpMult = 1 + fx.HeadCoach.xpPerLevel * hc + fx.AssistantCoach.xpPerLevel * ac;
  if (drillCategory === 'Goalkeeping') {
    xpMult += fx.GoalkeepingCoach.gkXpPerLevel * gk;
  }
  return {
    xpMult,
    fitnessCostMult: Math.max(0.5, 1 - fx.FitnessCoach.fitnessCostReductionPerLevel * fc),
    injuryRiskMult: Math.max(0.4, 1 - fx.Physio.injuryRiskReductionPerLevel * physio),
  };
}

/**
 * Daily recovery tick for a squad: fitness rest (boosted by fitness
 * coach) + injury healing (accelerated by physio and medical center).
 */
export function applyDailyRecovery(players, roster, rng = null, facilities = null) {
  const fx = staffCfg().effects;
  const fc = staffLevel(roster, 'FitnessCoach');
  const physio = staffLevel(roster, 'Physio');
  const hours = 24 * (1 + fx.FitnessCoach.recoveryPerLevel * fc);
  const medChance = facilities ? medicalHealChance(facilities) : 0;

  for (const p of players) {
    rest(p, hours);
    if (p.injury) {
      tickInjury(p);
      // Physio: chance of an extra healing tick per day.
      if (p.injury && rng && rng.chance(fx.Physio.healingPerLevel * physio)) {
        tickInjury(p);
      }
      // Medical center: another independent extra-tick chance.
      if (p.injury && rng && rng.chance(medChance)) {
        tickInjury(p);
      }
    }
  }
  return players;
}

/** Weekly wage bill for the whole staff roster. */
export function staffWageBill(roster) {
  return roster.members.reduce((s, m) => s + m.wage, 0);
}
