// Facility effects: matchday income, training bonus, youth & medical hooks.
import { facilitiesCfg, getFacilityLevel } from './facilities.js';

/** Matchday ticket income: attendance (capped by capacity) x ticket price. */
export function matchdayIncome(facilities, attendance) {
  const cfg = facilitiesCfg();
  const level = getFacilityLevel(facilities, 'Stadium');
  const capacity = cfg.facilities.Stadium.levels[String(level)].capacity;
  const crowd = Math.max(0, Math.min(attendance, capacity));
  return crowd * cfg.ticketPrice;
}

/** Training-ground level to pass as facilityLevel into runTrainingSession. */
export function trainingGroundLevel(facilities) {
  return getFacilityLevel(facilities, 'TrainingGround');
}

/** Youth intake quality bonus (used by the youth module, Phase 16). */
export function youthQualityBonus(facilities) {
  const cfg = facilitiesCfg();
  const level = getFacilityLevel(facilities, 'YouthAcademy');
  return cfg.facilities.YouthAcademy.levels[String(level)].qualityBonus;
}

/**
 * Extra daily injury-heal chance from the medical center.
 * Wired into recovery by the caller (staff.applyDailyRecovery accepts it).
 */
export function medicalHealChance(facilities) {
  return 0.05 * (getFacilityLevel(facilities, 'MedicalCenter') - 1);
}
