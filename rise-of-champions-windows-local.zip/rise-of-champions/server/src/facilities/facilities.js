// Club facilities: stadium, training ground, youth academy, medical center.
// Levels 1-5; upgrades cost cash and unlock gameplay effects.
import { assert, checkIntRange } from '../core/validate.js';
import { loadConfig } from '../core/config.js';

export function facilitiesCfg() {
  return loadConfig('facilities');
}

export function createFacilities() {
  const cfg = facilitiesCfg();
  const facilities = {};
  for (const type of Object.keys(cfg.facilities)) {
    facilities[type] = { type, level: 1 };
  }
  return facilities;
}

export function getFacilityLevel(facilities, type) {
  assert(facilities[type], `unknown facility: ${type}`);
  return facilities[type].level;
}

/** Upgrade one level; deducts cost from club.cash. Returns cost paid. */
export function upgradeFacility(facilities, club, type) {
  const cfg = facilitiesCfg();
  const def = cfg.facilities[type];
  assert(def, `unknown facility: ${type}`);
  const fac = facilities[type];
  assert(fac.level < def.maxLevel, `${type} already at max level`);
  const next = fac.level + 1;
  const cost = def.levels[String(next)].upgradeCost;
  assert(club.cash >= cost, `insufficient funds: need ${cost}, have ${club.cash}`);
  club.cash -= cost;
  fac.level = next;
  return cost;
}
