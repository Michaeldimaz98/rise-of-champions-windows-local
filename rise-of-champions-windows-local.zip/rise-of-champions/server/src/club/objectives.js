// Season objectives: measurable targets with rewards.
// Progress is fed in from league/cup/finance results; rewards are paid
// out by the finance module (post-MVP hook lives on `reward`).
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';

export const OBJECTIVE_KINDS = ['league_position', 'wins', 'goals', 'cup_round'];

export function createObjective({ kind, target, reward = 0, description }) {
  assert(OBJECTIVE_KINDS.includes(kind), `unknown objective kind: ${kind}`);
  return {
    id: newId('obj'),
    kind,
    target,
    progress: 0,
    reward,
    description: description ?? `${kind}: ${target}`,
    complete: false,
  };
}

/**
 * Feed season stats: { position, wins, goals, cupRound }.
 * Returns true when the objective is complete.
 */
export function updateObjective(objective, stats = {}) {
  switch (objective.kind) {
    case 'league_position':
      if (stats.position != null) objective.progress = stats.position;
      objective.complete = objective.progress > 0 && objective.progress <= objective.target;
      break;
    case 'wins':
    case 'goals':
    case 'cup_round': {
      const key = objective.kind === 'cup_round' ? 'cupRound' : objective.kind;
      if (stats[key] != null) objective.progress = Math.max(objective.progress, stats[key]);
      objective.complete = objective.progress >= objective.target;
      break;
    }
  }
  return objective.complete;
}
