// Club entity: factory with validation. Finance details (income,
// expenses, ledger) arrive in the finance module — the club only holds
// the current cash balance and identity.
import { loadConfig } from '../core/config.js';
import { newId } from '../core/ids.js';
import { checkIntRange, checkName, assert, isInt } from '../core/validate.js';

export function createClub(data = {}) {
  const defs = loadConfig('club');

  const name = checkName(data.name, 'club name');
  const cash = data.cash ?? defs.startingCash;
  assert(isInt(cash) && cash >= 0, `cash must be a non-negative integer, got ${cash}`);

  return {
    id: data.id ?? newId('club'),
    name,
    shortName: data.shortName ?? name.slice(0, 3).toUpperCase(),
    colors: data.colors ?? { primary: '#1a3a6b', secondary: '#ffffff' },
    level: checkIntRange(data.level ?? 1, 1, defs.maxLevel, 'level'),
    reputation: checkIntRange(
      data.reputation ?? defs.startingReputation,
      defs.reputationRange[0],
      defs.reputationRange[1],
      'reputation'
    ),
    cash,
  };
}
