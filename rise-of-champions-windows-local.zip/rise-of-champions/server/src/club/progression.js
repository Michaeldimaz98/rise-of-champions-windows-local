// Club progression: promotion/relegation effects on level & reputation.
// Called by the league module at season rollover.
import { loadConfig } from '../core/config.js';

export function promoteClub(club) {
  const defs = loadConfig('club');
  club.level = Math.min(defs.maxLevel, club.level + 1);
  club.reputation = Math.min(defs.reputationRange[1], club.reputation + 10);
  return club;
}

export function relegateClub(club) {
  const defs = loadConfig('club');
  club.level = Math.max(1, club.level - 1);
  club.reputation = Math.max(defs.reputationRange[0], club.reputation - 10);
  return club;
}
