// Board: season expectations, confidence, job security.
// The board sets a minimum league finish based on club reputation;
// confidence rises/falls with results. Hit 0 and you're sacked.
import { loadConfig } from '../core/config.js';
import { newId } from '../core/ids.js';
import { checkIntRange } from '../core/validate.js';

function boardCfg() {
  return loadConfig('club').board;
}

export function createBoard() {
  return {
    confidence: boardCfg().startConfidence,
    status: 'safe', // safe | warning | sacked
    expectations: [],
  };
}

/** Set season expectations from club reputation. Higher rep => higher demands. */
export function generateSeasonExpectations(board, club) {
  const cfg = boardCfg();
  const band = cfg.expectationBands.find(
    ([lo, hi]) => club.reputation >= lo && club.reputation <= hi
  );
  const minPosition = band ? band[2] : 8;
  board.expectations = [
    {
      id: newId('exp'),
      kind: 'league_position',
      target: minPosition,
      description: `Finish ${minPosition}${ordinal(minPosition)} or better in the league`,
    },
  ];
  return board.expectations;
}

function ordinal(n) {
  if (n === 1) return 'st';
  if (n === 2) return 'nd';
  if (n === 3) return 'rd';
  return 'th';
}

/**
 * End-of-season review. seasonResult: { finalPosition }.
 * Returns { met, status, confidence }.
 */
export function reviewBoard(board, seasonResult) {
  const cfg = boardCfg();
  const finalPosition = checkIntRange(seasonResult.finalPosition, 1, 64, 'finalPosition');
  const exp = board.expectations.find((e) => e.kind === 'league_position');
  const met = exp ? finalPosition <= exp.target : true;
  board.confidence = Math.max(
    0,
    Math.min(100, board.confidence + (met ? cfg.confidenceOnMet : cfg.confidenceOnMissed))
  );
  if (board.confidence <= cfg.sackAt) board.status = 'sacked';
  else if (board.confidence < cfg.warningBelow) board.status = 'warning';
  else board.status = 'safe';
  return { met, status: board.status, confidence: board.confidence };
}

/** Reset for a new season (a sacked manager stays sacked). */
export function newSeasonBoard(board) {
  if (board.status === 'sacked') return board;
  board.confidence = boardCfg().resetConfidence;
  board.status = 'safe';
  board.expectations = [];
  return board;
}
