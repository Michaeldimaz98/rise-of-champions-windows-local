// Daily-claim persistence: { [userId]: { lastClaim, streak } }.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.resolve(__dirname, '../../data/daily.json');

export let daily = {};

export function loadDaily() {
  try {
    daily = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return true;
  } catch {
    daily = {};
    return false;
  }
}

export function persistDaily() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(daily));
  fs.renameSync(tmp, DATA_FILE);
}
