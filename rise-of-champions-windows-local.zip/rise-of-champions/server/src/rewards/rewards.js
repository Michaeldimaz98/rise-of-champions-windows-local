// Rewards (Phase 23) — DOMAIN module. Pure logic: daily login rewards,
// achievements, streaks, league-season prizes. All amounts come from
// config/rewards.json. Every reward is server-validated, idempotent, and
// logged via the finance ledger by the caller.
import { assert } from '../core/validate.js';
import { recordTransaction } from '../finance/finance.js';
import { notify } from '../career/career.js';

/** Server-local calendar day: YYYY-MM-DD. */
export function dayString(now = Date.now()) {
  const d = new Date(now);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function prevDay(dayStr) {
  const [y, m, d] = dayStr.split('-').map(Number);
  return dayString(new Date(y, m - 1, d - 1).getTime());
}

// --- daily login rewards ---
// state: { [userId]: { lastClaim: 'YYYY-MM-DD'|null, streak: number } }
export function claimDaily(state, userId, dayStr, cfg) {
  assert(/^\d{4}-\d{2}-\d{2}$/.test(dayStr), 'bad day string');
  const u = state[userId] ?? { lastClaim: null, streak: 0 };
  if (u.lastClaim === dayStr) {
    return { alreadyClaimed: true, streak: u.streak, reward: null, bonus: 0 };
  }
  u.streak = u.lastClaim === prevDay(dayStr) ? u.streak + 1 : 1;
  const reward = cfg.daily[(u.streak - 1) % cfg.daily.length];
  const bonus = u.streak % cfg.daily.length === 0 ? (cfg.streakWeekBonus ?? 0) : 0;
  u.lastClaim = dayStr;
  state[userId] = u;
  return { alreadyClaimed: false, streak: u.streak, reward, bonus };
}

export function dailyStatus(state, userId, dayStr, cfg) {
  const u = state[userId] ?? { lastClaim: null, streak: 0 };
  const canClaim = u.lastClaim !== dayStr;
  const nextStreak = canClaim ? (u.lastClaim === prevDay(dayStr) ? u.streak + 1 : 1) : u.streak;
  const calendar = cfg.daily.map((r, i) => ({
    ...r,
    state: !canClaim && i === (u.streak - 1) % cfg.daily.length ? 'claimed'
      : canClaim && i === (nextStreak - 1) % cfg.daily.length ? 'today' : 'upcoming',
  }));
  return { canClaim, streak: u.streak, nextStreak, calendar };
}

// --- career stats & achievements ---
export function ensureRewardState(career) {
  career.stats = career.stats ?? {
    played: 0, wins: 0, draws: 0, losses: 0, goalsFor: 0,
    winStreak: 0, bestWinStreak: 0, youthPromoted: 0, signings: 0,
    trainings: 0, facilitiesUpgraded: 0, // Phase 32
  };
  career.achievements = career.achievements ?? { unlocked: {} };
  return career;
}

/** Record the player's match result into career stats. Idempotent-safe: call once per match. */
export function recordMatchResult(career, { won, drawn, goalsFor }) {
  ensureRewardState(career);
  const s = career.stats;
  s.played += 1;
  s.goalsFor += Math.max(0, goalsFor | 0);
  if (won) {
    s.wins += 1;
    s.winStreak += 1;
    s.bestWinStreak = Math.max(s.bestWinStreak, s.winStreak);
  } else {
    if (drawn) s.draws += 1; else s.losses += 1;
    s.winStreak = 0;
  }
  return s;
}

/**
 * Unlock every achievement whose target is met. Idempotent: already-unlocked
 * achievements are never granted twice. Returns the newly unlocked list.
 */
export function checkAchievements(career, cfg) {
  ensureRewardState(career);
  const newly = [];
  for (const a of cfg.achievements) {
    if (career.achievements.unlocked[a.id]) continue;
    if ((career.stats[a.stat] ?? 0) >= a.target) {
      career.achievements.unlocked[a.id] = Date.now();
      newly.push(a);
    }
  }
  return newly;
}

/** Pay achievement rewards through the ledger + notify. */
export function applyAchievementRewards(career, list) {
  if (!list.length) return [];
  const club = career.clubs[career.playerClubId].club;
  return list.map((a) => {
    recordTransaction(club, { type: 'achievement_reward', amount: a.cash, description: `Achievement: ${a.name}` });
    notify(career, `🏆 Achievement unlocked: ${a.name} (+${a.cash.toLocaleString()}).`);
    return a.id;
  });
}

/** Full progress view for the client. */
export function achievementProgress(career, cfg) {
  ensureRewardState(career);
  return cfg.achievements.map((a) => ({
    id: a.id,
    name: a.name,
    desc: a.desc,
    category: a.category ?? 'Match',
    target: a.target,
    current: Math.min(career.stats[a.stat] ?? 0, a.target),
    cash: a.cash,
    unlocked: !!career.achievements.unlocked[a.id],
    unlockedAt: career.achievements.unlocked[a.id] ?? null,
  }));
}

// --- online league season rewards ---
/** Prizes for the top-3 of a completed online league season. Pure. */
export function leagueSeasonRewards(table, cfg) {
  return table.slice(0, 3).map((row, i) => ({
    userId: row.userId,
    username: row.username,
    clubName: row.clubName,
    position: i + 1,
    amount: cfg.leagueSeason[String(i + 1)] ?? 0,
  }));
}

/** Pay league-season rewards into each manager's career club. Idempotent via caller flag. */
export function applyLeagueSeasonRewards(rewards, getCareer) {
  const paid = [];
  for (const r of rewards) {
    const career = getCareer(r.userId);
    if (!career || r.amount <= 0) continue;
    const club = career.clubs[career.playerClubId].club;
    recordTransaction(club, { type: 'league_season_reward', amount: r.amount, description: `Online League — ${r.position}${ordinal(r.position)} place` });
    notify(career, `🏆 Online League season over: ${r.position}${ordinal(r.position)} place (+${r.amount.toLocaleString()}).`);
    paid.push({ ...r });
  }
  return paid;
}

function ordinal(n) {
  return n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th';
}
