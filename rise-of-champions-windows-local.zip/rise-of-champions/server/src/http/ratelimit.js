// Simple in-memory sliding-window rate limiter (no dependencies).
// Protects auth endpoints (brute force) and the general API from abuse.
// Single-process: state lives in module scope; each server instance tracks
// its own counters. now() is injectable for tests.
export function createRateLimiter({ windowMs = 60000, maxAuth = 30, maxApi = 600, now = () => Date.now() } = {}) {
  const buckets = new Map(); // key -> { count, resetAt }

  function check(ip, pathname) {
    const bucket = pathname.startsWith('/api/auth/') ? 'auth' : 'api';
    const max = bucket === 'auth' ? maxAuth : maxApi;
    const key = `${bucket}:${ip ?? 'unknown'}`;
    const t = now();
    let e = buckets.get(key);
    if (!e || t >= e.resetAt) {
      e = { count: 0, resetAt: t + windowMs };
      buckets.set(key, e);
    }
    e.count += 1;
    if (buckets.size > 10000) {
      for (const [k, v] of buckets) if (v.resetAt <= t) buckets.delete(k);
    }
    return { allowed: e.count <= max, retryAfterMs: e.count <= max ? 0 : e.resetAt - t };
  }

  return { check, _buckets: buckets };
}
