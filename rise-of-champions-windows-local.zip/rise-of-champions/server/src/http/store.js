// In-memory career store. Boot loads persisted saves from disk (Phase 19).
import { loadAllCareers } from '../save/save.js';
import { loadOleagues } from '../oleague/store.js';
import { loadRanked } from '../pvp/rstore.js';
import { loadDaily } from '../rewards/dstore.js';
import { loadEvents } from '../events/store.js';
import { loadShop } from '../shop/store.js';
import { loadAnalytics } from '../analytics/store.js';
import { loadLiveops } from '../liveops/store.js';
import { loadReminders } from '../season/store.js';

export const careers = new Map();

export function initStore() {
  for (const career of loadAllCareers()) {
    careers.set(career.id, career);
  }
  loadOleagues();
  loadRanked();
  loadDaily();
  loadEvents();
  loadShop();
  loadAnalytics();
  loadLiveops();
  loadReminders();
  return careers.size;
}
