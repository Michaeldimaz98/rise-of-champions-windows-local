// HTTP server: JSON API + static client. No dependencies, Node built-ins only.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleApi } from './api.js';
import { initStore } from './store.js';
import { createRateLimiter } from './ratelimit.js';
import { ValidationError } from '../core/validate.js';

const limiter = createRateLimiter();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLIENT_DIR = path.resolve(__dirname, '../../../client');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

// Phase 27: baseline security headers on every response.
const SECURITY_HEADERS = {
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'SAMEORIGIN',
  'referrer-policy': 'no-referrer',
  'permissions-policy': 'camera=(), microphone=(), geolocation=()',
};

function serveStatic(req, res) {
  let urlPath = new URL(req.url, 'http://x').pathname;
  if (urlPath === '/') urlPath = '/index.html';
  const file = path.normalize(path.join(CLIENT_DIR, urlPath));
  if (!file.startsWith(CLIENT_DIR) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404, { 'content-type': 'text/plain', ...SECURITY_HEADERS });
    res.end('not found');
    return;
  }
  // Phase 28: ETag revalidation — client caches, server sends 304 when fresh.
  const stat = fs.statSync(file);
  const etag = `"${stat.size.toString(36)}-${Math.floor(stat.mtimeMs).toString(36)}"`;
  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, { etag, ...SECURITY_HEADERS });
    res.end();
    return;
  }
  res.writeHead(200, {
    'content-type': MIME[path.extname(file)] ?? 'application/octet-stream',
    etag,
    'cache-control': 'public, max-age=60',
    ...SECURITY_HEADERS,
  });
  fs.createReadStream(file).pipe(res);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const MAX_BODY_BYTES = 1_000_000;
    const chunks = [];
    let totalBytes = 0;
    let settled = false;
    req.on('data', (chunk) => {
      // Continue draining over-limit requests, but do not retain further chunks.
      if (settled) return;
      totalBytes += chunk.length;
      if (totalBytes > MAX_BODY_BYTES) {
        settled = true;
        chunks.length = 0;
        const e = new Error('body too large');
        e.statusCode = 413;
        reject(e);
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      if (totalBytes === 0) {
        settled = true;
        resolve({});
        return;
      }
      try {
        const body = JSON.parse(Buffer.concat(chunks, totalBytes).toString('utf8'));
        settled = true;
        resolve(body);
      } catch {
        const e = new Error('invalid JSON body');
        e.statusCode = 400;
        settled = true;
        reject(e);
      }
    });
    req.on('error', (err) => {
      if (settled) return;
      settled = true;
      reject(err);
    });
  });
}

function sendJson(res, status, obj) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', ...SECURITY_HEADERS });
  res.end(JSON.stringify(obj));
}

export function createServer() {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x');
      if (req.method === 'GET' && url.pathname === '/__health') {
        sendJson(res, 200, { app: 'rise-of-champions', status: 'ok' });
        return;
      }
      const rl = limiter.check(req.socket.remoteAddress, url.pathname);
      if (!rl.allowed) {
        res.writeHead(429, { 'content-type': 'application/json', 'retry-after': Math.ceil(rl.retryAfterMs / 1000), ...SECURITY_HEADERS });
        res.end(JSON.stringify({ error: 'too many requests, slow down' }));
        return;
      }
      if (url.pathname.startsWith('/api/')) {
        const body = req.method === 'GET' || req.method === 'HEAD' ? {} : await readBody(req);
        const out = await handleApi(req.method, url.pathname, body, url.searchParams, req.headers);
        sendJson(res, out.status ?? 200, out.body);
        return;
      }
      if (req.method === 'GET') return serveStatic(req, res);
      res.writeHead(405, { 'content-type': 'text/plain', ...SECURITY_HEADERS });
      res.end('method not allowed');
    } catch (err) {
      // Phase 27: validation problems are the client's fault (400 + message);
      // unexpected failures never leak internals (500 + generic).
      const status = err.statusCode ?? (err instanceof ValidationError ? 400 : 500);
      if (status >= 500) {
        console.error(`[server] ${req.method} ${req.url} ->`, err);
        sendJson(res, 500, { error: 'internal server error' });
      } else {
        sendJson(res, status, { error: err.message });
      }
    }
  });
}

const PORT = process.env.PORT ?? 3000;
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const loaded = initStore();
  createServer().listen(PORT, '127.0.0.1', () => {
    console.log(`Rise of Champions server on http://127.0.0.1:${PORT} (${loaded} saves loaded)`);
  });
}
