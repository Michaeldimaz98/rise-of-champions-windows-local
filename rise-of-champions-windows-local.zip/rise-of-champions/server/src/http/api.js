// API routes: thin handlers over the game modules. All game logic stays
// in the domain modules; this file only wires HTTP <-> career.
// Routes with `auth: true` require a Bearer session token.
import fs from 'node:fs';
import path from 'node:path';
import { createRng } from '../core/rng.js';
import { checkName, assert } from '../core/validate.js';
import { createCareer, notify } from '../career/career.js';
import { advanceMatchday, getTable, getScorers, completeLiveMatchday } from '../career/season.js';
import { setLineup, setBench, setCaptain, setSetPieceTakers } from '../squad/squad.js';
import { createTactics, setPlayerInstruction } from '../tactics/tactics.js';
import { runTrainingSession, getDrills } from '../training/index.js';
import { trainingGroundLevel } from '../facilities/effects.js';
import { upgradeFacility } from '../facilities/facilities.js';
import { hireStaff, fireStaff } from '../staff/staff.js';
import { hireScout, scoutPlayers } from '../scouting/index.js';
import {
  listForSale, makeOffer, evaluateOffer, answerCounter, completeTransfer,
} from '../transfer/index.js';
import { playerValue } from '../players/player.js';
import { youthIntake, promoteToSenior, releaseYouth } from '../youth/youth.js';
import { offerContract, signContract, getExpiring } from '../contracts/contracts.js';
import { getLedger, financialHealth, recordTransaction } from '../finance/finance.js';
import { saveCareer, deleteSave, SAVE_DIR } from '../save/save.js';
import {
  registerUser, loginUser, logoutUser, getUserByToken, getUserByName, getUserById,
} from '../auth/auth.js';
import { playFriendly, buildLeaderboard } from '../pvp/pvp.js';
import {
  createLeague, joinLeague, leaveLeague, startSeason, playFixture,
  advanceMatchday as advanceOnlineMatchday, computeTable, newSeason, publicLeague,
} from '../oleague/oleague.js';
import { oleagues, loadOleagues, persistOleagues } from '../oleague/store.js';
import {
  getEntry, joinQueue, leaveQueue, tryMatch, seasonEnded, isPendingFixture,
  tierFor, defaultApplyReward, TIER_REWARDS,
} from '../pvp/competitive.js';
import {
  sealFixture, ensureSettled, settleOverdue, fixtureView, migrateLegacyFixtures,
  PREPARATION_WINDOW_MS,
} from '../pvp/sealed.js';
import { ranked, loadRanked, persistRanked } from '../pvp/rstore.js';
import {
  dayString, claimDaily, dailyStatus, ensureRewardState, recordMatchResult,
  checkAchievements, applyAchievementRewards, achievementProgress,
  leagueSeasonRewards, applyLeagueSeasonRewards,
} from '../rewards/rewards.js';
import { daily, loadDaily, persistDaily } from '../rewards/dstore.js';
import { loadConfig } from '../core/config.js';
import {
  getTemplate, eventStatus, createEvent, joinEvent, recordEventProgress,
  eventLeaderboard, settleEvent, publicEvent,
} from '../events/events.js';
import { events, loadEvents, persistEvents } from '../events/store.js';
import {
  getProduct, blankEntitlements, trainingXpMult, vipDailyBonus,
  createOrder, completeOrder, publicEntitlements,
} from '../shop/shop.js';
import { orders, entitlements, loadShop, persistOrders, persistEntitlements } from '../shop/store.js';
import { charge } from '../shop/provider.js';
import { makeEvent, summarize } from '../analytics/analytics.js';
import { analyticsEvents, trackEvent, loadAnalytics } from '../analytics/store.js';
// Phase 38: live match management.
import {
  startLive, continueLive, abandonLive, applyTactics, applyFormation,
  applySubstitution, applyInstruction, liveView, getLiveContext,
  hasActiveLive, clearLiveContext, ensureLiveMatch,
} from '../live/match.js';
import { startLiveCompetition, finishLiveCompetition, isLiveCompetition } from '../live/competitions.js';
import {
  periodKey, periodEnd, metricValues, ensurePeriod, objectiveView, claimObjective,
} from '../liveops/objectives.js';
import {
  blankManager, levelForXp, xpForNextLevel, grantXp, trackView, claimTrackLevel,
} from '../liveops/manager.js';
import { sendInbox, listInbox, markRead, markAllRead } from '../liveops/inbox.js';
import {
  objectiveState, managerState, inboxState,
  loadLiveops, persistObjectives, persistManager, persistInbox,
} from '../liveops/store.js';
import {
  finalizeRankedSeason, seasonStandings, mySeasonResult, snapshotStandings,
} from '../season/finalize.js';
import {
  reminderDue, markReminder, seasonEndingKey, eventEndingKey,
  withinWindow,
} from '../season/reminders.js';
import { reminderState, loadReminders, persistReminders } from '../season/store.js';
import {
  ensureLegacy, recordMatch, awardTrophy,
  checkMilestones, applyMilestoneRewards, milestoneProgress,
  computePrestige, tierFor as prestigeTierFor, updateIdentity,
  ownManagerProfile, publicManagerProfile,
} from '../legacy/index.js';
import {
  ensureRivalry, processRivalryMatch, rivalriesFromMatches, rivalryFor,
  rivalryMilestoneProgress,
} from '../rivalry/index.js';
import {
  ensureCup, playCupRound, playerCupFixture, playerCupRun, cupView, completeCupTie,
} from '../cup/career.js';
import {
  ensureContinental, qualifyContinental, playContinental,
  playerContinentalFixture, playerContinentalRun, continentalView,
  awardQualificationReward, completeContinentalFixture,
} from '../continental/career.js';
import { pushActivity } from '../rivalry/matches.js';

const liveopsCfg = loadConfig('liveops');

function mgrOf(userId) {
  let m = managerState[userId];
  if (!m) { m = managerState[userId] = blankManager(); }
  return m;
}

/** Grant manager XP from a server-validated event; pay level-up rewards. */
function grantManagerXp(userId, amount, source) {
  const mgr = mgrOf(userId);
  const out = grantXp(mgr, liveopsCfg, amount, source);
  persistManager();
  if (out.leveledUp.length) {
    const career = careerOfUser(userId);
    for (const lv of out.leveledUp) {
      const def = liveopsCfg.managerLevels.find((l) => l.level === lv);
      if (career && def) {
        const club = career.clubs[career.playerClubId].club;
        recordTransaction(club, {
          type: 'manager_level',
          amount: def.cash,
          description: `Manager level ${lv} reward`,
        });
        notify(career, `⭐ Manager level ${lv}! Reward +${def.cash.toLocaleString()}.`);
        autosave(career);
      }
    }
    sendInbox(inboxState, userId, {
      type: 'manager_level',
      title: `Manager level ${out.level}!`,
      body: `You reached manager level ${out.level}.` + (career ? '' : ' Create a career to receive level rewards.'),
    });
    persistInbox();
  }
  return out;
}

function metricsFor(userId) {
  const career = careerOfUser(userId);
  return metricValues(career);
}

// ---- Phase 33: seasonal reminders (idempotent, server-time based) ----
function reminderBox(userId) {
  let box = reminderState[userId];
  if (!box) box = reminderState[userId] = {};
  return box;
}

/** Season-ending reminder for one user (24h window, once per season). */
function maybeSeasonReminder(userId, now = Date.now()) {
  const entry = ranked.ratings[userId];
  if (!entry || entry.w + entry.d + entry.l === 0) return; // only participants
  for (const h of liveopsCfg.reminderWindows.seasonEndingHours) {
    if (withinWindow(ranked.season.endsAt, h * 3600000, now)) {
      const key = seasonEndingKey(ranked.season.number, userId, h);
      const box = reminderBox(userId);
      if (reminderDue(box, key, now)) {
        markReminder(box, key, now);
        persistReminders();
        sendInbox(inboxState, userId, {
          type: 'season',
          title: `Ranked Season ${ranked.season.number} ends soon`,
          body: `Season ends in under ${h}h. Play your remaining ranked matches to lock your final tier reward.`,
        });
        persistInbox();
      }
    }
  }
}

/** Event-ending reminders for events the user joined (once per event). */
function maybeEventReminders(userId, now = Date.now()) {
  for (const h of liveopsCfg.reminderWindows.eventEndingHours) {
    for (const ev of events.values()) {
      if (!ev.participants[userId]) continue; // only relevant accounts
      if (!withinWindow(ev.endsAt, h * 3600000, now)) continue;
      const key = eventEndingKey(ev.id, userId);
      const box = reminderBox(userId);
      if (reminderDue(box, key, now)) {
        markReminder(box, key, now);
        persistReminders();
        sendInbox(inboxState, userId, {
          type: 'event',
          title: `Event ending soon: ${ev.name}`,
          body: `Ends in under ${h}h. Your current score: ${ev.participants[userId].score}.`,
        });
        persistInbox();
      }
    }
  }
}

/** Seasonal goal progress from a ranked entry (server-derived). */
function seasonGoalProgress(entry) {
  const played = (entry.w ?? 0) + (entry.d ?? 0) + (entry.l ?? 0);
  const vals = { ranked_wins: entry.w ?? 0, ranked_matches: played, ranked_rating: entry.rating ?? 1000 };
  return liveopsCfg.seasonGoals.map((g) => {
    const cur = vals[g.metric] ?? 0;
    return { id: g.id, title: g.title, desc: g.desc, target: g.target, current: Math.min(cur, g.target), done: cur >= g.target };
  });
}

const rewardCfg = loadConfig('rewards');
const eventCfg = loadConfig('events');
const shopCfg = loadConfig('shop');

function entOf(userId) {
  let ent = entitlements.get(userId);
  if (!ent) { ent = blankEntitlements(); entitlements.set(userId, ent); }
  return ent;
}

/** Fire-and-forget analytics; never breaks the request. */
function track(type, ctx, data = null) {
  trackEvent(makeEvent({
    type,
    userId: ctx.user ? ctx.user.id : null,
    careerId: ctx.id || null,
    data,
  }));
}

// Phase 27: anti double-submit / rapid-fire on state-advancing actions.
// Keyed in-memory (transient); not persisted.
const lastActionAt = new Map();
function debounceAction(careerId, action, ms = 2000) {
  const key = `${careerId}:${action}`;
  const now = Date.now();
  const last = lastActionAt.get(key) ?? 0;
  if (now - last < ms) httpError(429, 'too fast — please wait a moment');
  lastActionAt.set(key, now);
}

/** Record a career match into stats + unlock achievements (idempotent per call). */
function grantMatchRewards(career, playerResult) {
  if (!playerResult || !playerResult.score) return [];
  const clubName = career.clubs[career.playerClubId].club.name;
  const isHome = playerResult.home === clubName;
  const gf = isHome ? playerResult.score.home : playerResult.score.away;
  const ga = isHome ? playerResult.score.away : playerResult.score.home;
  recordMatchResult(career, { won: gf > ga, drawn: gf === ga, goalsFor: gf });
  const newly = checkAchievements(career, rewardCfg);
  applyAchievementRewards(career, newly);
  // Phase 24: feed active events the user joined (persist only when changed — Phase 28)
  if (career.userId) {
    const updated = recordEventProgress([...events.values()], career.userId, {
      goalsFor: gf, won: gf > ga, played: 1,
    });
    if (updated.length) persistEvents();
  }
  return newly;
}

/**
 * Shared post-processing for a played league matchday (instant + live).
 * Runs rewards, season-end inbox/trophy, records, rivalry, XP — all
 * idempotent via ledger/milestone guards. Phase 38 extraction.
 */
function postLeaguePlay(career, ctx, out) {
  const unlocked = grantMatchRewards(career, out.playerResult);
  // Phase 33: career season-end inbox (one-shot: endSeason runs once per season)
  if (out.seasonEnd && career.userId) {
    const se = out.seasonEnd;
    sendInbox(inboxState, career.userId, {
      type: 'season',
      title: `Season ${career.season - 1} complete — finished #${se.position}`,
      body: `Prize: +${(se.prize ?? 0).toLocaleString()} cash. A new season has begun.`,
    });
    persistInbox();
    // Phase 34: league title trophy (idempotent by trophy id)
    if (se.position === 1) {
      const got = awardTrophy(career, {
        id: `league-${career.id}-s${career.season - 1}`,
        type: 'league',
        competition: 'League',
        season: career.season - 1,
        result: 'Champions',
      });
      if (got) notify(career, '🏆 League champions! Trophy added to the cabinet.');
      grantMilestones(career, career.userId);
    }
  }
  autosave(career);
  if (out.playerResult && out.playerResult.score) {
    const clubName = career.clubs[career.playerClubId].club.name;
    const isHome = out.playerResult.home === clubName;
    const gf = isHome ? out.playerResult.score.home : out.playerResult.score.away;
    const ga = isHome ? out.playerResult.score.away : out.playerResult.score.home;
    track('match_played', ctx, { won: gf > ga, drawn: gf === ga, goalsFor: gf, matchday: career.matchday });
    // Phase 34: club records from the validated result; milestone check (wins50/100)
    recordMatch(career, {
      gf, ga,
      opponent: isHome ? out.playerResult.away : out.playerResult.home,
      at: Date.now(),
    });
    grantMilestones(career, career.userId);
    // Phase 35: rivalry — league meetings vs AI clubs feed H2H/intensity/milestones
    const oppName = isHome ? out.playerResult.away : out.playerResult.home;
    const oppEntryId = clubEntryIdByName(career, oppName);
    if (oppEntryId && oppEntryId !== career.playerClubId) {
      grantRivalry(career, career.userId, {
        competition: 'league',
        opponentKey: `league:${oppEntryId}`,
        opponentName: oppName,
        gf, ga,
        at: Date.now(),
      });
    }
  }
  for (const a of unlocked) track('achievement_unlocked', ctx, { achievementId: a.id });
  if (career.userId && out.playerResult && out.playerResult.score) {
    const clubName = career.clubs[career.playerClubId].club.name;
    const isHome = out.playerResult.home === clubName;
    const won = (isHome ? out.playerResult.score.home : out.playerResult.score.away)
      > (isHome ? out.playerResult.score.away : out.playerResult.score.home);
    grantManagerXp(career.userId,
      liveopsCfg.xpSources.match_played + (won ? liveopsCfg.xpSources.match_won : 0),
      won ? 'match_won' : 'match_played');
  }
  return { body: { ...out, unlockedAchievements: unlocked.map((a) => ({ id: a.id, name: a.name, cash: a.cash })), state: stateView(career) } };
}

/** Increment a career stat + check achievements. Returns newly unlocked. */
function grantStatReward(career, stat) {
  ensureRewardState(career);
  career.stats[stat] = (career.stats[stat] ?? 0) + 1;
  const newly = checkAchievements(career, rewardCfg);
  applyAchievementRewards(career, newly);
  return newly;
}

// ---- Phase 34: club legacy helpers ----

/** Ranked context for prestige/milestones: top-3 finishes + best rank. */
function rankedCtxOf(userId) {
  const hist = ranked.rankedHistory?.[userId] ?? [];
  const ranks = hist.map((h) => h.rank ?? 999);
  return {
    rankedTop3: ranks.filter((r) => r <= 3).length,
    rankedBest: ranks.length ? Math.min(...ranks) : null,
    tiers: liveopsCfg.prestigeTiers,
  };
}

/** Full legacy view for one career (own, authenticated). */
function legacyView(career, userId) {
  ensureLegacy(career);
  const club = career.clubs[career.playerClubId].club;
  const ctx = rankedCtxOf(userId);
  const prestige = computePrestige(career, ctx);
  const s = career.stats || {};
  return {
    clubName: club.name,
    prestige: prestige.score,
    prestigeTier: prestige.tier,
    reputation: club.reputation,
    records: career.legacy.records,
    trophies: career.legacy.trophies,
    milestones: milestoneProgress(career, liveopsCfg, ctx),
    identity: { ...career.identity },
    career: {
      played: s.played || 0,
      wins: s.wins || 0,
      draws: s.draws || 0,
      losses: s.losses || 0,
      goalsFor: s.goalsFor || 0,
      bestWinStreak: s.bestWinStreak || 0,
      bestUnbeaten: s.bestUnbeaten || 0,
    },
  };
}

/** Check + pay newly unlocked milestones for a career. Returns unlocked defs. */
function grantMilestones(career, userId) {
  const newly = checkMilestones(career, liveopsCfg, rankedCtxOf(userId));
  if (newly.length) {
    applyMilestoneRewards(career, newly);
    autosave(career);
  }
  return newly;
}

// ---- Phase 35: rivalry helpers ----

/** Find a club entry id in a career by club name (AI clubs have unique names). */
function clubEntryIdByName(career, name) {
  for (const [id, entry] of Object.entries(career.clubs)) {
    if (entry.club.name === name) return id;
  }
  return null;
}

/** Pay rivalry milestone rewards: cash via ledger + manager XP. One-time by unlock map. */
function payRivalryMilestones(career, userId, list) {
  if (!list.length) return [];
  const club = career.clubs[career.playerClubId].club;
  const paid = [];
  for (const { def, rivalName } of list) {
    if (def.cash > 0) {
      recordTransaction(club, {
        type: 'rivalry_milestone',
        amount: def.cash,
        description: `Rivalry milestone: ${def.title}${rivalName ? ` (${rivalName})` : ''}`,
      });
    }
    notify(career, `⚔️ Rivalry milestone: ${def.title}${def.cash > 0 ? ` (+${def.cash.toLocaleString()})` : ''}.`);
    paid.push(def.id);
  }
  if (userId) {
    const totalXp = list.reduce((a, { def }) => a + (def.xp || 0), 0);
    if (totalXp > 0) grantManagerXp(userId, totalXp, 'rivalry_milestone');
  }
  autosave(career);
  return paid;
}

/**
 * Process one verified eligible match into a career's rivalry state.
 * Returns the orchestration result (rivalry, tierUp, newMilestones).
 */
function grantRivalry(career, userId, match) {
  ensureRivalry(career);
  const out = processRivalryMatch(career, liveopsCfg, match);
  payRivalryMilestones(career, userId, out.newMilestones);
  autosave(career);
  return out;
}

/** Public-safe rivalry summary for lists. */
function publicRivalry(r) {  return {
    key: r.key,
    opponentName: r.opponentName,
    tier: r.tier.label,
    tierId: r.tier.id,
    intensity: r.intensity,
    meetings: r.meetings,
    wins: r.wins,
    draws: r.draws,
    losses: r.losses,
    goalsFor: r.goalsFor,
    goalsAgainst: r.goalsAgainst,
    lastMeetingAt: r.lastMeetingAt,
    lastResult: r.lastResult,
    lastScore: r.lastScore,
    streak: r.streak,
  };
}

/** My club's public comparison stats. */
function myClubPublic(career, userId) {
  ensureLegacy(career);
  const club = career.clubs[career.playerClubId].club;
  const prestige = computePrestige(career, rankedCtxOf(userId));
  const trophies = career.legacy.trophies;
  const s = career.stats || {};
  const played = s.played || 0;
  return {
    clubName: club.name,
    prestige: prestige.score,
    prestigeTier: prestige.tier,
    reputation: club.reputation,
    trophies: trophies.length,
    leagueTitles: trophies.filter((t) => t.type === 'league').length,
    matches: played,
    wins: s.wins || 0,
    winRate: played ? Math.round((s.wins / played) * 100) : 0,
  };
}

/** Rival club public info: ranked (real manager) or league (AI club). Never private data. */
function rivalClubPublic(career, r) {
  if (r.opponentUserId) {
    const user = getUserById(r.opponentUserId);
    const oc = user ? careerOfUser(user.id) : null;
    const info = { kind: 'manager', name: r.opponentName };
    if (user) {
      info.manager = user.username;
      info.managerLevel = mgrOf(user.id).level;
    }
    if (oc) {
      ensureLegacy(oc);
      const club = oc.clubs[oc.playerClubId].club;
      const prestige = computePrestige(oc, rankedCtxOf(user.id));
      info.clubName = club.name;
      info.prestigeTier = prestige.tier;
      info.reputation = club.reputation;
      info.trophies = oc.legacy.trophies.length;
      info.leagueTitles = oc.legacy.trophies.filter((t) => t.type === 'league').length;
      info.motto = oc.identity?.motto || '';
      info.stadiumName = oc.identity?.stadiumName || '';
    }
    return info;
  }
  // AI club inside my own career
  const entryId = r.key.startsWith('league:') ? r.key.slice(7) : null;
  const entry = entryId ? career.clubs[entryId] : null;
  const info = { kind: 'club', name: r.opponentName };
  if (entry) {
    info.reputation = entry.club.reputation;
    info.level = entry.club.level;
  }
  return info;
}

/** Full rival detail: H2H, last 5, comparison, milestones, activity. */
function rivalDetail(career, userId, r) {
  ensureRivalry(career);
  const me = myClubPublic(career, userId);
  const rival = rivalClubPublic(career, r);
  const keys = Object.keys(career.legacy.rivalryMilestones)
    .filter((k) => k.endsWith(`:${r.key}`));
  return {
    rivalry: publicRivalry(r),
    last5: r.last5,
    opponent: rival,
    comparison: {
      me: { name: me.clubName, prestige: me.prestige, prestigeTier: me.prestigeTier, reputation: me.reputation, trophies: me.trophies, leagueTitles: me.leagueTitles, matches: me.matches, wins: me.wins, winRate: me.winRate },
      rival: {
        name: rival.clubName ?? rival.name,
        prestigeTier: rival.prestigeTier ?? null,
        reputation: rival.reputation ?? null,
        trophies: rival.trophies ?? null,
        leagueTitles: rival.leagueTitles ?? null,
      },
    },
    milestonesUnlocked: keys.length,
    activity: career.legacy.activity.filter((a) => a.key === r.key).slice(0, 10),
  };
}

/** Public-safe manager comparison totals. */
function userCompareTotals(userId) {
  const cs = [...careers.values()].filter((c) => c.userId === userId);
  let matches = 0, wins = 0, trophies = 0, leagueTitles = 0, bestPrestige = 0, bestTier = 'Local';
  for (const c of cs) {
    ensureLegacy(c);
    const s = c.stats || {};
    matches += s.played || 0;
    wins += s.wins || 0;
    trophies += c.legacy.trophies.length;
    leagueTitles += c.legacy.trophies.filter((t) => t.type === 'league').length;
    const p = computePrestige(c, rankedCtxOf(userId));
    if (p.score > bestPrestige) { bestPrestige = p.score; bestTier = p.tier; }
  }
  return {
    clubs: cs.length,
    matches, wins,
    winRate: matches ? Math.round((wins / matches) * 100) : 0,
    trophies, leagueTitles,
    bestPrestige, bestTier,
  };
}

function managerCompare(me, them) {
  const a = { username: me.username, level: mgrOf(me.id).level, ...userCompareTotals(me.id) };
  const b = { username: them.username, level: mgrOf(them.id).level, ...userCompareTotals(them.id) };
  const rows = [
    ['Level', a.level, b.level],
    ['Clubs managed', a.clubs, b.clubs],
    ['Matches', a.matches, b.matches],
    ['Wins', a.wins, b.wins],
    ['Win rate', `${a.winRate}%`, `${b.winRate}%`],
    ['Trophies', a.trophies, b.trophies],
    ['League titles', a.leagueTitles, b.leagueTitles],
    ['Best prestige', `${a.bestPrestige} (${a.bestTier})`, `${b.bestPrestige} (${b.bestTier})`],
  ];
  return { me: a, them: b, rows };
}

// ---- Phase 36: career cup finalization ----

/**
 * Finalize a completed cup: trophy (existing cabinet, idempotent),
 * prize money (existing ledger), milestones, notifications.
 * Idempotent: guarded by cup.finalized; safe under retry/restart/replay.
 * Returns the finalization summary, or null if already finalized.
 */
function finalizeCareerCup(career, userId) {
  const cup = career.cup;
  if (!cup || cup.status !== 'complete' || !cup.champion || cup.finalized) return null;
  cup.finalized = true;

  const champName = career.clubs[cup.champion]?.club.name ?? '?';
  const isPlayer = cup.champion === career.playerClubId;
  const club = career.clubs[career.playerClubId].club;

  // Trophy via the existing Phase 34 cabinet (deterministic id) — champion only.
  let trophy = null;
  if (isPlayer) {
    trophy = awardTrophy(career, {
      id: `cup-${career.id}-s${cup.season}`,
      type: 'cup',
      competition: 'Cup',
      season: cup.season,
      result: 'Champions',
    });
  }

  // Prize for the player's run (one-time, ledger-backed).
  const run = playerCupRun(career, cup);
  const prizeKey = { Champions: 'champion', Final: 'runnerUp', 'Semi-final': 'semiFinal', 'Quarter-final': 'quarterFinal' }[run];
  const rewards = liveopsCfg.cupRewards ?? {};
  let prize = 0;
  if (prizeKey && rewards[prizeKey] > 0) {
    prize = rewards[prizeKey];
    recordTransaction(club, {
      type: 'cup_prize',
      amount: prize,
      description: `Cup ${run} prize (Season ${cup.season})`,
    });
  }

  // Milestones (first_cup_title becomes reachable here) + manager XP.
  grantMilestones(career, userId);
  if (isPlayer) {
    grantManagerXp(userId, liveopsCfg.xpSources.cup_champion ?? 0, 'cup_champion');
  }

  if (isPlayer) {
    notify(career, `🏆 CUP CHAMPIONS! Season ${cup.season} cup winners${prize ? ` (+${prize.toLocaleString()})` : ''}.`);
  } else {
    notify(career, `Cup complete: ${champName} are the Season ${cup.season} cup champions.`);
  }
  if (userId) {
    sendInbox(inboxState, userId, {
      type: 'cup',
      title: isPlayer ? `🏆 Cup champions — Season ${cup.season}!` : `Cup complete — ${champName} champions`,
      body: isPlayer
        ? `Your club lifted the cup! Prize +${prize.toLocaleString()} cash.`
        : `${champName} won the Season ${cup.season} cup. Your run: ${run ?? '—'}.`,
    });
    persistInbox();
  }
  autosave(career);
  return { champion: champName, isPlayer, run, prize, trophy: !!trophy };
}

// ---- Phase 37: continental champions finalization ----

/**
 * Finalize a completed continental competition. Same guarantees as the cup:
 * trophy via the existing cabinet (champion only — regression-guarded),
 * one-time ledger prize, milestones, manager XP, inbox, activity.
 * Idempotent via cont.finalized.
 */
function finalizeContinental(career, userId) {
  const cont = career.continental;
  if (!cont || cont.status !== 'complete' || !cont.champion || cont.finalized) return null;
  cont.finalized = true;

  const champName = career.clubs[cont.champion]?.club.name ?? '?';
  const isPlayer = cont.champion === career.playerClubId;
  const club = career.clubs[career.playerClubId].club;

  let trophy = null;
  if (isPlayer) {
    trophy = awardTrophy(career, {
      id: `continental-${career.id}-s${cont.season}`,
      type: 'continental',
      competition: 'Continental Champions',
      season: cont.season,
      result: 'Champions',
    });
  }

  const run = playerContinentalRun(career, cont);
  const rewards = liveopsCfg.continentalRewards ?? {};
  const prizeKey = run === 'Champions' ? 'champion' : run === 'Final' ? 'runnerUp' : null;
  let prize = 0;
  if (prizeKey && rewards[prizeKey] > 0) {
    prize = rewards[prizeKey];
    recordTransaction(club, {
      type: 'continental_prize',
      amount: prize,
      description: `Continental Champions ${run} prize (Season ${cont.season})`,
    });
  }

  grantMilestones(career, userId);
  if (isPlayer) {
    grantManagerXp(userId, liveopsCfg.xpSources.continental_champion ?? 0, 'continental_champion');
  }

  pushActivity(career, liveopsCfg, {
    kind: 'continental',
    key: `continental:s${cont.season}`,
    text: isPlayer
      ? `🏆 Won the Continental Champions (Season ${cont.season})!`
      : `${champName} won the Continental Champions (Season ${cont.season}).`,
  });
  if (isPlayer) {
    notify(career, `🏆 CONTINENTAL CHAMPIONS! Season ${cont.season} winners${prize ? ` (+${prize.toLocaleString()})` : ''}.`);
  } else {
    notify(career, `Continental complete: ${champName} are the Season ${cont.season} champions.`);
  }
  if (userId) {
    sendInbox(inboxState, userId, {
      type: 'continental',
      title: isPlayer ? `🏆 Continental champions — Season ${cont.season}!` : `Continental complete — ${champName} champions`,
      body: isPlayer
        ? `Your club conquered the continent! Prize +${prize.toLocaleString()} cash.`
        : `${champName} won the Season ${cont.season} Continental Champions. Your run: ${run ?? '—'}.`,
    });
    persistInbox();
  }
  autosave(career);
  return { champion: champName, isPlayer, run, prize, trophy: !!trophy };
}

import { careers } from './store.js';

function httpError(status, message) {
  const e = new Error(message);
  e.statusCode = status;
  throw e;
}

function bearerToken(headers) {
  const h = headers?.authorization ?? headers?.Authorization ?? '';
  const m = /^Bearer\s+(.+)$/i.exec(String(h).trim());
  return m ? m[1] : null;
}

function requireUser(ctx) {
  const user = getUserByToken(bearerToken(ctx.headers));
  if (!user) httpError(401, 'login required');
  return user;
}

function getCareer(id) {
  const c = careers.get(id);
  if (!c) httpError(404, 'career not found');
  return c;
}

/** Career owned by the logged-in user, else 403. */
function getOwnCareer(ctx, id) {
  const career = getCareer(id);
  if (!career.userId) httpError(403, 'legacy save has no owner — start a new career');
  if (career.userId !== ctx.user.id) httpError(403, 'not your career');
  return career;
}

function getOleague(id) {
  const lg = oleagues.get(id);
  if (!lg) httpError(404, 'online league not found');
  return lg;
}

function getEvent(id) {
  const ev = events.get(id);
  if (!ev) httpError(404, 'event not found');
  return ev;
}

/** Latest career belonging to a user (by creation order). */
function careerOfUser(userId) {
  let found = null;
  for (const c of careers.values()) {
    if (c.userId === userId) found = c;
  }
  return found;
}

/** Ranked fixture safe for clients: sealed view + opponent username. Never leaks the opponent's config/pool. */
function publicRankedFixture(fx, meId = null) {
  const view = fixtureView(fx, meId);
  if (!view) return null;
  const oppId = meId ? (fx.aUserId === meId ? fx.bUserId : fx.aUserId) : null;
  view.opponent = oppId ? (ranked.ratings[oppId]?.username ?? '?') : null;
  view.homeUser = ranked.ratings[fx.homeUserId]?.username ?? '?';
  view.awayUser = ranked.ratings[fx.awayUserId]?.username ?? '?';
  return view;
}

/**
 * Lazy ranked maintenance for read paths: migrate legacy fixtures, settle
 * overdue ones (deadline → fallback → canonical sim), then run symmetric
 * post-processing for newly completed fixtures.
 */
function settleRankedOverdue() {
  migrateLegacyFixtures(ranked, (uid) => careerOfUser(uid));
  const settled = settleOverdue(ranked, { getCareer: (uid) => careerOfUser(uid) });
  // Phase 40: persist settlements BEFORE post-processing side effects.
  // If the process crashes during postSealedCompletion, the Elo/result is
  // already durable and cannot be re-settled (no duplicate rating changes).
  if (settled.length) persistRanked();
  for (const fx of settled) postSealedCompletion(fx);
  return settled;
}

/**
 * Shared post-processing for a completed sealed ranked fixture.
 * Symmetric for both managers: club records + mirrored rivalry + inbox.
 * Idempotent via fx.postProcessed.
 * Phase 39b (replaces Phase 38 postRankedPlay).
 */
function postSealedCompletion(fx) {
  if (!fx || fx.status !== 'completed' || fx.postProcessed || !fx.result) return;
  fx.postProcessed = true;
  // Phase 40: persist the postProcessed guard BEFORE career side effects.
  // recordMatch/recordRivalryMatch are not idempotent; if the process crashes
  // mid-post-processing, the guard is already durable so a restart cannot
  // duplicate H2H entries, club records, or activity feed items.
  persistRanked();
  const score = fx.result.score;
  for (const uid of [fx.aUserId, fx.bUserId]) {
    const career = careerOfUser(uid);
    const isHome = fx.homeUserId === uid;
    const oppUid = isHome ? fx.awayUserId : fx.homeUserId;
    const oppName = ranked.ratings[oppUid]?.username ?? 'ranked opponent';
    if (career) {
      // Phase 34: ranked matches count toward club records.
      recordMatch(career, {
        gf: isHome ? score.home : score.away,
        ga: isHome ? score.away : score.home,
        opponent: oppName,
        at: Date.now(),
      });
      // Phase 35: ranked rivalry — mirrored for both clubs.
      grantRivalry(career, uid, {
        competition: 'ranked',
        opponentKey: `user:${oppUid}`,
        opponentName: oppName,
        opponentUserId: oppUid,
        gf: isHome ? score.home : score.away,
        ga: isHome ? score.away : score.home,
        at: Date.now(),
      });
      autosave(career);
    }
    const myGoals = isHome ? score.home : score.away;
    const oppGoals = isHome ? score.away : score.home;
    const before = fx.ratingBefore?.[uid] ?? null;
    const after = fx.ratingAfter?.[uid] ?? null;
    const delta = before !== null && after !== null ? after - before : null;
    sendInbox(inboxState, uid, {
      type: 'ranked_result',
      title: `Ranked ${myGoals > oppGoals ? 'win' : myGoals < oppGoals ? 'loss' : 'draw'} ${myGoals}–${oppGoals}`,
      body: `vs ${oppName} (${fx.completedVia === 'deadline' ? 'decided at the preparation deadline' : 'both managers sealed'}).` +
        (delta !== null ? ` Rating ${before} → ${after} (${delta >= 0 ? '+' : ''}${delta}).` : ''),
    });
  }
  persistInbox();
}

function oleagueDetail(ctx, league) {  const table = league.status === 'registration' ? [] : computeTable(league);
  const myId = ctx.user.id;
  const myFixture = league.status === 'active'
    ? league.fixtures.find((f) => f.matchday === league.currentMatchday
      && (f.homeUserId === myId || f.awayUserId === myId)) ?? null
    : null;
  const nameOf = (uid) => league.managers.find((m) => m.userId === uid);
  return {
    league: publicLeague(league),
    isCommissioner: league.commissionerId === myId,
    isMember: league.managers.some((m) => m.userId === myId),
    managers: league.managers.map((m) => ({ username: m.username, clubName: m.clubName })),
    table,
    fixtures: league.fixtures.map((f) => ({
      ...f,
      homeName: nameOf(f.homeUserId)?.clubName ?? '?',
      awayName: nameOf(f.awayUserId)?.clubName ?? '?',
      homeUser: nameOf(f.homeUserId)?.username ?? '?',
      awayUser: nameOf(f.awayUserId)?.username ?? '?',
    })),
    myFixture: myFixture ? {
      ...myFixture,
      homeName: nameOf(myFixture.homeUserId)?.clubName ?? '?',
      awayName: nameOf(myFixture.awayUserId)?.clubName ?? '?',
    } : null,
  };
}

function playerEntry(career) {
  return career.clubs[career.playerClubId];
}

function registries(career) {
  return {
    playersById: new Map(Object.entries(career.players)),
    squadsById: new Map(Object.values(career.clubs).map((c) => [c.club.id, c.squad])),
    clubsById: new Map(Object.values(career.clubs).map((c) => [c.club.id, c.club])),
  };
}

function clubName(career, id) {
  return career.clubs[id]?.club.name ?? id;
}

function stateView(career) {
  const entry = playerEntry(career);
  const league = career.league;
  const md = league.currentMatchday;
  const nextFixture = league.fixtures.find(
    (f) => f.matchday === md + 1 && (f.home === entry.club.id || f.away === entry.club.id)
  );
  const table = getTable(career).map((r) => ({ ...r, name: clubName(career, r.clubId) }));
  return {
    id: career.id,
    season: career.season,
    matchday: md,
    leagueComplete: league.complete,
    totalMatchdays: Math.max(...league.fixtures.map((f) => f.matchday), 0),
    club: entry.club,
    board: entry.board,
    tactics: entry.tactics,
    facilities: entry.facilities,
    staff: entry.staff.members,
    academy: entry.academy.players,
    scouts: career.scouts,
    pvpHistory: career.pvpHistory ?? [],
    squad: {
      ...entry.squad,
      players: entry.squad.players.map((id) => career.players[id]),
    },
    expiringContracts: getExpiring(entry.squad.players.map((id) => career.players[id])).map((p) => p.id),
    nextFixture: nextFixture
      ? {
          matchday: nextFixture.matchday,
          home: clubName(career, nextFixture.home),
          away: clubName(career, nextFixture.away),
          isHome: nextFixture.home === entry.club.id,
        }
      : null,
    table,
    recentResults: league.results.slice(-5).map((r) => ({
      ...r,
      homeName: clubName(career, r.home),
      awayName: clubName(career, r.away),
    })),
    notifications: career.notifications.slice(0, 10),
    activeListings: [...career.market.listings.values()].filter((l) => l.status === 'active').length,
  };
}

/** Seed AI transfer listings so the player can buy. */
function seedAiListings(career) {
  const rng = createRng(`${career.seed}:market`);
  for (const entry of Object.values(career.clubs)) {
    if (entry.isPlayer) continue;
    const sellable = entry.squad.players.filter((id) => !entry.squad.lineup.includes(id));
    for (let i = 0; i < Math.min(2, sellable.length); i++) {
      const pid = sellable.splice(rng.int(0, sellable.length - 1), 1)[0];
      listForSale(career.market, {
        playerId: pid,
        sellerClubId: entry.club.id,
        askingPrice: Math.round(playerValue(career.players[pid]) * 1.3),
      });
    }
  }
}

function autosave(career) {
  try { saveCareer(career); } catch { /* best-effort */ }
}

// --- route table ---
/**

/**
 * Shared post-processing for a played continental matchday (instant + live).
 * Idempotent via ledger/milestone/trophy guards. Phase 38 extraction.
 */
function postContinentalPlay(career, ctx, out) {
  // Player's own fixture: club records, rivalry, manager XP (server-derived).
  if (out.playerResult) {
    const fx = out.playerResult.fixture;
    const isHome = fx.home === career.playerClubId;
    const gf = isHome ? fx.homeScore : fx.awayScore;
    const ga = isHome ? fx.awayScore : fx.homeScore;
    const oppId = isHome ? fx.away : fx.home;
    const oppName = career.clubs[oppId]?.club.name ?? '?';
    recordMatchResult(career, { won: gf > ga, drawn: gf === ga, goalsFor: gf });
    recordMatch(career, { gf, ga, opponent: oppName, at: Date.now() });
    grantRivalry(career, career.userId, {
      competition: 'continental',
      opponentKey: `league:${oppId}`,
      opponentName: oppName,
      gf, ga,
      at: Date.now(),
    });
    if (career.userId) {
      grantManagerXp(career.userId,
        liveopsCfg.xpSources.match_played + (gf > ga ? (liveopsCfg.xpSources.continental_won ?? 0) : 0),
        gf > ga ? 'continental_won' : 'match_played');
    }
  }
  let final = null;
  if (out.champion) final = finalizeContinental(career, career.userId);
  else grantMilestones(career, career.userId); // continental_final unlocks when the final is set
  autosave(career);
  return {
    body: {
      playerResult: out.playerResult ? {
        fixtureId: out.playerResult.fixture.id,
        round: out.playerResult.fixture.round ?? `Matchday ${out.playerResult.fixture.matchday}`,
        homeScore: out.playerResult.fixture.homeScore,
        awayScore: out.playerResult.fixture.awayScore,
        won: out.playerResult.fixture.winner === career.playerClubId,
        report: out.playerResult.report ?? null, // Phase 51: shared report projection
      } : null,
      champion: out.champion ? career.clubs[out.champion]?.club.name ?? null : null,
      final,
      continental: continentalView(career),
    },
  };
}

/**
 * Shared post-processing for a played cup round (instant + live).
 * Idempotent via ledger/milestone/trophy guards. Phase 38 extraction.
 */
function postCupPlay(career, ctx, out) {
  // Player's own fixture: club records, rivalry, manager XP (server-derived).
  if (out.playerResult) {
    const fx = out.playerResult.fixture;
    const isHome = fx.home === career.playerClubId;
    const gf = isHome ? fx.homeScore : fx.awayScore;
    const ga = isHome ? fx.awayScore : fx.homeScore;
    const oppId = isHome ? fx.away : fx.home;
    const oppName = career.clubs[oppId]?.club.name ?? '?';
    recordMatchResult(career, { won: gf > ga, drawn: gf === ga, goalsFor: gf });
    recordMatch(career, { gf, ga, opponent: oppName, at: Date.now() });
    grantRivalry(career, career.userId, {
      competition: 'cup',
      opponentKey: `league:${oppId}`,
      opponentName: oppName,
      gf, ga,
      at: Date.now(),
    });
    if (career.userId) {
      grantManagerXp(career.userId,
        liveopsCfg.xpSources.match_played + (gf > ga ? (liveopsCfg.xpSources.cup_won ?? 0) : 0),
        gf > ga ? 'cup_won' : 'match_played');
    }
  }
  let final = null;
  if (out.champion) final = finalizeCareerCup(career, career.userId);
  autosave(career);
  return {
    body: {
      playerResult: out.playerResult ? {
        fixtureId: out.playerResult.fixture.id,
        round: out.playerResult.fixture.round,
        homeScore: out.playerResult.fixture.homeScore,
        awayScore: out.playerResult.fixture.awayScore,
        won: out.playerResult.fixture.winner === career.playerClubId,
        report: out.playerResult.report ?? null, // Phase 51: shared report projection
      } : null,
      champion: out.champion ? career.clubs[out.champion]?.club.name ?? null : null,
      final,
      cup: cupView(career),
    },
  };
}

const routes = [
  // auth (public)
  {
    method: 'POST', pattern: /^\/api\/auth\/register$/,
    handler: (ctx) => {
      registerUser(ctx.body);
      const login = loginUser(ctx.body); // auto-login
      track('user_registered', { user: { id: login.user.id } });
      return { status: 201, body: login };
    },
  },
  {
    method: 'POST', pattern: /^\/api\/auth\/login$/,
    handler: (ctx) => {
      const login = loginUser(ctx.body);
      track('user_login', { user: { id: login.user.id } });
      return { body: login };
    },
  },
  {
    method: 'POST', pattern: /^\/api\/auth\/logout$/,
    handler: (ctx) => {
      logoutUser(bearerToken(ctx.headers));
      return { body: { ok: true } };
    },
  },
  // careers
  {
    auth: true, method: 'POST', pattern: /^\/api\/career$/,
    handler: (ctx) => {
      const clubName = checkName(ctx.body.clubName, 'clubName');
      assert(clubName.length <= 30, 'clubName max 30 chars');
      const career = createCareer({ clubName });
      career.userId = ctx.user.id;
      seedAiListings(career);
      careers.set(career.id, career);
      autosave(career);
      track('career_created', ctx, { careerId: career.id });
      return { status: 201, body: { id: career.id } };
    },
  },
  {
    method: 'GET', pattern: /^\/api\/career$/,
    handler: (ctx) => {
      const user = requireUser(ctx);
      // Phase 66: list from the in-memory careers map (authoritative, loaded
      // at startup and kept in sync on create/delete) instead of listSaves(),
      // which deserializes every save file on disk per request (18s+ with
      // ~1800 saves). Response shape is unchanged.
      const saves = [...careers.values()]
        .filter((c) => c.userId === user.id)
        .map((c) => {
          const entry = c.clubs[c.playerClubId];
          let updatedAt = 0;
          try { updatedAt = fs.statSync(path.join(SAVE_DIR, `${c.id}.json`)).mtimeMs; } catch { /* ignore */ }
          return {
            id: c.id,
            clubName: entry?.club.name ?? '?',
            season: c.season,
            matchday: c.league.currentMatchday,
            cash: entry?.club.cash ?? 0,
            updatedAt,
          };
        })
        .sort((a, b) => b.updatedAt - a.updatedAt);
      return { body: { saves } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)$/,
    handler: (ctx) => ({ body: stateView(getOwnCareer(ctx, ctx.id)) }),
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/save$/,
    handler: (ctx) => {
      const info = saveCareer(getOwnCareer(ctx, ctx.id));
      return { body: { ok: true, ...info } };
    },
  },
  {
    auth: true, method: 'DELETE', pattern: /^\/api\/career\/([^/]+)$/,
    handler: (ctx) => {
      getOwnCareer(ctx, ctx.id);
      careers.delete(ctx.id);
      deleteSave(ctx.id);
      return { body: { ok: true } };
    },
  },
  // squad & tactics
  {
    auth: true, method: 'PUT', pattern: /^\/api\/career\/([^/]+)\/lineup$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const squad = playerEntry(getOwnCareer(ctx, id)).squad;
      if (body.lineup) setLineup(squad, body.lineup);
      if (body.bench) setBench(squad, body.bench);
      if (body.captainId) setCaptain(squad, body.captainId);
      if (body.setPieces) setSetPieceTakers(squad, body.setPieces);
      return { body: { ok: true } };
    },
  },
  {
    auth: true, method: 'PUT', pattern: /^\/api\/career\/([^/]+)\/tactics$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      // Phase 39a: preserve existing player instructions when the client does
      // not send them (the tactics screen may not manage them).
      const incoming = { ...(body.tactics ?? {}) };
      if (incoming.playerInstructions === undefined) {
        incoming.playerInstructions = playerEntry(career).tactics?.playerInstructions ?? {};
      }
      playerEntry(career).tactics = createTactics(incoming);
      return { body: { ok: true, tactics: playerEntry(career).tactics } };
    },
  },
  // Phase 39a: set/clear a per-player instruction on career tactics (non-live).
  // Client submits only { playerId, arrow }; all effects are server-owned.
  // Instructions apply to XI and bench alike; the engine resolves them by
  // playerId whenever the player is on the pitch.
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/tactics\/instruction$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const entry = playerEntry(career);
      const { playerId, arrow } = ctx.body ?? {};
      if (!playerId) httpError(400, 'playerId required');
      const owned = (entry.squad?.players ?? []).some((p) => p === playerId || p?.id === playerId);
      if (!owned) httpError(403, 'not your player');
      try {
        setPlayerInstruction(entry.tactics, playerId, arrow ?? null);
      } catch (e) {
        httpError(400, e.message);
      }
      autosave(career);
      return { body: { ok: true, playerId, arrow: entry.tactics.playerInstructions[playerId] ?? null } };
    },
  },
  // match
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/play$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const entry = playerEntry(career);
      if (entry.board.status === 'sacked') httpError(403, 'You were sacked. Start a new career.');
      // Phase 38: instant play cannot run while a live league match is active.
      if (hasActiveLive(career) && career.liveMatch.competition === 'league') {
        httpError(400, 'finish or abandon your live match first');
      }
      debounceAction(career.id, 'play');
      const out = advanceMatchday(career);
      return postLeaguePlay(career, ctx, out);
    },
  },
  // ---- Phase 38: live match management ----
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/start$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const entry = playerEntry(career);
      if (entry.board.status === 'sacked') httpError(403, 'You were sacked. Start a new career.');
      debounceAction(career.id, 'live-start');
      const { competition } = ctx.body ?? {};
      if (!isLiveCompetition(competition)) httpError(400, 'unknown competition (league/cup/continental)');
      try {
        const info = startLiveCompetition(career, competition, {
          ranked, userId: ctx.user.id, getCareer: (uid) => careerOfUser(uid),
        });
        autosave(career);
        return { body: { ok: true, ...info, live: liveView(career) } };
      } catch (e) {
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/live$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return { body: { live: liveView(career) } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/continue$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-continue', 500);
      try {
        const out = continueLive(career);
        autosave(career);
        return { body: { ok: true, live: out.view, newEvents: out.newEvents, finished: out.finished } };
      } catch (e) {
        if (e.code === 'MATCH_FULLTIME') httpError(400, e.message);
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/tactics$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-tactics', 500);
      try {
        const out = applyTactics(career, ctx.body?.patch ?? ctx.body);
        autosave(career);
        return { body: { ok: true, live: out.view, applied: out.applied } };
      } catch (e) {
        if (e.code === 'MATCH_FULLTIME') httpError(400, e.message);
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/formation$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-formation', 500);
      try {
        const out = applyFormation(career, ctx.body?.formation);
        autosave(career);
        return { body: { ok: true, live: out.view, formation: out.formation } };
      } catch (e) {
        if (e.code === 'MATCH_FULLTIME') httpError(400, e.message);
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/sub$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-sub', 500);
      try {
        const out = applySubstitution(career, {
          playerOut: ctx.body?.playerOut,
          playerIn: ctx.body?.playerIn,
        });
        autosave(career);
        return { body: { ok: true, live: out.view, newEvents: out.newEvents, subsUsed: out.subsUsed } };
      } catch (e) {
        if (e.code === 'MATCH_FULLTIME' || e.code === 'SUB_LIMIT' || e.code === 'INVALID_SUB') httpError(400, e.message);
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/instruction$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-instruction', 500);
      try {
        const out = applyInstruction(career, {
          playerId: ctx.body?.playerId,
          arrow: ctx.body?.arrow,
        });
        autosave(career);
        return { body: { ok: true, live: out.view, playerId: out.playerId, arrow: out.arrow } };
      } catch (e) {
        if (e.code === 'MATCH_FULLTIME') httpError(400, e.message);
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/abandon$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-abandon');
      try {
        const out = abandonLive(career);
        autosave(career);
        // Abandon fast-forwards to fulltime; the result still needs a finish.
        return { body: { ok: true, live: out.view, newEvents: out.newEvents, finished: out.finished } };
      } catch (e) {
        httpError(400, e.message);
      }
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/live\/finish$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      debounceAction(career.id, 'live-finish');
      const lm = ensureLiveMatch(career);
      if (!lm || !lm.finished || !lm.result) httpError(400, 'no finished live match to complete');
      const result = lm.result;
      const { competition, out } = finishLiveCompetition(career, result, {
        ranked, userId: ctx.user.id, getCareer: (uid) => careerOfUser(uid),
      });
      if (competition === 'ranked') persistRanked();
      // Competition-specific post-processing (shared with instant routes).
      // Phase 39b: ranked is no longer a live competition (sealed duels).
      let body;
      if (competition === 'league') body = postLeaguePlay(career, ctx, out).body;
      else if (competition === 'cup') body = postCupPlay(career, ctx, out).body;
      else if (competition === 'continental') body = postContinentalPlay(career, ctx, out).body;
      else httpError(400, `unknown competition: ${competition}`);
      career.liveMatch = null;
      clearLiveContext(career.id);
      autosave(career);
      return { body: { ...body, liveFinished: true, competition } };
    },
  },
  // training
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/train$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      // Phase 57 (F-1): validate drillId at the boundary. Missing or unknown
      // drillId must be 400, not 500 (getDrillOrThrow throws uncaught).
      if (!body.drillId) httpError(400, 'drillId required');
      if (!getDrills().some((d) => d.id === body.drillId)) {
        httpError(400, `unknown drill: ${body.drillId}`);
      }
      debounceAction(career.id, 'train');
      const entry = playerEntry(career);
      const ent = career.userId ? entOf(career.userId) : blankEntitlements();
      const results = runTrainingSession({
        players: entry.squad.players.map((pid) => career.players[pid]),
        drillId: body.drillId,
        facilityLevel: trainingGroundLevel(entry.facilities),
        staff: entry.staff,
        xpBonus: trainingXpMult(ent, shopCfg),
        rng: createRng(`${career.seed}:train:${Date.now()}`),
      });
      track('training_done', ctx, { drillId: body.drillId });
      grantStatReward(career, 'trainings');
      if (career.userId) grantManagerXp(career.userId, liveopsCfg.xpSources.training_done, 'training_done');
      autosave(career); // Phase 32: training mutated state but never persisted
      return { body: { results } };
    },
  },
  // tables
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/table$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return { body: { table: getTable(career).map((r) => ({ ...r, name: clubName(career, r.clubId) })) } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/scorers$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return {
        body: {
          scorers: getScorers(career, 10).map((s) => ({ ...s, clubName: clubName(career, s.clubId) })),
        },
      };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/fixtures$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const mine = career.league.fixtures.filter(
        (f) => f.home === career.playerClubId || f.away === career.playerClubId
      );
      return {
        body: {
          fixtures: mine.map((f) => ({
            ...f,
            homeName: clubName(career, f.home),
            awayName: clubName(career, f.away),
          })),
        },
      };
    },
  },
  // transfer market
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/market$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const listings = [...career.market.listings.values()]
        .filter((l) => l.status === 'active')
        .map((l) => ({
          ...l,
          player: career.players[l.playerId],
          sellerName: clubName(career, l.sellerClubId),
          mine: l.sellerClubId === career.playerClubId,
        }));
      return { body: { listings, windowOpen: career.market.windowOpen } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/market\/list$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const listing = listForSale(career.market, {
        playerId: body.playerId,
        sellerClubId: career.playerClubId,
        askingPrice: body.askingPrice,
      });
      notify(career, `${career.players[body.playerId].name} listed for ${body.askingPrice.toLocaleString()}.`);
      return { status: 201, body: { listing } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/market\/offer$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const listing = career.market.listings.get(body.listingId);
      if (!listing || listing.sellerClubId === career.playerClubId) {
        httpError(400, 'You can only bid on other clubs\u2019 players');
      }
      const offer = makeOffer(career.market, {
        listingId: listing.id,
        fromClubId: career.playerClubId,
        fee: body.fee,
        wageOffer: body.wageOffer,
        years: body.years,
      });
      const { decision, counter } = evaluateOffer(career.market, offer.id);
      if (decision === 'accepted') {
        const record = completeTransfer(career.market, offer.id, registries(career));
        notify(career, `Signed ${record.playerName} for ${record.fee.toLocaleString()}!`);
        grantStatReward(career, 'signings');
        autosave(career);
        return { body: { decision, record } };
      }
      return { body: { decision, counter: counter ?? null } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/market\/counter$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const counter = answerCounter(career.market, body.counterId, body.accept !== false);
      if (counter.status === 'accepted') {
        counter.fromClubId = career.playerClubId;
        const record = completeTransfer(career.market, counter.id, registries(career));
        notify(career, `Signed ${record.playerName} for ${record.fee.toLocaleString()}!`);
        grantStatReward(career, 'signings');
        autosave(career);
        return { body: { decision: 'accepted', record } };
      }
      return { body: { decision: 'rejected' } };
    },
  },
  // scouting
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/scout\/hire$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const scout = hireScout({ name: body.name, level: body.level ?? 1, region: body.region });
      career.scouts.push(scout);
      return { status: 201, body: { scout } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/scout\/assign$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const entry = playerEntry(career);
      const scout = career.scouts.find((s) => s.id === body.scoutId);
      if (!scout) httpError(404, 'scout not found');
      const { reports, cost } = scoutPlayers({
        scout,
        club: entry.club,
        criteria: body.criteria ?? {},
        rng: createRng(`${career.seed}:scout:${Date.now()}`),
      });
      return {
        body: {
          cost,
          reports: reports.map((r) => ({
            id: r.id,
            scoutName: r.scoutName,
            playerId: r.playerId,
            reported: r.reported,
            accuracy: r.accuracy,
          })),
        },
      };
    },
  },
  // staff
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/staff\/hire$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const member = hireStaff(playerEntry(career).staff, {
        name: body.name,
        role: body.role,
        level: body.level ?? 1,
      });
      return { status: 201, body: { member } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/staff\/fire$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      return { body: { member: fireStaff(playerEntry(career).staff, body.staffId) } };
    },
  },
  // facilities
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/facilities\/upgrade$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const entry = playerEntry(career);
      const cost = upgradeFacility(entry.facilities, entry.club, body.type);
      notify(career, `${body.type} upgraded (cost ${cost.toLocaleString()}).`);
      grantStatReward(career, 'facilitiesUpgraded');
      grantMilestones(career, career.userId); // Phase 34: facility milestones
      autosave(career); // Phase 32: upgrade mutated state but never persisted
      return { body: { ok: true, cost, facilities: entry.facilities } };
    },
  },
  // youth
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/youth\/intake$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const entry = playerEntry(career);
      const playersById = new Map(Object.entries(career.players));
      const intake = youthIntake({
        academy: entry.academy,
        club: entry.club,
        facilities: entry.facilities,
        rng: createRng(`${career.seed}:youth:${career.season}`),
        playersById,
      });
      for (const p of intake) career.players[p.id] = p;
      notify(career, `${intake.length} youth prospects joined the academy.`);
      return { body: { intake } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/youth\/promote$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const entry = playerEntry(career);
      const player = promoteToSenior({ academy: entry.academy, playerId: body.playerId, squad: entry.squad, wage: body.wage });
      notify(career, `${player.name} promoted to the first team!`);
      grantStatReward(career, 'youthPromoted');
      autosave(career);
      return { body: { player } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/youth\/release$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const entry = playerEntry(career);
      const playersById = new Map(Object.entries(career.players));
      const player = releaseYouth({ academy: entry.academy, playerId: body.playerId, playersById });
      delete career.players[player.id];
      return { body: { ok: true } };
    },
  },
  // contracts
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/contracts\/offer$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const player = career.players[body.playerId];
      if (!player) httpError(404, 'player not found');
      return { body: offerContract(player, body.terms) };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/contracts\/sign$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const player = career.players[body.playerId];
      if (!player) httpError(404, 'player not found');
      signContract(player, body.terms);
      notify(career, `${player.name} signed a new ${body.terms.years}-year deal.`);
      return { body: { ok: true } };
    },
  },
  // finance
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/finance$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const entry = playerEntry(career);
      const players = entry.squad.players.map((pid) => career.players[pid]);
      return {
        body: {
          cash: entry.club.cash,
          ledger: getLedger(entry.club, { limit: 30 }),
          health: financialHealth(entry.club, { players, staffRoster: entry.staff }),
        },
      };
    },
  },
  // pvp
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/pvp\/challenge$/,
    handler: (ctx) => {
      const { id, body } = ctx;
      const career = getOwnCareer(ctx, id);
      const oppUser = getUserByName(body.username);
      if (!oppUser) httpError(404, 'manager not found');
      if (oppUser.id === ctx.user.id) httpError(400, 'cannot challenge yourself');
      const opponent = [...careers.values()].find((c) => c.userId === oppUser.id);
      if (!opponent) httpError(404, 'that manager has no career yet');
      const { result, record } = playFriendly({ challenger: career, opponent });
      autosave(career);
      autosave(opponent);
      return {
        body: {
          record,
          score: result.score,
          winner: result.winner,
          home: result.home,
          away: result.away,
        },
      };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/pvp\/history$/,
    handler: (ctx) => ({
      body: { history: getOwnCareer(ctx, ctx.id).pvpHistory ?? [] },
    }),
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/leaderboard$/,
    handler: (ctx) => {
      requireUser(ctx);
      const board = buildLeaderboard(careers, (uid) => getUserById(uid)?.username ?? '?');
      return { body: { leaderboard: board } };
    },
  },
  // ---- online leagues (Phase 21) ----
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.body.careerId);
      const league = createLeague({
        name: ctx.body.name,
        userId: ctx.user.id,
        username: ctx.user.username,
        maxManagers: ctx.body.maxManagers,
      });
      joinLeague(league, {
        userId: ctx.user.id,
        username: ctx.user.username,
        careerId: career.id,
        clubName: career.clubs[career.playerClubId].club.name,
      });
      oleagues.set(league.id, league);
      persistOleagues();
      return { status: 201, body: { id: league.id } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/oleagues$/,
    handler: (ctx) => {
      requireUser(ctx);
      return { body: { leagues: [...oleagues.values()].map(publicLeague) } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/oleagues\/([^/]+)$/,
    handler: (ctx) => ({ body: oleagueDetail(ctx, getOleague(ctx.id)) }),
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues\/([^/]+)\/join$/,
    handler: (ctx) => {
      const league = getOleague(ctx.id);
      const career = getOwnCareer(ctx, ctx.body.careerId);
      joinLeague(league, {
        userId: ctx.user.id,
        username: ctx.user.username,
        careerId: career.id,
        clubName: career.clubs[career.playerClubId].club.name,
      });
      persistOleagues();
      return { body: { ok: true } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues\/([^/]+)\/leave$/,
    handler: (ctx) => {
      const league = getOleague(ctx.id);
      const res = leaveLeague(league, ctx.user.id);
      if (res === 'empty') oleagues.delete(league.id);
      persistOleagues();
      return { body: { ok: true } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues\/([^/]+)\/start$/,
    handler: (ctx) => {
      const league = getOleague(ctx.id);
      if (ctx.user.id !== league.commissionerId) httpError(403, 'only the commissioner can start');
      startSeason(league, (uid) => careerOfUser(uid));
      persistOleagues();
      return { body: { ok: true, totalMatchdays: league.totalMatchdays } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues\/([^/]+)\/play$/,
    handler: (ctx) => {
      const league = getOleague(ctx.id);
      const out = playFixture(league, ctx.user.id, (uid) => careerOfUser(uid));
      persistOleagues();
      const career = careerOfUser(ctx.user.id);
      if (career) autosave(career);
      return {
        body: {
          alreadyPlayed: out.alreadyPlayed,
          fixture: out.fixture,
          score: out.result ? out.result.score : { home: out.fixture.homeScore, away: out.fixture.awayScore },
        },
      };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues\/([^/]+)\/advance$/,
    handler: (ctx) => {
      const league = getOleague(ctx.id);
      const wasActive = league.status === 'active';
      try {
        advanceOnlineMatchday(league, ctx.user.id, { force: ctx.body?.force === true });
      } catch (e) {
        httpError(409, e.message);
      }
      let seasonRewards = [];
      // Pay top-3 season prizes once, at the active -> complete transition.
      if (wasActive && league.status === 'complete' && league.rewardsPaidSeason !== league.season) {
        const table = computeTable(league);
        seasonRewards = applyLeagueSeasonRewards(
          leagueSeasonRewards(table, rewardCfg),
          (uid) => careerOfUser(uid)
        );
        for (const r of seasonRewards) {
          const c = careerOfUser(r.userId);
          if (c) autosave(c);
        }
        league.rewardsPaidSeason = league.season;
      }
      persistOleagues();
      return { body: { ok: true, status: league.status, currentMatchday: league.currentMatchday, champion: league.champion, seasonRewards } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/oleagues\/([^/]+)\/new-season$/,
    handler: (ctx) => {
      const league = getOleague(ctx.id);
      newSeason(league, ctx.user.id, (uid) => careerOfUser(uid));
      persistOleagues();
      return { body: { ok: true, season: league.season } };
    },
  },
  // ---- competitive PvP / ranked (Phase 22; sealed duels Phase 39b) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/pvp\/ranked$/,
    handler: (ctx) => {
      const e = getEntry(ranked, ctx.user.id, ctx.user.username);
      settleRankedOverdue();
      const fixture = ranked.fixtures.find((f) => isPendingFixture(f)
        && (f.aUserId === ctx.user.id || f.bUserId === ctx.user.id));
      // Phase 33: seasonal dashboard data + idempotent season-ending reminder
      maybeSeasonReminder(ctx.user.id);
      const live = snapshotStandings(ranked);
      const myRank = live.findIndex((r) => r.userId === ctx.user.id) + 1 || null;
      const myHistory = (ranked.seasonHistory ?? [])
        .map((h) => {
          const row = h.standings.find((s) => s.userId === ctx.user.id);
          const rw = h.rewards.find((r) => r.userId === ctx.user.id);
          return row ? {
            season: h.season, endedAt: h.endedAt, rank: row.rank,
            rating: row.rating, tier: row.tier, w: row.w, d: row.d, l: row.l,
            rewardAmount: rw ? rw.amount : 0,
          } : null;
        })
        .filter(Boolean)
        .slice(0, 3);
      return {
        body: {
          rating: e.rating,
          tier: tierFor(e.rating),
          wins: e.w, draws: e.d, losses: e.l,
          season: ranked.season,
          timeRemainingMs: Math.max(0, ranked.season.endsAt - Date.now()),
          seasonEnded: seasonEnded(ranked),
          myRank,
          tierRewards: TIER_REWARDS,
          myTierReward: (e.w + e.d + e.l) > 0 ? TIER_REWARDS[tierFor(e.rating)] : 0,
          seasonGoals: seasonGoalProgress(e),
          mySeasonHistory: myHistory,
          inQueue: ranked.queue.some((q) => q.userId === ctx.user.id),
          queueSize: ranked.queue.length,
          fixture: fixture ? publicRankedFixture(fixture, ctx.user.id) : null,
          preparationWindowMs: PREPARATION_WINDOW_MS,
        },
      };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/pvp\/ranked\/fixture$/,
    handler: (ctx) => {
      const id = ctx.searchParams.get('id');
      if (!id) httpError(400, 'id required');
      settleRankedOverdue();
      const fx = ranked.fixtures.find((f) => f.id === id);
      if (!fx) httpError(404, 'fixture not found');
      if (fx.aUserId !== ctx.user.id && fx.bUserId !== ctx.user.id) httpError(403, 'not your fixture');
      return { body: { fixture: publicRankedFixture(fx, ctx.user.id) } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/pvp\/queue\/join$/,
    handler: (ctx) => {
      settleRankedOverdue();
      const fx = joinQueue(ranked, { userId: ctx.user.id, username: ctx.user.username },
        (uid) => careerOfUser(uid));
      persistRanked();
      if (fx) {
        // Phase 39b: notify both managers of the sealed-duel preparation window.
        const oppId = fx.aUserId === ctx.user.id ? fx.bUserId : fx.aUserId;
        const oppName = ranked.ratings[oppId]?.username ?? '?';
        for (const [uid, vs] of [[ctx.user.id, oppName], [oppId, ctx.user.username]]) {
          sendInbox(inboxState, uid, {
            type: 'ranked_fixture',
            title: `Ranked fixture vs ${vs}`,
            body: `Prepare your tactics and seal them within 24 hours. If you don't seal, your fallback configuration (frozen at matchmaking) will be used.`,
          });
        }
        persistInbox();
      }
      return { body: { matched: !!fx, fixture: fx ? publicRankedFixture(fx, ctx.user.id) : null } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/pvp\/queue\/leave$/,
    handler: (ctx) => {
      leaveQueue(ranked, ctx.user.id);
      persistRanked();
      return { body: { ok: true } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/pvp\/queue\/poll$/,
    handler: (ctx) => {
      // waiting managers poll for a match (also attempts matchmaking)
      settleRankedOverdue();
      if (!ranked.queue.some((q) => q.userId === ctx.user.id)) {
        return { body: { matched: false, inQueue: false } };
      }
      const fx = tryMatch(ranked, (uid) => careerOfUser(uid));
      persistRanked();
      const mine = fx && (fx.aUserId === ctx.user.id || fx.bUserId === ctx.user.id) ? fx
        : ranked.fixtures.find((f) => isPendingFixture(f)
          && (f.aUserId === ctx.user.id || f.bUserId === ctx.user.id));
      return { body: { matched: !!mine, inQueue: !mine, fixture: mine ? publicRankedFixture(mine, ctx.user.id) : null } };
    },
  },
  {
    // Phase 39b: seal a tactical configuration for a ranked fixture.
    // Body: { fixtureId, lineupIds[11], benchIds[], formation, tactics{}, plan[], playerInstructions{} }.
    // Tactical choices only — condition is snapshotted server-side.
    // Phase 39c: playerInstructions { playerId: 'red'|'blue' } accepted and validated.
    auth: true, method: 'POST', pattern: /^\/api\/pvp\/ranked\/seal$/,
    handler: (ctx) => {
      const body = ctx.body ?? {};
      if (!body.fixtureId) httpError(400, 'fixtureId required');
      settleRankedOverdue();
      let out;
      try {
        out = sealFixture(ranked, body.fixtureId, ctx.user.id, {
          lineupIds: body.lineupIds,
          benchIds: body.benchIds,
          formation: body.formation,
          tactics: body.tactics,
          plan: body.plan,
          playerInstructions: body.playerInstructions,
        }, (uid) => careerOfUser(uid));
      } catch (e) {
        if (e.code === 'ALREADY_SEALED') httpError(409, e.message);
        if (e.code === 'DEADLINE_PASSED') httpError(410, e.message);
        throw e;
      }
      persistRanked();
      const fx = out.fixture;
      if (!out.alreadySealed) {
        const oppId = fx.aUserId === ctx.user.id ? fx.bUserId : fx.aUserId;
        sendInbox(inboxState, oppId, {
          type: 'ranked_sealed',
          title: 'Ranked: opponent sealed their tactics',
          body: `${ctx.user.username} locked their tactical configuration.` +
            (fx.sealed[oppId] ? ' Both sides sealed — the canonical match is being simulated.' : ' Seal yours before the deadline.'),
        });
        persistInbox();
      }
      if (out.simulated) postSealedCompletion(fx);
      return {
        body: {
          alreadySealed: out.alreadySealed,
          simulated: out.simulated,
          fixture: publicRankedFixture(fx, ctx.user.id),
        },
      };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/pvp\/leaderboard$/,
    handler: (ctx) => {
      requireUser(ctx);
      // Phase 33: season-scoped leaderboard (?season=N). Defaults to current.
      const q = ctx.searchParams.get('season');
      const seasonNumber = q === null || q === '' ? ranked.season.number : parseInt(q, 10);
      if (!Number.isInteger(seasonNumber) || seasonNumber < 1) httpError(400, 'invalid season');
      const board = seasonStandings(ranked, seasonNumber).slice(0, 50).map((r) => ({
        rank: r.rank, username: r.username, rating: r.rating, tier: r.tier,
        w: r.w, d: r.d, l: r.l,
      }));
      return { body: { leaderboard: board, season: seasonNumber, currentSeason: ranked.season.number } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/pvp\/season\/history$/,
    handler: (ctx) => {
      requireUser(ctx);
      return {
        body: {
          currentSeason: ranked.season.number,
          history: (ranked.seasonHistory ?? []).map((h) => ({
            season: h.season,
            endedAt: h.endedAt,
            participants: h.standings.length,
            top3: h.standings.slice(0, 3).map((s) => ({ rank: s.rank, username: s.username, rating: s.rating, tier: s.tier })),
          })),
        },
      };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/pvp\/season\/rollover$/,
    handler: (ctx) => {
      // Phase 33: route through the idempotent finalization service
      // (snapshots standings, records history, sends inbox notifications).
      const before = ranked.season.number;
      const out = finalizeRankedSeason(ranked, before, {
        getCareer: (uid) => careerOfUser(uid),
        applyReward: (career, amount, text) => {
          defaultApplyReward(career, amount, text);
          autosave(career);
        },
        notifyUser: (uid, msg) => {
          sendInbox(inboxState, uid, { type: msg.type, title: msg.title, body: msg.body });
        },
      });
      persistRanked();
      persistInbox();
      // Phase 34: ranked trophies for the top-3 + milestone check (all idempotent)
      for (const row of (out.standings || []).slice(0, 3)) {
        const career = careerOfUser(row.userId);
        if (!career) continue;
        const got = awardTrophy(career, {
          id: `ranked-${row.userId}-s${out.season}`,
          type: 'ranked',
          competition: 'Ranked Arena',
          season: out.season,
          result: `Rank ${row.rank}`,
        });
        if (got) notify(career, `🏆 Ranked trophy: finished #${row.rank} in season ${out.season}!`);
        grantMilestones(career, row.userId);
      }
      return {
        body: {
          ok: true, fromSeason: before, toSeason: ranked.season.number,
          rewards: out.rewards, participants: out.standings.length,
        },
      };
    },
  },
  // ---- rewards (Phase 23) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/rewards\/daily$/,
    handler: (ctx) => {
      const st = dailyStatus(daily, ctx.user.id, dayString(), rewardCfg);
      return { body: { ...st, username: ctx.user.username } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/rewards\/daily\/claim$/,
    handler: (ctx) => {
      const career = careerOfUser(ctx.user.id);
      if (!career) httpError(400, 'create a career first to claim rewards');
      const out = claimDaily(daily, ctx.user.id, dayString(), rewardCfg);
      persistDaily();
      if (!out.alreadyClaimed) {
        const club = career.clubs[career.playerClubId].club;
        const vipBonus = vipDailyBonus(entOf(ctx.user.id), shopCfg);
        const total = out.reward.cash + out.bonus + vipBonus;
        recordTransaction(club, {
          type: 'daily_reward',
          amount: total,
          description: `Daily reward — day ${out.streak} (${out.reward.label})${out.bonus ? ' + week bonus' : ''}${vipBonus ? ' + VIP bonus' : ''}`,
        });
        notify(career, `🎁 Daily reward claimed: +${total.toLocaleString()} (day ${out.streak}).`);
        autosave(career);
        track('daily_claimed', ctx, { streak: out.streak });
        grantManagerXp(ctx.user.id, liveopsCfg.xpSources.daily_claim, 'daily_claim');
      }
      return { body: { ...out } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/achievements$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return { body: { achievements: achievementProgress(career, rewardCfg) } };
    },
  },
  // ---- events (Phase 24) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/events$/,
    handler: (ctx) => {
      const now = Date.now();
      // Phase 33: event-ending reminders (joined events only, once per event)
      maybeEventReminders(ctx.user.id, now);
      const list = [...events.values()]
        .map((ev) => publicEvent(ev, ctx.user.id, now))
        .sort((a, b) => b.startsAt - a.startsAt);
      return {
        body: {
          events: list,
          templates: eventCfg.templates.map((t) => ({
            id: t.id, name: t.name, description: t.description,
            durationDays: t.durationDays, scoring: t.scoring,
            rewards: t.rewards, maxParticipants: t.maxParticipants,
          })),
        },
      };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/events\/([^/]+)$/,
    handler: (ctx) => ({ body: publicEvent(getEvent(ctx.id), ctx.user.id) }),
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/events$/,
    handler: (ctx) => {
      const now = Date.now();
      const active = [...events.values()].filter((ev) => eventStatus(ev, now) !== 'ended').length;
      if (active >= eventCfg.maxActiveEvents) {
        httpError(409, `too many live events (max ${eventCfg.maxActiveEvents})`);
      }
      const ev = createEvent(eventCfg, {
        templateId: ctx.body.templateId,
        createdBy: ctx.user.id,
        now,
      });
      events.set(ev.id, ev);
      persistEvents();
      return { status: 201, body: { id: ev.id } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/events\/([^/]+)\/join$/,
    handler: (ctx) => {
      const ev = getEvent(ctx.id);
      if (!careerOfUser(ctx.user.id)) httpError(400, 'create a career first to join events');
      joinEvent(ev, { userId: ctx.user.id, username: ctx.user.username });
      persistEvents();
      track('event_joined', ctx, { eventId: ev.id });
      grantManagerXp(ctx.user.id, liveopsCfg.xpSources.event_joined, 'event_joined');
      return { body: { ok: true } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/events\/([^/]+)\/settle$/,
    handler: (ctx) => {
      const ev = getEvent(ctx.id);
      const payouts = settleEvent(ev, eventCfg, { getCareer: (uid) => careerOfUser(uid) });
      for (const p of payouts) {
        const c = careerOfUser(p.userId);
        if (c) autosave(c);
      }
      persistEvents();
      return { body: { ok: true, payouts } };
    },
  },
  // ---- shop / monetization (Phase 25) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/shop$/,
    handler: (ctx) => {
      const myOrders = [...orders.values()]
        .filter((o) => o.userId === ctx.user.id)
        .sort((a, b) => b.createdAt - a.createdAt)
        .slice(0, 20)
        .map((o) => ({ id: o.id, productName: o.productName, amountIdr: o.amountIdr, status: o.status, createdAt: o.createdAt }));
      return {
        body: {
          products: shopCfg.products.map((p) => ({
            id: p.id, type: p.type, name: p.name, description: p.description,
            priceIdr: p.priceIdr, days: p.days ?? null,
          })),
          entitlements: publicEntitlements(entOf(ctx.user.id), shopCfg),
          orders: myOrders,
          paymentsLive: false, // mock provider; see server/src/shop/provider.js
        },
      };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/shop\/purchase$/,
    handler: async (ctx) => {
      const product = getProduct(shopCfg, ctx.body.productId);
      if ((product.type === 'cash' || product.type === 'heal') && !careerOfUser(ctx.user.id)) {
        httpError(400, 'create a career first to use this product');
      }
      const order = createOrder(
        { userId: ctx.user.id, username: ctx.user.username, productId: product.id },
        shopCfg
      );
      orders.set(order.id, order);
      persistOrders();
      const receipt = await charge(order);
      if (!receipt.ok) {
        order.status = 'failed';
        persistOrders();
        httpError(502, 'payment failed');
      }
      order.txId = receipt.txId;
      const granted = completeOrder(order, product, {
        now: Date.now(),
        getCareer: (uid) => careerOfUser(uid),
        getEnt: () => entOf(ctx.user.id),
        saveEnt: (ent) => { entitlements.set(ctx.user.id, ent); persistEntitlements(); },
        saveCareer: (career) => autosave(career),
      });
      persistOrders();
      persistEntitlements();
      track('shop_purchase', ctx, { productId: product.id, amountIdr: order.amountIdr });
      return { body: { ok: true, order: { id: order.id, status: order.status, txId: order.txId }, granted } };
    },
  },
  // ---- analytics (Phase 26) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/analytics\/summary$/,
    handler: (ctx) => {
      const days = Math.min(90, Math.max(1, parseInt(ctx.searchParams.get('days') || '30', 10) || 30));
      return { body: summarize(analyticsEvents, { since: Date.now() - days * 86400000 }) };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/analytics\/recent$/,
    handler: () => ({
      body: { events: analyticsEvents.slice(-50).reverse() },
    }),
  },
  // ---- live ops: objectives (Phase 32) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/objectives$/,
    handler: (ctx) => {
      const now = Date.now();
      const metrics = metricsFor(ctx.user.id);
      const out = {};
      for (const period of ['daily', 'weekly']) {
        const ps = ensurePeriod(objectiveState, ctx.user.id, period, metrics, now);
        persistObjectives();
        out[period] = {
          key: periodKey(period, now),
          endsAt: periodEnd(period, now),
          items: liveopsCfg.objectives[period].map((d) => objectiveView(d, ps, metrics)),
        };
      }
      return { body: out };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/objectives\/([^/]+)\/claim$/,
    handler: (ctx) => {
      const now = Date.now();
      const metrics = metricsFor(ctx.user.id);
      let def = null;
      let period = null;
      for (const p of ['daily', 'weekly']) {
        const d = liveopsCfg.objectives[p].find((x) => x.id === ctx.id);
        if (d) { def = d; period = p; break; }
      }
      if (!def) httpError(404, 'objective not found');
      const ps = ensurePeriod(objectiveState, ctx.user.id, period, metrics, now);
      const claimed = claimObjective(liveopsCfg.objectives[period], ps, ctx.id, metrics);
      persistObjectives();
      const career = careerOfUser(ctx.user.id);
      if (career) {
        const club = career.clubs[career.playerClubId].club;
        recordTransaction(club, {
          type: 'objective_reward',
          amount: claimed.cash,
          description: `Objective: ${claimed.title}`,
        });
        notify(career, `🎯 Objective "${claimed.title}" complete! +${claimed.cash.toLocaleString()}.`);
        autosave(career);
      }
      grantManagerXp(ctx.user.id, liveopsCfg.xpSources.objective_claimed, 'objective_claimed');
      sendInbox(inboxState, ctx.user.id, {
        type: 'objective',
        title: `Objective complete: ${claimed.title}`,
        body: `Reward: +${claimed.cash.toLocaleString()} cash, +${liveopsCfg.xpSources.objective_claimed} manager XP.`,
      });
      persistInbox();
      track('objective_claimed', ctx, { objectiveId: claimed.id });
      return { body: { ok: true, cash: claimed.cash } };
    },
  },
  // ---- live ops: manager progression + reward track (Phase 32) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/manager$/,
    handler: (ctx) => {
      const mgr = mgrOf(ctx.user.id);
      persistManager();
      return {
        body: {
          xp: mgr.xp,
          level: mgr.level,
          next: xpForNextLevel(liveopsCfg, mgr.xp),
          history: mgr.history.slice(0, 10),
        },
      };
    },
  },
  // ---- Phase 34: club legacy & manager identity ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/legacy\/([^/]+)$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return { body: legacyView(career, ctx.user.id) };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/legacy\/([^/]+)\/milestones\/check$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const newly = grantMilestones(career, ctx.user.id);
      return { body: { unlocked: newly.map((m) => m.id) } };
    },
  },
  {
    auth: true, method: 'PUT', pattern: /^\/api\/career\/([^/]+)\/identity$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const body = ctx.body ?? {};
      const identity = updateIdentity(career, {
        motto: body.motto,
        stadiumName: body.stadiumName,
      });
      autosave(career);
      return { body: { identity } };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/manager\/profile$/,
    handler: (ctx) => {
      const user = requireUser(ctx);
      const all = [...careers.values()];
      return { body: ownManagerProfile(user, mgrOf(user.id), all, liveopsCfg, rankedCtxOf) };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/profile\/([^/]+)$/,
    handler: (ctx) => {
      requireUser(ctx);
      const target = getUserByName(ctx.id);
      if (!target) httpError(404, 'manager not found');
      const all = [...careers.values()];
      return { body: publicManagerProfile(target, mgrOf(target.id), all, liveopsCfg, rankedCtxOf) };
    },
  },
  // ---- Phase 35: club community & rivalries ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/rivals$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      ensureRivalry(career);
      const rivalries = rivalriesFromMatches(career, liveopsCfg);
      return {
        body: {
          rivals: rivalries.slice(0, 8).map((r) => publicRivalry(r)),
          activity: career.legacy.activity.slice(0, 10),
          milestones: rivalryMilestoneProgress(career, liveopsCfg),
        },
      };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/rivals\/(.+)$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const key = ctx.params?.[1] ?? '';
      const r = rivalryFor(career, liveopsCfg, key);
      if (!r) httpError(404, 'rivalry not found');
      return { body: rivalDetail(career, ctx.user.id, r) };
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/manager\/compare\/([^/]+)$/,
    handler: (ctx) => {
      const me = requireUser(ctx);
      const them = getUserByName(ctx.id);
      if (!them) httpError(404, 'manager not found');
      return { body: managerCompare(me, them) };
    },
  },
  // ---- Phase 37: continental champions ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/continental$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return { body: continentalView(career) };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/continental\/play$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      // Phase 38: cannot instant-play while a live continental tie is active.
      if (hasActiveLive(career) && career.liveMatch.competition === 'continental') {
        httpError(400, 'finish or abandon your live match first');
      }
      debounceAction(career.id, 'continental');
      const cont = ensureContinental(career);
      if (!cont) httpError(400, 'not qualified for the continental competition');
      if (cont.status === 'complete') httpError(400, 'continental is already complete');
      const out = playContinental(career);
      return postContinentalPlay(career, ctx, out);
    },
  },
  // ---- Phase 36: career cup ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/cup$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      return { body: cupView(career) };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/career\/([^/]+)\/cup\/play$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      // Phase 38: cannot instant-play while a live cup tie is active.
      if (hasActiveLive(career) && career.liveMatch.competition === 'cup') {
        httpError(400, 'finish or abandon your live match first');
      }
      debounceAction(career.id, 'cup');
      const cup = ensureCup(career);
      if (cup.status !== 'active') httpError(400, 'cup is already complete');
      const out = playCupRound(career);
      return postCupPlay(career, ctx, out);
    },
  },
  {
    auth: true, method: 'GET', pattern: /^\/api\/reward-track$/,
    handler: (ctx) => {
      const mgr = mgrOf(ctx.user.id);
      return { body: { xp: mgr.xp, levels: trackView(liveopsCfg, mgr) } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/reward-track\/([^/]+)\/claim$/,
    handler: (ctx) => {
      const level = parseInt(ctx.id, 10);
      if (!Number.isInteger(level)) httpError(400, 'invalid track level');
      const mgr = mgrOf(ctx.user.id);
      const def = claimTrackLevel(liveopsCfg, mgr, level);
      persistManager();
      const career = careerOfUser(ctx.user.id);
      if (career) {
        const club = career.clubs[career.playerClubId].club;
        recordTransaction(club, {
          type: 'reward_track',
          amount: def.cash,
          description: `Reward track level ${def.level}`,
        });
        notify(career, `🎖️ Reward track level ${def.level} claimed: +${def.cash.toLocaleString()}.`);
        autosave(career);
      }
      sendInbox(inboxState, ctx.user.id, {
        type: 'reward_track',
        title: `Reward track level ${def.level} claimed`,
        body: `+${def.cash.toLocaleString()} cash.`,
      });
      persistInbox();
      return { body: { ok: true, cash: def.cash } };
    },
  },
  // ---- live ops: inbox (Phase 32) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/inbox$/,
    handler: (ctx) => {
      persistInbox();
      return { body: listInbox(inboxState, ctx.user.id) };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/inbox\/read-all$/,
    handler: (ctx) => {
      const n = markAllRead(inboxState, ctx.user.id);
      persistInbox();
      return { body: { ok: true, marked: n } };
    },
  },
  {
    auth: true, method: 'POST', pattern: /^\/api\/inbox\/([^/]+)\/read$/,
    handler: (ctx) => {
      markRead(inboxState, ctx.user.id, ctx.id);
      persistInbox();
      return { body: { ok: true } };
    },
  },
  // ---- live ops: season presentation (Phase 32) ----
  {
    auth: true, method: 'GET', pattern: /^\/api\/career\/([^/]+)\/season$/,
    handler: (ctx) => {
      const career = getOwnCareer(ctx, ctx.id);
      const table = getTable(career);
      const row = table.find((r) => r.clubId === career.playerClubId) ?? {};
      const st = career.stats ?? {};
      const league = career.league ?? {};
      const md = league.currentMatchday ?? 0;
      const totalMd = league.fixtures
        ? new Set(league.fixtures.map((f) => f.matchday)).size
        : 0;
      return {
        body: {
          season: career.season,
          matchday: md,
          totalMatchdays: totalMd,
          progressPct: totalMd ? Math.round((md / totalMd) * 100) : 0,
          position: table.findIndex((r) => r.clubId === career.playerClubId) + 1,
          played: row.played ?? st.played ?? 0,
          won: row.won ?? st.wins ?? 0,
          drawn: row.drawn ?? st.draws ?? 0,
          lost: row.lost ?? st.losses ?? 0,
          points: row.points ?? 0,
          goalsFor: row.gf ?? st.goalsFor ?? 0,
          goalsAgainst: row.ga ?? 0,
          history: career.seasonHistory ?? [],
        },
      };
    },
  },
];

export async function handleApi(method, pathname, body, searchParams, headers) {
  for (const route of routes) {
    if (route.method !== method) continue;
    const m = pathname.match(route.pattern);
    if (!m) continue;
    const ctx = {
      id: m[1] ? decodeURIComponent(m[1]) : null,
      params: m.slice(1).map((g) => (g != null ? decodeURIComponent(g) : g)),
      body, searchParams, headers,
    };
    if (route.auth) ctx.user = requireUser(ctx);
    const t0 = Date.now();
    try {
      const res = await route.handler(ctx);
      trackEvent(makeEvent({
        type: 'api_request',
        userId: ctx.user ? ctx.user.id : null,
        careerId: ctx.id,
        data: { method, route: route.pattern.source, status: res.status || 200, ms: Date.now() - t0 },
      }));
      return res;
    } catch (e) {
      trackEvent(makeEvent({
        type: 'api_request',
        userId: ctx.user ? ctx.user.id : null,
        careerId: ctx.id,
        data: { method, route: route.pattern.source, status: e.status || 500, ms: Date.now() - t0 },
      }));
      throw e;
    }
  }
  httpError(404, `no route ${method} ${pathname}`);
}
