// Scouts: hireable staff who find players. Higher level => sharper reports.
import { newId } from '../core/ids.js';
import { assert, checkIntRange, checkName } from '../core/validate.js';
import { loadConfig } from '../core/config.js';

export function scoutingCfg() {
  return loadConfig('scouting');
}

export function hireScout({ name, level = 1, region = 'Domestic', wage = 1000 }) {
  checkName(name, 'scout name');
  checkIntRange(level, 1, 5, 'scout level');
  const cfg = scoutingCfg();
  assert(cfg.regions.includes(region), `unknown region: ${region}`);
  assert(Number.isFinite(wage) && wage > 0, 'wage must be positive');
  return { id: newId('scout'), name, level, region, wage: Math.round(wage) };
}

/** Upgrade a scout one level (returns cost charged). */
export function upgradeScout(scout, club) {
  assert(scout.level < 5, 'scout already at max level');
  const cfg = scoutingCfg();
  const next = scout.level + 1;
  const cost = cfg.levels[String(next)].costPerReport * 10;
  assert(club.cash >= cost, `insufficient funds for upgrade: need ${cost}`);
  club.cash -= cost;
  scout.level = next;
  return cost;
}
