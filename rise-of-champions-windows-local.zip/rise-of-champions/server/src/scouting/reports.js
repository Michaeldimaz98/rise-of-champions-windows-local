// Scouting reports: a scout finds players; the report's accuracy
// scales with scout level. The true player object stays server-side;
// the UI only ever sees `reported`.
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';
import { generatePlayer, playerValue } from '../players/player.js';
import { scoutingCfg } from './scout.js';

function gaussian(rng) {
  // Box-Muller
  const u = Math.max(rng.float(), 1e-9);
  const v = rng.float();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function potentialStars(potential, thresholds) {
  let stars = 1;
  for (const t of thresholds) if (potential >= t) stars++;
  return Math.min(5, stars);
}

/**
 * Send a scout to find players.
 *   criteria: { position?, ageRange?, overallRange?, count }
 * Returns { reports, cost }. Deducts cost from club.cash.
 */
export function scoutPlayers({ scout, club, criteria = {}, rng }) {
  if (!rng) throw new Error('scoutPlayers requires rng');
  const cfg = scoutingCfg();
  const levelCfg = cfg.levels[String(scout.level)];
  const count = Math.max(1, Math.min(5, criteria.count ?? 3));
  const cost = levelCfg.costPerReport * count;
  assert(club.cash >= cost, `insufficient funds for scouting: need ${cost}`);

  club.cash -= cost;
  const reports = [];
  for (let i = 0; i < count; i++) {
    const player = generatePlayer(rng, {
      position: criteria.position,
      ageRange: criteria.ageRange ?? [17, 30],
      overallRange: criteria.overallRange ?? [50, 85],
    });
    reports.push(makeReport(scout, player, rng, cfg));
  }
  return { reports, cost };
}

function makeReport(scout, player, rng, cfg) {
  const std = cfg.levels[String(scout.level)].noiseStd;
  const noisy = (v) => Math.round(v + gaussian(rng) * std);

  const overallEst = noisy(player.overall);
  const spread = Math.ceil(std * 1.5);
  const value = playerValue(player);
  const attrs = Object.entries(player.attributes);
  const sorted = [...attrs].sort((a, b) => b[1] - a[1]);

  return {
    id: newId('report'),
    scoutId: scout.id,
    scoutName: scout.name,
    playerId: player.id,
    player, // truth, server-side only
    reported: {
      overallLow: Math.max(30, overallEst - spread),
      overallHigh: Math.min(99, overallEst + spread),
      potentialStars: Math.max(1, Math.min(5, potentialStars(player.potential, cfg.starThresholds) + Math.round(gaussian(rng) * 0.5))),
      strengths: sorted.slice(0, 3).map(([name]) => name),
      weaknesses: sorted.slice(-2).map(([name]) => name),
      valueLow: Math.max(0, Math.round(value * (0.75 + rng.float() * 0.15))),
      valueHigh: Math.round(value * (1.1 + rng.float() * 0.25)),
    },
    accuracy: Math.max(0, Math.min(1, 1 - std / 10)),
    at: Date.now(),
  };
}

/** Shortlist a reported player for later transfer approach. */
export function shortlistReport(shortlist, report) {
  assert(!shortlist.includes(report.id), 'report already shortlisted');
  shortlist.push(report.id);
  return shortlist;
}
