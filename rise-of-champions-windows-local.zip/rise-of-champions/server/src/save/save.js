// Save system: persist careers as JSON on disk. The career object is
// plain data except for Maps (transfer market listings/offers), which
// are converted via a JSON replacer/reviver pair.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const SAVE_DIR = path.resolve(__dirname, '../../data/saves');

function replacer(_key, value) {
  if (value instanceof Map) return { __type: 'Map', entries: [...value] };
  return value;
}

function reviver(_key, value) {
  if (value && value.__type === 'Map' && Array.isArray(value.entries)) {
    return new Map(value.entries);
  }
  return value;
}

export function serializeCareer(career) {
  return JSON.stringify(career, replacer);
}

export function deserializeCareer(text) {
  const career = JSON.parse(text, reviver);
  if (!career || !career.id || !career.clubs || !career.players) {
    throw new Error('invalid save data');
  }
  return career;
}

function savePath(id) {
  if (!/^[a-z0-9_-]+$/i.test(id)) throw new Error('invalid career id');
  return path.join(SAVE_DIR, `${id}.json`);
}

export function saveCareer(career) {
  fs.mkdirSync(SAVE_DIR, { recursive: true });
  const payload = serializeCareer(career);
  const tmp = savePath(career.id) + '.tmp';
  fs.writeFileSync(tmp, payload);
  fs.renameSync(tmp, savePath(career.id)); // atomic
  return { id: career.id, bytes: payload.length };
}

/** Load one save; returns null if missing. */
export function loadCareer(id) {
  const file = savePath(id);
  if (!fs.existsSync(file)) return null;
  return deserializeCareer(fs.readFileSync(file, 'utf8'));
}

/** Load every save on disk. */
export function loadAllCareers() {
  if (!fs.existsSync(SAVE_DIR)) return [];
  return fs
    .readdirSync(SAVE_DIR)
    .filter((f) => f.endsWith('.json'))
    .map((f) => {
      try {
        return deserializeCareer(fs.readFileSync(path.join(SAVE_DIR, f), 'utf8'));
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

/** Lightweight listing for the Continue screen. */
export function listSaves() {
  return loadAllCareers().map((c) => {
    const entry = c.clubs[c.playerClubId];
    const stat = fs.statSync(savePath(c.id));
    return {
      id: c.id,
      clubName: entry?.club.name ?? '?',
      season: c.season,
      matchday: c.league.currentMatchday,
      cash: entry?.club.cash ?? 0,
      updatedAt: stat.mtimeMs,
    };
  }).sort((a, b) => b.updatedAt - a.updatedAt);
}

export function deleteSave(id) {
  const file = savePath(id);
  if (fs.existsSync(file)) fs.unlinkSync(file);
  return true;
}
