// Club finance: ledger, weekly tick (wages + sponsorship), matchday and
// prize income, financial health. All money movement goes through the
// ledger so the books always balance.
import { assert } from '../core/validate.js';
import { loadConfig } from '../core/config.js';
import { matchdayIncome } from '../facilities/effects.js';
import { staffWageBill } from '../staff/effects.js';

function financeCfg() {
  return loadConfig('finance');
}

export function ensureFinances(club) {
  if (!club.finances) club.finances = { ledger: [] };
  return club.finances;
}

/**
 * Record a transaction. Positive amount = income, negative = expense.
 * Mutates club.cash and appends to the ledger. Returns the entry.
 */
export function recordTransaction(club, { type, amount, description = '' }) {
  assert(Number.isFinite(amount), 'amount must be a number');
  assert(type, 'transaction type required');
  ensureFinances(club);
  club.cash = Math.round(club.cash + amount);
  const entry = { type, amount: Math.round(amount), description, balance: club.cash, at: Date.now() };
  club.finances.ledger.push(entry);
  return entry;
}

export function getLedger(club, { type = null, limit = 50 } = {}) {
  ensureFinances(club);
  const entries = type
    ? club.finances.ledger.filter((e) => e.type === type)
    : club.finances.ledger;
  return entries.slice(-limit).reverse();
}

/** Weekly player wage bill. player.wage is the weekly wage. */
export function playerWageBill(players) {
  return players.reduce((s, p) => s + (p.wage ?? 0), 0);
}

/**
 * Weekly tick: pay player + staff wages, collect sponsorship.
 * Returns { wages, staffWages, sponsorship, deficit }.
 */
export function processWeek(club, { players = [], staffRoster = null } = {}) {
  const cfg = financeCfg();
  const wages = playerWageBill(players);
  const staffWages = staffRoster ? staffWageBill(staffRoster) : 0;
  const sponsorship = cfg.sponsorBase + cfg.sponsorPerReputation * (club.reputation ?? 50);

  if (wages > 0) recordTransaction(club, { type: 'wages', amount: -wages, description: 'Player wages' });
  if (staffWages > 0) recordTransaction(club, { type: 'staff_wages', amount: -staffWages, description: 'Staff wages' });
  recordTransaction(club, { type: 'sponsorship', amount: sponsorship, description: 'Weekly sponsorship' });

  return { wages, staffWages, sponsorship, deficit: club.cash < 0 };
}

/** Home matchday: ticket income into the books. */
export function processMatchday(club, facilities, attendance) {
  const income = matchdayIncome(facilities, attendance);
  recordTransaction(club, { type: 'matchday', amount: income, description: `Matchday (${attendance} attendance)` });
  return income;
}

/** End-of-season prize money. competition: 'league' | 'cup'. */
export function awardPrizeMoney(club, competition, placement) {
  const table = financeCfg().prizeMoney[competition] ?? {};
  const amount = table[String(placement)] ?? 0;
  if (amount > 0) {
    recordTransaction(club, { type: 'prize', amount, description: `${competition} prize (${placement})` });
  }
  return amount;
}

/**
 * Financial health snapshot: weeks of runway at current burn rate.
 * status: healthy (>8 weeks), tight (3-8), critical (<3 or negative cash).
 */
export function financialHealth(club, { players = [], staffRoster = null } = {}) {
  const burn = playerWageBill(players) + (staffRoster ? staffWageBill(staffRoster) : 0);
  const income = financeCfg().sponsorBase + financeCfg().sponsorPerReputation * (club.reputation ?? 50);
  const netWeekly = income - burn;
  const weeks = netWeekly >= 0 ? Infinity : burn === 0 ? Infinity : club.cash / -netWeekly;
  const status = club.cash < 0 || weeks < 3 ? 'critical' : weeks <= 8 ? 'tight' : 'healthy';
  return { cash: club.cash, weeklyBurn: burn, weeklyIncome: income, runwayWeeks: weeks, status };
}
