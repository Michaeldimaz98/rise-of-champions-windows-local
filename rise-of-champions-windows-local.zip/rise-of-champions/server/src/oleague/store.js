// Online-league persistence: in-memory map + atomic JSON file.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.resolve(__dirname, '../../data/oleagues.json');

export const oleagues = new Map();

export function loadOleagues() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    for (const [id, lg] of Object.entries(raw)) oleagues.set(id, lg);
    return oleagues.size;
  } catch {
    return 0;
  }
}

export function persistOleagues() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(oleagues)));
  fs.renameSync(tmp, DATA_FILE);
}
