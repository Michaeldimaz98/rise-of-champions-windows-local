// Online League (Phase 21) — DOMAIN module. Pure game logic: no HTTP, no DOM,
// no database. Persistence and API live outside this file.
// A league gathers real managers (user accounts); each manager enters with
// one of their career clubs. Fixtures are deterministic (circle method).
// Matches are server-simulated via the single authoritative match engine.
// The manager who triggers a fixture plays with their LIVE career squad
// (mutated); the opponent is simulated from their season snapshot (untouched).
// Fixture results are idempotent: a fixture can only be played once.
import { createRng } from '../core/rng.js';
import { newId } from '../core/ids.js';
import { assert } from '../core/validate.js';
import { simulateMatch } from '../match/engine.js';
import { careerTeamBundle } from '../career/career.js';

const MIN_MANAGERS = 2;
const MAX_MANAGERS_DEFAULT = 8;

function deepCopy(o) {
  return JSON.parse(JSON.stringify(o));
}

export function createLeague({ name, userId, username, maxManagers = MAX_MANAGERS_DEFAULT }) {
  assert(typeof name === 'string' && name.trim().length >= 3, 'league name min 3 chars');
  const n = Number(maxManagers);
  assert(Number.isInteger(n) && n >= MIN_MANAGERS && n <= 16, 'maxManagers 2-16');
  return {
    id: newId('olg'),
    name: name.trim().slice(0, 40),
    season: 1,
    status: 'registration', // registration -> active -> complete
    commissionerId: userId,
    maxManagers: n,
    managers: [], // { userId, username, careerId, clubName, snapshot }
    fixtures: [], // { id, matchday, homeUserId, awayUserId, status, homeScore, awayScore, playedAt, playedBy }
    currentMatchday: 0,
    totalMatchdays: 0,
    champion: null,
    createdAt: Date.now(),
  };
}

export function joinLeague(league, { userId, username, careerId, clubName }) {
  assert(league.status === 'registration', 'registration is closed');
  assert(!league.managers.some((m) => m.userId === userId), 'already joined');
  assert(league.managers.length < league.maxManagers, 'league is full');
  league.managers.push({ userId, username, careerId, clubName, snapshot: null });
  return league;
}

export function leaveLeague(league, userId) {
  assert(league.status === 'registration', 'cannot leave after season start');
  const i = league.managers.findIndex((m) => m.userId === userId);
  assert(i >= 0, 'not a member');
  league.managers.splice(i, 1);
  if (league.managers.length === 0) return 'empty';
  if (league.commissionerId === userId) league.commissionerId = league.managers[0].userId;
  return 'left';
}

/** Deterministic double round-robin via circle method. Returns fixtures. */
export function generateFixtures(managerIds, season, leagueId) {
  const ids = [...managerIds];
  assert(ids.length >= MIN_MANAGERS && ids.length % 2 === 0, 'need an even number of managers (>= 2)');
  const rng = createRng(`oleague:${leagueId}:s${season}`);
  // deterministic shuffle of manager order
  for (let i = ids.length - 1; i > 0; i--) {
    const j = rng.int(0, i);
    [ids[i], ids[j]] = [ids[j], ids[i]];
  }
  const n = ids.length;
  const rounds = [];
  const arr = [...ids];
  for (let r = 0; r < n - 1; r++) {
    const pairs = [];
    for (let i = 0; i < n / 2; i++) pairs.push([arr[i], arr[n - 1 - i]]);
    rounds.push(pairs);
    arr.splice(1, 0, arr.pop());
  }
  const fixtures = [];
  rounds.forEach((pairs, r) => {
    for (const [home, away] of pairs) {
      fixtures.push({ matchday: r + 1, homeUserId: home, awayUserId: away });
    }
  });
  rounds.forEach((pairs, r) => {
    for (const [home, away] of pairs) {
      fixtures.push({ matchday: n + r, homeUserId: away, awayUserId: home });
    }
  });
  return fixtures.map((f) => ({
    id: newId('ofx'),
    status: 'pending',
    homeScore: null,
    awayScore: null,
    playedAt: null,
    playedBy: null,
    ...f,
  }));
}

/**
 * Start the season: snapshot every manager's team bundle from their live
 * career, generate fixtures. getCareer(userId) -> career (callback keeps
 * this module decoupled from persistence).
 */
export function startSeason(league, getCareer) {
  assert(league.status === 'registration', 'season already started');
  assert(league.managers.length % 2 === 0 && league.managers.length >= MIN_MANAGERS,
    `need an even number of managers (>= ${MIN_MANAGERS}) to start`);
  for (const m of league.managers) {
    const career = getCareer(m.userId);
    assert(career, `career missing for ${m.username}`);
    const bundle = careerTeamBundle(career, career.playerClubId);
    m.clubName = bundle.name;
    m.snapshot = deepCopy({ players: bundle.players, bench: bundle.bench, tactics: bundle.tactics });
  }
  league.fixtures = generateFixtures(league.managers.map((m) => m.userId), league.season, league.id);
  league.totalMatchdays = 2 * (league.managers.length - 1);
  league.currentMatchday = 1;
  league.status = 'active';
  league.champion = null;
  return league;
}

function managerOf(league, userId) {
  return league.managers.find((m) => m.userId === userId);
}

function snapshotBundle(league, userId) {
  const m = managerOf(league, userId);
  assert(m?.snapshot, 'no snapshot for manager');
  const s = deepCopy(m.snapshot);
  return { name: m.clubName, players: s.players, bench: s.bench, tactics: s.tactics };
}

function applyResult(league, fx, result, playedBy) {
  fx.status = 'played';
  fx.homeScore = result.score.home;
  fx.awayScore = result.score.away;
  fx.playedAt = Date.now();
  fx.playedBy = playedBy;
  return fx;
}

/**
 * Play the caller's pending fixture for the current matchday.
 * Idempotent: if already played (by either side), returns the recorded result.
 */
export function playFixture(league, userId, getCareer) {
  assert(league.status === 'active', 'league is not active');
  const mine = (f) => f.matchday === league.currentMatchday
    && (f.homeUserId === userId || f.awayUserId === userId);
  const pending = league.fixtures.find((f) => mine(f) && f.status === 'pending');
  const done = league.fixtures.find((f) => mine(f) && f.status === 'played');
  if (!pending) {
    if (done) return { fixture: done, alreadyPlayed: true };
    throw new Error('no fixture for you this matchday');
  }
  const career = getCareer(userId);
  assert(career, 'your career is missing');
  const live = careerTeamBundle(career, career.playerClubId);
  const oppId = pending.homeUserId === userId ? pending.awayUserId : pending.homeUserId;
  const oppBundle = snapshotBundle(league, oppId);
  const isHome = pending.homeUserId === userId;
  const result = simulateMatch({
    home: isHome ? live : oppBundle,
    away: isHome ? oppBundle : live,
    seed: `oleague:${league.id}:s${league.season}:md${league.currentMatchday}:${pending.id}:${Date.now()}`,
  });
  applyResult(league, pending, result, userId);
  return { fixture: pending, result, alreadyPlayed: false };
}

/** Auto-sim a fixture from both snapshots (used for unplayed fixtures). */
export function autoSimFixture(league, fx) {
  assert(fx.status === 'pending', 'fixture already played');
  const result = simulateMatch({
    home: snapshotBundle(league, fx.homeUserId),
    away: snapshotBundle(league, fx.awayUserId),
    seed: `oleague:${league.id}:s${league.season}:md${fx.matchday}:${fx.id}:auto`,
  });
  applyResult(league, fx, result, null);
  return fx;
}

/**
 * Advance to the next matchday. All current-matchday fixtures must be played,
 * unless force is set by the commissioner (unplayed are auto-simmed).
 */
export function advanceMatchday(league, userId, { force = false } = {}) {
  assert(league.status === 'active', 'league is not active');
  const pending = league.fixtures.filter(
    (f) => f.matchday === league.currentMatchday && f.status === 'pending');
  if (pending.length > 0) {
    assert(force && userId === league.commissionerId,
      `${pending.length} fixture(s) unplayed — commissioner can force advance`);
    for (const fx of pending) autoSimFixture(league, fx);
  }
  league.currentMatchday += 1;
  if (league.currentMatchday > league.totalMatchdays) {
    league.status = 'complete';
    const table = computeTable(league);
    league.champion = table.length ? table[0].userId : null;
  }
  return league;
}

/** Standings derived from fixtures — the single source of truth. */
export function computeTable(league) {
  const rows = new Map();
  for (const m of league.managers) {
    rows.set(m.userId, {
      userId: m.userId, username: m.username, clubName: m.clubName,
      p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0,
    });
  }
  for (const fx of league.fixtures) {
    if (fx.status !== 'played') continue;
    const h = rows.get(fx.homeUserId);
    const a = rows.get(fx.awayUserId);
    if (!h || !a) continue;
    h.p++; a.p++;
    h.gf += fx.homeScore; h.ga += fx.awayScore;
    a.gf += fx.awayScore; a.ga += fx.homeScore;
    if (fx.homeScore > fx.awayScore) { h.w++; a.l++; h.pts += 3; }
    else if (fx.homeScore < fx.awayScore) { a.w++; h.l++; a.pts += 3; }
    else { h.d++; a.d++; h.pts++; a.pts++; }
  }
  for (const r of rows.values()) r.gd = r.gf - r.ga;
  return [...rows.values()].sort((x, y) => y.pts - x.pts || y.gd - x.gd || y.gf - x.gf);
}

/** Start a fresh season with the current managers (commissioner only). */
export function newSeason(league, userId, getCareer) {
  assert(league.status === 'complete', 'season is not complete yet');
  assert(userId === league.commissionerId, 'only the commissioner can start a new season');
  league.season += 1;
  league.status = 'registration';
  league.fixtures = [];
  league.currentMatchday = 0;
  league.totalMatchdays = 0;
  league.champion = null;
  for (const m of league.managers) m.snapshot = null;
  return league;
}

export function publicLeague(league) {
  return {
    id: league.id, name: league.name, season: league.season, status: league.status,
    commissionerId: league.commissionerId, maxManagers: league.maxManagers,
    memberCount: league.managers.length,
    currentMatchday: league.currentMatchday, totalMatchdays: league.totalMatchdays,
    champion: league.champion, createdAt: league.createdAt,
  };
}
