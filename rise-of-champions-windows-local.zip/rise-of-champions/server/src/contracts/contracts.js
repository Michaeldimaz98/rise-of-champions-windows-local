// Contracts: offers, agent negotiation, renewals, expiry & Bosman,
// release-clause buyouts. Player.contract is the source of truth.
import { newId } from '../core/ids.js';
import { assert, checkIntRange } from '../core/validate.js';
import { loadConfig } from '../core/config.js';
import { removePlayer, registerPlayer } from '../squad/squad.js';

function contractsCfg() {
  return loadConfig('contracts');
}

/** What the player's agent demands: wage-based with an overall kicker. */
export function contractDemand(player) {
  const cfg = contractsCfg();
  return Math.round(player.wage * cfg.demandWageMult * (0.9 + player.overall / 500));
}

/**
 * Offer a new contract (renewal or new signing).
 * Returns { terms, evaluation: 'accepted' | 'counter' | 'rejected', counter? }.
 * The offer is NOT applied until signContract is called.
 */
export function offerContract(player, { years, salary, signingBonus = 0, releaseClause = null, role = 'Squad Player' }) {
  const cfg = contractsCfg();
  checkIntRange(years, cfg.minYears, cfg.maxYears, 'contract years');
  assert(Number.isFinite(salary) && salary > 0, 'salary must be positive');
  assert(Number.isFinite(signingBonus) && signingBonus >= 0, 'signingBonus must be non-negative');
  if (releaseClause !== null) assert(releaseClause > 0, 'releaseClause must be positive');

  const terms = {
    id: newId('contract'),
    playerId: player.id,
    years,
    salary: Math.round(salary),
    signingBonus: Math.round(signingBonus),
    releaseClause,
    role,
  };
  const demand = contractDemand(player);
  const ratio = terms.salary / demand;
  if (ratio >= cfg.acceptThreshold) {
    return { terms, evaluation: 'accepted' };
  }
  if (ratio >= cfg.counterThreshold) {
    return {
      terms,
      evaluation: 'counter',
      counter: { ...terms, id: newId('contract'), salary: demand },
    };
  }
  return { terms, evaluation: 'rejected' };
}

/** Apply agreed terms to the player. */
export function signContract(player, terms) {
  assert(terms.playerId === player.id, 'contract is for another player');
  player.wage = terms.salary;
  player.contract = {
    yearsLeft: terms.years,
    salary: terms.salary,
    signingBonus: terms.signingBonus,
    releaseClause: terms.releaseClause,
    role: terms.role,
  };
  player.morale = Math.min(100, (player.morale ?? 70) + 5);
  return player;
}

/** End-of-season tick: contracts run down. Returns expired player ids. */
export function tickContracts(players) {
  const expired = [];
  for (const p of players) {
    p.contract.yearsLeft = Math.max(0, p.contract.yearsLeft - 1);
    if (p.contract.yearsLeft === 0) expired.push(p.id);
  }
  return expired;
}

/** Players who can talk to other clubs (Bosman): yearsLeft <= threshold. */
export function getExpiring(players) {
  const cfg = contractsCfg();
  return players.filter((p) => p.contract.yearsLeft <= cfg.bosmanYearsLeft);
}

/**
 * Release-clause buyout: no negotiation, clause price paid in full.
 * Player must have a releaseClause set.
 */
export function executeReleaseClause({ player, buyerClubId, sellerClubId, playersById, squadsById, clubsById }) {
  const clause = player.contract.releaseClause;
  assert(clause && clause > 0, 'player has no release clause');
  assert(buyerClubId !== sellerClubId, 'cannot buy out your own player');
  const buyer = clubsById.get(buyerClubId);
  const seller = clubsById.get(sellerClubId);
  assert(buyer && seller, 'buyer or seller club not found');
  assert(buyer.cash >= clause, `insufficient funds: need ${clause}, have ${buyer.cash}`);

  buyer.cash -= clause;
  seller.cash += clause;
  const sellerSquad = squadsById.get(sellerClubId);
  const buyerSquad = squadsById.get(buyerClubId);
  if (sellerSquad) removePlayer(sellerSquad, player.id);
  if (buyerSquad) registerPlayer(buyerSquad, player.id);
  player.morale = Math.min(100, (player.morale ?? 70) + 10);

  return {
    playerId: player.id,
    playerName: player.name,
    fromClubId: sellerClubId,
    toClubId: buyerClubId,
    fee: clause,
    via: 'release-clause',
    at: Date.now(),
  };
}
