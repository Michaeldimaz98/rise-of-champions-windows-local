// League competition: round-robin fixtures, standings, promotion/relegation.
// Match results come from the match engine; this module owns the table.
import { loadConfig } from '../core/config.js';
import { simulateMatch } from '../match/engine.js';
import { promoteClub, relegateClub } from '../club/progression.js';

function getCfg() {
  return loadConfig('competition').league;
}

/**
 * Generate a double round-robin fixture list (circle method).
 * Returns [{ matchday, home, away }] with club ids.
 * Odd club count gets a bye each round (no fixture for one club).
 */
export function generateFixtures(clubIds) {
  const ids = [...clubIds];
  const hasBye = ids.length % 2 === 1;
  if (hasBye) ids.push(null); // bye
  const n = ids.length;
  const rounds = n - 1;
  const firstLeg = [];
  const arr = [...ids];
  for (let round = 0; round < rounds; round++) {
    for (let i = 0; i < n / 2; i++) {
      const home = arr[i];
      const away = arr[n - 1 - i];
      if (home && away) {
        // Alternate home/away for fairness across rounds.
        const flip = round % 2 === 1;
        firstLeg.push({
          matchday: round + 1,
          home: flip ? away : home,
          away: flip ? home : away,
        });
      }
    }
    // rotate (keep first fixed)
    arr.splice(1, 0, arr.pop());
  }
  if (!getCfg().homeAndAway) return firstLeg;
  const gamesPerRound = firstLeg.length / rounds;
  const secondLeg = firstLeg.map((f, i) => ({
    matchday: rounds + 1 + Math.floor(i / gamesPerRound),
    home: f.away,
    away: f.home,
  }));
  return [...firstLeg, ...secondLeg].sort((a, b) => a.matchday - b.matchday);
}

export function createLeague({ name, clubs, season = 1 }) {
  const ids = clubs.map((c) => c.id);
  return {
    id: `league_${name.toLowerCase().replace(/\s+/g, '_')}_${season}`,
    name,
    season,
    clubs: ids,
    fixtures: generateFixtures(ids),
    results: [], // { matchday, home, away, homeGoals, awayGoals, resultId }
    table: Object.fromEntries(ids.map((id) => [id, blankRow(id)])),
    scorers: {}, // playerId -> { playerId, name, clubId, goals, assists }
    currentMatchday: 0,
    complete: false,
  };
}

function blankRow(clubId) {
  return { clubId, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, gd: 0, points: 0 };
}

/** Clubs must be a Map id -> { id, name, players, bench, tactics }. */
export function playMatchday(league, clubsById, seedBase) {
  const cfg = getCfg();
  const md = league.currentMatchday + 1;
  const fixtures = league.fixtures.filter((f) => f.matchday === md);
  if (fixtures.length === 0) {
    league.complete = true;
    return [];
  }
  const played = [];
  fixtures.forEach((f, i) => {
    const home = clubsById.get(f.home);
    const away = clubsById.get(f.away);
    const result = simulateMatch({
      home: { name: home.name, players: home.players, bench: home.bench, tactics: home.tactics },
      away: { name: away.name, players: away.players, bench: away.bench, tactics: away.tactics },
      seed: `${seedBase}:m${md}:${f.home}-v-${f.away}`,
    });
    applyFixtureResult(league, f, result);
    played.push(result);
  });
  league.currentMatchday = md;
  const remaining = league.fixtures.some((f) => f.matchday > md);
  if (!remaining) league.complete = true;
  return played;
}

export function applyFixtureResult(league, fixture, result) {
  const cfg = getCfg();
  const { home, away } = fixture;
  const hg = result.score.home;
  const ag = result.score.away;
  league.results.push({ matchday: fixture.matchday, home, away, homeGoals: hg, awayGoals: ag });

  const H = league.table[home];
  const A = league.table[away];
  for (const row of [H, A]) row.played++;
  H.gf += hg; H.ga += ag;
  A.gf += ag; A.ga += hg;
  if (hg > ag) {
    H.won++; A.lost++;
    H.points += cfg.winPoints;
  } else if (hg < ag) {
    A.won++; H.lost++;
    A.points += cfg.winPoints;
  } else {
    H.drawn++; A.drawn++;
    H.points += cfg.drawPoints;
    A.points += cfg.drawPoints;
  }
  H.gd = H.gf - H.ga;
  A.gd = A.gf - A.ga;

  // scorers table from player ratings
  for (const [pid, pr] of Object.entries(result.playerRatings)) {
    if (pr.goals === 0 && pr.assists === 0) continue;
    const clubId = pr.team === 'home' ? home : away;
    const entry = league.scorers[pid] ?? { playerId: pid, name: pr.name, clubId, goals: 0, assists: 0 };
    entry.goals += pr.goals;
    entry.assists += pr.assists;
    league.scorers[pid] = entry;
  }
}

/** Sorted standings: points, goal difference, goals for, club id. */
export function getStandings(league) {
  return Object.values(league.table).sort(
    (a, b) => b.points - a.points || b.gd - a.gd || b.gf - a.gf || String(a.clubId).localeCompare(String(b.clubId))
  );
}

export function getTopScorers(league, limit = 10) {
  return Object.values(league.scorers)
    .sort((a, b) => b.goals - a.goals || b.assists - a.assists)
    .slice(0, limit);
}

/**
 * Season rollover: promote top N, relegate bottom N (mutates club objects).
 * Returns { promoted: [ids], relegated: [ids], champions: id }.
 */
export function applySeasonEnd(league, clubsById, { promote = 0, relegate = 0 } = {}) {
  const standings = getStandings(league);
  const promoted = standings.slice(0, promote).map((r) => r.clubId);
  const relegated = standings.slice(-relegate).map((r) => r.clubId);
  for (const id of promoted) {
    const club = clubsById.get(id);
    if (club?.club) promoteClub(club.club);
  }
  for (const id of relegated) {
    const club = clubsById.get(id);
    if (club?.club) relegateClub(club.club);
  }
  return { promoted, relegated, champions: standings[0]?.clubId ?? null };
}
