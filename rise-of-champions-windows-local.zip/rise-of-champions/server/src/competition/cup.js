// Knockout cup: seeded single-elimination bracket.
// Ties use the match engine in knockout mode (ET + penalties if drawn).
import { loadConfig } from '../core/config.js';
import { createRng } from '../core/rng.js';
import { simulateMatch } from '../match/engine.js';

function roundName(size) {
  const names = loadConfig('competition').cup.rounds;
  return names[String(size)] ?? `Round of ${size}`;
}

/**
 * Create a cup. clubs: [{ id, ... }]. Draw is seeded by `seed`.
 * Non-power-of-2 fields: top seeds get byes into the next round.
 */
export function createCup({ name, clubs, season = 1, seed = 'cup-draw' }) {
  const rng = createRng(seed);
  const ids = clubs.map((c) => c.id);
  // Shuffle, then byes go to the teams drawn first (top seeds).
  const shuffled = [...ids].sort(() => rng.float() - 0.5);
  return {
    id: `cup_${name.toLowerCase().replace(/\s+/g, '_')}_${season}`,
    name,
    season,
    rounds: [],
    currentRound: 0,
    pending: shuffled, // teams waiting for their first tie
    champions: null,
    complete: false,
  };
}

/** Play the next round. clubsById: Map id -> { id, name, players, bench, tactics }. */
export function playCupRound(cup, clubsById, seedBase) {
  if (cup.complete) return [];
  let entrants = [...cup.pending];
  cup.pending = [];

  // Byes: next power of 2.
  let size = 1;
  while (size < entrants.length) size *= 2;
  const byes = size - entrants.length;
  const byeTeams = entrants.splice(0, byes);

  const roundLabel = roundName(size);
  const ties = [];
  for (let i = 0; i < entrants.length; i += 2) {
    ties.push({ home: entrants[i], away: entrants[i + 1] });
  }

  const winners = [...byeTeams];
  const results = [];
  ties.forEach((tie, i) => {
    const home = clubsById.get(tie.home);
    const away = clubsById.get(tie.away);
    const result = simulateMatch({
      home: { name: home.name, players: home.players, bench: home.bench, tactics: home.tactics },
      away: { name: away.name, players: away.players, bench: away.bench, tactics: away.tactics },
      seed: `${seedBase}:cup-r${cup.currentRound + 1}:${tie.home}-v-${tie.away}`,
      knockout: true,
    });
    const winnerId = result.winner === 'home' ? tie.home : tie.away;
    winners.push(winnerId);
    results.push({ ...result, round: roundLabel, homeId: tie.home, awayId: tie.away, winnerId });
  });

  cup.rounds.push({ round: roundLabel, results });
  cup.currentRound++;
  if (winners.length === 1) {
    cup.champions = winners[0];
    cup.complete = true;
  } else {
    cup.pending = winners;
  }
  return results;
}
