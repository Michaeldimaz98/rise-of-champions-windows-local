// Analytics (Phase 26) — DOMAIN module. Pure: event recording shapes and
// summary aggregation. Storage (JSONL) lives in store.js. No HTTP, no DOM.
// Analytics is server-local only; nothing leaves the machine.
export function makeEvent({ type, userId = null, careerId = null, data = null, ts = Date.now() }) {
  return { ts, type, userId, careerId, data };
}

/**
 * Summarize events. Returns:
 *  - totals: { [type]: count }
 *  - byDay: { 'YYYY-MM-DD': { dau: Set->count, matches, purchases, revenueIdr } }
 *  - topRoutes: slowest routes by avg ms (from request events)
 */
export function summarize(events, { since = 0 } = {}) {
  const totals = {};
  const byDay = {};
  const routes = {};
  for (const e of events) {
    if (e.ts < since) continue;
    totals[e.type] = (totals[e.type] || 0) + 1;
    const day = new Date(e.ts).toISOString().slice(0, 10);
    const d = (byDay[day] = byDay[day] || { users: new Set(), matches: 0, purchases: 0, revenueIdr: 0 });
    if (e.userId) d.users.add(e.userId);
    if (e.type === 'match_played') d.matches++;
    if (e.type === 'shop_purchase') {
      d.purchases++;
      d.revenueIdr += (e.data && e.data.amountIdr) || 0;
    }
    if (e.type === 'api_request' && e.data) {
      const key = `${e.data.method} ${e.data.route}`;
      const r = (routes[key] = routes[key] || { count: 0, totalMs: 0, errors: 0 });
      r.count++;
      r.totalMs += e.data.ms || 0;
      if (e.data.status >= 400) r.errors++;
    }
  }
  const days = Object.fromEntries(
    Object.entries(byDay)
      .sort(([a], [b]) => (a < b ? -1 : 1))
      .map(([day, d]) => [day, { dau: d.users.size, matches: d.matches, purchases: d.purchases, revenueIdr: d.revenueIdr }])
  );
  const topRoutes = Object.entries(routes)
    .map(([route, r]) => ({ route, count: r.count, avgMs: Math.round(r.totalMs / r.count), errors: r.errors }))
    .sort((a, b) => b.avgMs - a.avgMs)
    .slice(0, 10);
  return { totals, days, topRoutes, eventCount: events.length };
}
