// Analytics storage: append-only JSONL. In-memory ring of recent events.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FILE = path.resolve(__dirname, '../../data/analytics.jsonl');
const MAX_KEEP = 50000;

export const analyticsEvents = [];

export function loadAnalytics() {
  try {
    // Phase 28: rotate — never let the log grow unbounded.
    const stat = fs.statSync(FILE);
    if (stat.size > 10 * 1024 * 1024) {
      const lines = fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean);
      fs.writeFileSync(FILE, lines.slice(-MAX_KEEP).join('\n') + '\n');
    }
    const lines = fs.readFileSync(FILE, 'utf8').split('\n').filter(Boolean);
    const keep = lines.slice(-MAX_KEEP);
    for (const line of keep) {
      try { analyticsEvents.push(JSON.parse(line)); } catch { /* skip corrupt line */ }
    }
    return analyticsEvents.length;
  } catch {
    return 0;
  }
}

let stream = null;
function getStream() {
  if (!stream) {
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    stream = fs.createWriteStream(FILE, { flags: 'a' });
  }
  return stream;
}

/** Append one event (fire-and-forget; never throws). */
export function trackEvent(evt) {
  try {
    analyticsEvents.push(evt);
    if (analyticsEvents.length > MAX_KEEP) analyticsEvents.splice(0, analyticsEvents.length - MAX_KEEP);
    getStream().write(JSON.stringify(evt) + '\n');
  } catch { /* analytics must never break the game */ }
}
