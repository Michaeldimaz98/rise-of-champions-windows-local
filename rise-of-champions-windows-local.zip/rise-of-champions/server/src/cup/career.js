// Career Cup: seasonal single-elimination knockout competition.
// Competition layer only: draw, bracket, fixtures, progression, finalization.
// Match simulation reuses the existing match engine (knockout mode).
// Rewards/trophies/milestones/records reuse Phase 32-35 infrastructure.
// Phase 36.
import { createRng } from '../core/rng.js';
import { simulateMatch } from '../match/engine.js';
import { buildMatchReport } from '../match/report.js';
import { loadConfig } from '../core/config.js';
import { assert } from '../core/validate.js';
import { careerTeamBundle, notify } from '../career/career.js';

function roundName(size) {
  const names = loadConfig('competition').cup.rounds;
  return names[String(size)] ?? `Round of ${size}`;
}

function blankCupHistory() {
  return [];
}

/**
 * Field-by-field backfill for old saves (never clobbers existing data).
 * Creates a fresh cup when missing or when the season has rolled over
 * (archiving the old one into cupHistory first).
 */
export function ensureCup(career) {
  assert(career && typeof career === 'object', 'career required');
  if (!Array.isArray(career.cupHistory)) career.cupHistory = blankCupHistory();
  const cup = career.cup;
  if (!cup || typeof cup !== 'object' || cup.season !== career.season) {
    if (cup && typeof cup === 'object') archiveCup(career);
    career.cup = createCareerCup(career);
  }
  return career.cup;
}

function createCareerCup(career) {
  const rng = createRng(`${career.seed}:cup:s${career.season}:draw`);
  const ids = Object.keys(career.clubs);
  assert(ids.length >= 2, 'cup needs at least 2 clubs');
  // Stable input order (club ids are random per career), then seeded Fisher-Yates.
  const ordered = [...ids].sort((a, b) =>
    career.clubs[a].club.name.localeCompare(career.clubs[b].club.name));
  for (let i = ordered.length - 1; i > 0; i--) {
    const j = Math.floor(rng.float() * (i + 1));
    [ordered[i], ordered[j]] = [ordered[j], ordered[i]];
  }
  const name = roundName(ordered.length);
  const fixtures = [];
  for (let i = 0; i < ordered.length; i += 2) {
    fixtures.push(newFixture(career.season, 0, i / 2, name, ordered[i], ordered[i + 1]));
  }
  return {
    season: career.season,
    status: 'active',
    champion: null,
    runnerUp: null,
    finalized: false,
    rounds: [{ name, fixtures }],
  };
}

function newFixture(season, roundIdx, fixIdx, roundName_, home, away) {
  return {
    id: `cup-s${season}-r${roundIdx}-f${fixIdx}`,
    round: roundName_,
    home,
    away,
    status: 'pending',
    homeScore: null,
    awayScore: null,
    winner: null,
  };
}

function archiveCup(career) {
  const cup = career.cup;
  career.cupHistory.push({
    season: cup.season,
    status: cup.status,
    champion: cup.champion,
    championName: cup.champion ? career.clubs[cup.champion]?.club.name ?? null : null,
    runnerUp: cup.runnerUp,
    playerRun: playerCupRun(career, cup),
  });
  const max = 12;
  if (career.cupHistory.length > max) {
    career.cupHistory.splice(0, career.cupHistory.length - max);
  }
}

/** How far the player's club got: Champions / Final / Semi-final / Quarter-final / null. */
export function playerCupRun(career, cup = career.cup) {
  if (!cup) return null;
  if (cup.champion === career.playerClubId) return 'Champions';
  for (let i = cup.rounds.length - 1; i >= 0; i--) {
    const round = cup.rounds[i];
    const involved = round.fixtures.some(
      (f) => f.home === career.playerClubId || f.away === career.playerClubId,
    );
    if (involved) return round.name;
  }
  return null;
}

/** The player's pending fixture in the current round, or null. */
export function playerCupFixture(career) {
  const cup = ensureCup(career);
  if (cup.status !== 'active') return null;
  const round = cup.rounds[cup.rounds.length - 1];
  return round.fixtures.find(
    (f) => f.status === 'pending'
      && (f.home === career.playerClubId || f.away === career.playerClubId),
  ) ?? null;
}

/**
 * Play the current round: simulates every pending fixture with the existing
 * match engine (knockout mode), advances winners, generates the next round.
 * Idempotent: already-played fixtures are skipped.
 * Returns { results, playerResult, champion }.
 */
export function playCupRound(career, opts = {}) {
  const deferPlayer = !!opts.deferPlayer;
  const cup = ensureCup(career);
  assert(cup.status === 'active', 'cup is already complete');
  const roundIdx = cup.rounds.length - 1;
  const round = cup.rounds[roundIdx];
  const results = [];
  let playerResult = null;
  let deferredFixture = null;

  for (const fx of round.fixtures) {
    if (fx.status === 'played') continue;
    const isPlayer = fx.home === career.playerClubId || fx.away === career.playerClubId;
    if (isPlayer && deferPlayer) {
      deferredFixture = fx;
      continue;
    }
    const home = careerTeamBundle(career, fx.home);
    const away = careerTeamBundle(career, fx.away);
    const result = simulateMatch({
      home,
      away,
      seed: `${career.seed}:cup:s${cup.season}:${fx.id}`,
      knockout: true,
    });
    applyCupTieResult(career, fx, result);
    results.push({ fixtureId: fx.id, home: fx.home, away: fx.away, score: result.score, winner: fx.winner });
    if (isPlayer) {
      // Phase 51: same shared report projection as every other flow.
      playerResult = {
        fixture: { ...fx },
        result,
        report: buildMatchReport(result, { tactics: { home: home.tactics, away: away.tactics } }),
      };
    }
  }

  if (deferPlayer) {
    // Progression waits for the live tie; run via completeCupTie().
    return { results, playerResult: null, deferredFixture, champion: null, deferred: true };
  }

  const champion = progressCup(cup, round, roundIdx);
  return { results, playerResult, champion };
}

/** Apply a knockout result to a cup fixture (shared by instant + live). */
export function applyCupTieResult(career, fx, result) {
  assert(result.winner === 'home' || result.winner === 'away',
    `knockout fixture ${fx.id} must produce a winner`);
  fx.homeScore = result.score.home;
  fx.awayScore = result.score.away;
  fx.winner = result.winner === 'home' ? fx.home : fx.away;
  fx.status = 'played';
  return fx;
}

/** Advance the cup: next round or champion. Returns champion club id or null. */
export function progressCup(cup, round, roundIdx) {
  const winners = round.fixtures.map((f) => f.winner);
  assert(winners.every(Boolean) && winners.length > 0, 'round must produce winners');

  if (winners.length === 1) {
    cup.champion = winners[0];
    const final = round.fixtures[0];
    cup.runnerUp = final.winner === final.home ? final.away : final.home;
    cup.status = 'complete';
  } else {
    const name = roundName(winners.length);
    const fixtures = [];
    for (let i = 0; i < winners.length; i += 2) {
      fixtures.push(newFixture(cup.season, roundIdx + 1, i / 2, name, winners[i], winners[i + 1]));
    }
    cup.rounds.push({ name, fixtures });
  }
  return cup.champion ?? null;
}

/**
 * Complete a deferred (live) cup tie. Applies the live result, then runs
 * progression. Idempotent per fixture: re-completing returns the recorded
 * outcome without re-applying. Phase 38.
 */
export function completeCupTie(career, fixtureId, result) {
  const cup = ensureCup(career);
  const roundIdx = cup.rounds.length - 1;
  const round = cup.rounds[roundIdx];
  const fx = round.fixtures.find((f) => f.id === fixtureId);
  if (!fx) throw new Error('cup fixture not found');
  // Phase 51: report from the authoritative live result. Player's own
  // configured tactics (synced from the live match) for their side only;
  // opponent behavior stays observed-only.
  const playerSide = fx.home === career.playerClubId ? 'home' : 'away';
  const report = buildMatchReport(result, {
    tactics: { [playerSide]: career.clubs[career.playerClubId].tactics },
  });
  if (fx.status === 'played') {
    return {
      playerResult: { fixture: { ...fx }, result, report },
      champion: cup.champion ?? null,
      alreadyCompleted: true,
    };
  }
  applyCupTieResult(career, fx, result);
  const champion = progressCup(cup, round, roundIdx);
  return {
    playerResult: { fixture: { ...fx }, result, report },
    champion,
    alreadyCompleted: false,
  };
}

/**
 * Public-safe cup view for the client. No internal ids beyond fixture ids.
 */
export function cupView(career) {
  const cup = ensureCup(career);
  const nameOf = (id) => career.clubs[id]?.club.name ?? '?';
  return {
    season: cup.season,
    status: cup.status,
    champion: cup.champion ? nameOf(cup.champion) : null,
    playerRun: playerCupRun(career, cup),
    playerFixture: (() => {
      const fx = playerCupFixture(career);
      return fx ? { id: fx.id, round: fx.round, home: nameOf(fx.home), away: nameOf(fx.away) } : null;
    })(),
    rounds: cup.rounds.map((r) => ({
      name: r.name,
      fixtures: r.fixtures.map((f) => ({
        id: f.id,
        home: nameOf(f.home),
        away: nameOf(f.away),
        homeScore: f.homeScore,
        awayScore: f.awayScore,
        winner: f.winner ? nameOf(f.winner) : null,
        status: f.status,
        involvesPlayer: f.home === career.playerClubId || f.away === career.playerClubId,
      })),
    })),
    history: career.cupHistory.slice().reverse(),
  };
}
