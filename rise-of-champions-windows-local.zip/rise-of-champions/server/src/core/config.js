// Config loader. All balancing/tuning lives in JSON files under /config.
// Loaded configs are deep-frozen so game code cannot mutate tuning at
// runtime; cached per process.
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
// server/src/core -> project root /config
const CONFIG_DIR = join(here, '..', '..', '..', 'config');

const cache = new Map();

function deepFreeze(obj) {
  if (obj && typeof obj === 'object' && !Object.isFrozen(obj)) {
    for (const v of Object.values(obj)) deepFreeze(v);
    Object.freeze(obj);
  }
  return obj;
}

export function loadConfig(name) {
  if (cache.has(name)) return cache.get(name);
  let raw;
  try {
    raw = readFileSync(join(CONFIG_DIR, `${name}.json`), 'utf8');
  } catch (err) {
    throw new Error(`config "${name}" not found in ${CONFIG_DIR}: ${err.message}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new Error(`config "${name}" is not valid JSON: ${err.message}`);
  }
  const frozen = deepFreeze(parsed);
  cache.set(name, frozen);
  return frozen;
}

/** Clear the cache (tests only). */
export function _clearConfigCache() {
  cache.clear();
}
