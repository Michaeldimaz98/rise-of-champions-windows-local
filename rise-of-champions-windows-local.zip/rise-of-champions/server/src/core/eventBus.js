// Minimal synchronous event bus for decoupled module communication.
// Modules emit domain events (e.g. "match:finished") instead of importing
// each other directly.

export function createEventBus() {
  const handlers = new Map(); // event -> Set<fn>

  function on(event, fn) {
    if (typeof fn !== 'function') throw new TypeError('handler must be a function');
    if (!handlers.has(event)) handlers.set(event, new Set());
    handlers.get(event).add(fn);
    return () => off(event, fn);
  }

  function once(event, fn) {
    const wrapper = (payload) => {
      off(event, wrapper);
      fn(payload);
    };
    return on(event, wrapper);
  }

  function off(event, fn) {
    const set = handlers.get(event);
    if (set) {
      set.delete(fn);
      if (set.size === 0) handlers.delete(event);
    }
  }

  function emit(event, payload) {
    const set = handlers.get(event);
    if (!set) return 0;
    // Copy: a handler may unsubscribe itself during emit.
    for (const fn of [...set]) fn(payload);
    return set.size;
  }

  function listenerCount(event) {
    return handlers.get(event)?.size ?? 0;
  }

  return { on, once, off, emit, listenerCount };
}
