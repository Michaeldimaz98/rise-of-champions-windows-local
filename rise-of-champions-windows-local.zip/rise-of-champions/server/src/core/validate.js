// Validation helpers. Game logic throws ValidationError (not generic
// Error) on bad input so callers and tests can distinguish programmer
// errors from domain failures.

export class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
  }
}

export function assert(condition, message = 'validation failed') {
  if (!condition) throw new ValidationError(message);
}

export function isInt(v) {
  return Number.isInteger(v);
}

export function isNumber(v) {
  return typeof v === 'number' && Number.isFinite(v);
}

export function inRange(v, min, max) {
  return isNumber(v) && v >= min && v <= max;
}

export function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}

export function isOneOf(v, list) {
  return list.includes(v);
}

/** Assert a value is an int in [min, max]; returns the value for chaining. */
export function checkIntRange(v, min, max, name = 'value') {
  assert(isInt(v) && v >= min && v <= max,
    `${name} must be an integer in [${min}, ${max}], got ${v}`);
  return v;
}

/** Assert a non-empty string; returns the trimmed value. */
export function checkName(v, name = 'name') {
  assert(isNonEmptyString(v), `${name} must be a non-empty string`);
  return v.trim();
}
