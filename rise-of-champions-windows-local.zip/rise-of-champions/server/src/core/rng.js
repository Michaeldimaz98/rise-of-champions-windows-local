// Deterministic seeded PRNG (mulberry32) with string-seed hashing (xfnv1a).
// Same seed + same call order => identical sequence. Used by the match
// engine so results are replayable and verifiable.

export function hashSeed(str) {
  // xfnv1a 32-bit
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed) {
  // State is kept in an object so it can be snapshotted/restored
  // (live matches persist the RNG position across segments/restarts).
  const st = { a: seed >>> 0 };
  const next = function () {
    st.a |= 0;
    st.a = (st.a + 0x6d2b79f5) | 0;
    let t = Math.imul(st.a ^ (st.a >>> 15), 1 | st.a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  next.getState = () => st.a >>> 0;
  next.setState = (s) => { st.a = s >>> 0; };
  return next;
}

export function createRng(seedInput) {
  const seed =
    typeof seedInput === 'number'
      ? seedInput >>> 0
      : hashSeed(String(seedInput));
  const next = mulberry32(seed);

  return {
    seed,
    /** Float in [0, 1). */
    float() {
      return next();
    },
    /** Integer in [min, max] inclusive. */
    int(min, max) {
      if (!Number.isInteger(min) || !Number.isInteger(max) || max < min) {
        throw new RangeError(`rng.int: invalid range [${min}, ${max}]`);
      }
      return min + Math.floor(next() * (max - min + 1));
    },
    /** True with probability p (0..1). */
    chance(p) {
      if (p <= 0) return false;
      if (p >= 1) return true;
      return next() < p;
    },
    /** Random element of a non-empty array. */
    pick(arr) {
      if (!Array.isArray(arr) || arr.length === 0) {
        throw new RangeError('rng.pick: empty array');
      }
      return arr[Math.floor(next() * arr.length)];
    },
    /** New array with elements shuffled (Fisher-Yates). */
    shuffle(arr) {
      const out = arr.slice();
      for (let i = out.length - 1; i > 0; i--) {
        const j = Math.floor(next() * (i + 1));
        [out[i], out[j]] = [out[j], out[i]];
      }
      return out;
    },
    /** Serializable RNG position (for live-match persistence). */
    getState() {
      return next.getState();
    },
    /** Restore a position from getState(). */
    setState(s) {
      next.setState(s);
    },
  };
}
