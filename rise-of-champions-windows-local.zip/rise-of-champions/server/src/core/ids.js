// Unique id generation for entities. Ids are opaque strings; the counter
// guarantees uniqueness within a process, the random suffix across restarts.
import { randomUUID } from 'node:crypto';

let counter = 0;

export function newId(prefix = 'id') {
  counter += 1;
  return `${prefix}_${counter.toString(36)}_${randomUUID().slice(0, 8)}`;
}

/** Reset the process counter (tests only). */
export function _resetIdCounter() {
  counter = 0;
}
