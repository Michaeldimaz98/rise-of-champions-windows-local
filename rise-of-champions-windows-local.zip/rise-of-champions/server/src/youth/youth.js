// Youth academy: seasonal intake of young prospects and promotion
// to the senior squad. Intake quality scales with the YouthAcademy
// facility level and club reputation.
import { assert } from '../core/validate.js';
import { loadConfig } from '../core/config.js';
import { generatePlayer } from '../players/player.js';
import { registerPlayer } from '../squad/squad.js';
import { youthQualityBonus } from '../facilities/effects.js';

function youthCfg() {
  return loadConfig('youth');
}

export function createYouthAcademy() {
  return { players: [] }; // player objects not yet in the senior squad
}

/**
 * Seasonal youth intake.
 *   academy, club { reputation }, facilities, rng, playersById (mutated)
 * Returns the new youth players.
 */
export function youthIntake({ academy, club, facilities, rng, playersById, count = null }) {
  if (!rng) throw new Error('youthIntake requires rng');
  const cfg = youthCfg();
  const n = count ?? rng.int(...cfg.intakePerSeason);
  const quality = youthQualityBonus(facilities) + ((club.reputation ?? 50) - 50) * cfg.reputationFactor;
  const shift = Math.round(quality * cfg.qualityPerBonusPoint);
  const [baseLo, baseHi] = cfg.baseOverallRange;
  const lo = Math.max(30, Math.min(80, baseLo + shift));
  const hi = Math.max(lo + 5, Math.min(85, baseHi + shift));

  const intake = [];
  for (let i = 0; i < n; i++) {
    const player = generatePlayer(rng, {
      ageRange: cfg.ageRange,
      overallRange: [lo, hi],
    });
    player.wage = 500; // youth stipend
    player.contract = { ...player.contract, yearsLeft: 3, salary: 500, role: 'Youth Prospect' };
    academy.players.push(player);
    playersById.set(player.id, player);
    intake.push(player);
  }
  return intake;
}

/** Promote a youth player to the senior squad. */
export function promoteToSenior({ academy, playerId, squad, wage = null }) {
  const i = academy.players.findIndex((p) => p.id === playerId);
  assert(i >= 0, `youth player not found: ${playerId}`);
  const [player] = academy.players.splice(i, 1);
  registerPlayer(squad, player.id);
  const seniorWage = wage ?? Math.max(player.wage, 2000);
  player.wage = seniorWage;
  player.contract = { ...player.contract, salary: seniorWage, role: 'Squad Player' };
  player.morale = Math.min(100, (player.morale ?? 70) + 5);
  return player;
}

/** Release a youth player who will not make it. */
export function releaseYouth({ academy, playerId, playersById }) {
  const i = academy.players.findIndex((p) => p.id === playerId);
  assert(i >= 0, `youth player not found: ${playerId}`);
  const [player] = academy.players.splice(i, 1);
  playersById.delete(player.id);
  return player;
}
