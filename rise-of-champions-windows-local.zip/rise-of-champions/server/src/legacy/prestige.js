// Club prestige — a derived, server-computed status score.
// Pure function of validated records: trophies, milestones, club reputation.
// Not stored, not submitted by clients, cannot be farmed by replaying matches.
// Phase 34.
import { ensureLegacy } from './records.js';

export const PRESTIGE_WEIGHTS = {
  leagueTitle: 100,
  cupTitle: 100,
  continentalTitle: 150,
  rankedTop3: 50,
  milestone: 25,
};

/** ctx.rankedTop3 = number of ranked seasons finished in the top 3 (account-level). */
export function computePrestige(career, ctx = {}) {
  ensureLegacy(career);
  const trophies = career.legacy.trophies;
  const leagueTitles = trophies.filter((t) => t.type === 'league').length;
  const cupTitles = trophies.filter((t) => t.type === 'cup').length;
  const continentalTitles = trophies.filter((t) => t.type === 'continental').length;
  const milestones = Object.keys(career.legacy.milestones).length;
  const score =
    leagueTitles * PRESTIGE_WEIGHTS.leagueTitle +
    cupTitles * PRESTIGE_WEIGHTS.cupTitle +
    continentalTitles * PRESTIGE_WEIGHTS.continentalTitle +
    (ctx.rankedTop3 || 0) * PRESTIGE_WEIGHTS.rankedTop3 +
    milestones * PRESTIGE_WEIGHTS.milestone +
    (career.clubs?.[career.playerClubId]?.club?.reputation ?? 0);
  return { score, tier: tierFor(score, ctx.tiers) };
}

export function tierFor(score, tiers) {
  const list = Array.isArray(tiers) && tiers.length
    ? tiers
    : [{ min: 1000, label: 'Legendary' }, { min: 500, label: 'Elite' }, { min: 250, label: 'Established' }, { min: 100, label: 'Regional' }, { min: 0, label: 'Local' }];
  for (const t of list) if (score >= t.min) return t.label;
  return list[list.length - 1].label;
}
