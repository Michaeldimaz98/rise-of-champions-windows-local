// Club legacy: persistent records, trophies, milestones, prestige, identity.
// Phase 34. All values are derived server-side from validated events only;
// the client can never submit records, trophies, milestones, or prestige.
export * from './records.js';
export * from './trophies.js';
export * from './milestones.js';
export * from './prestige.js';
export * from './identity.js';
export * from './profile.js';
