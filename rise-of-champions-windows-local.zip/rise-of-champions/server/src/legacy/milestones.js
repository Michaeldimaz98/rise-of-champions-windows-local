// Club milestones — long-term goals, data-driven via config.
// One-time, idempotent rewards paid through the ledger by the caller.
// Phase 34.
import { ensureLegacy } from './records.js';
import { computePrestige } from './prestige.js';
import { recordTransaction } from '../finance/finance.js';
import { notify } from '../career/career.js';

/** Evaluate milestone conditions against validated career state. */
export function milestoneMet(id, career, ctx = {}) {
  const trophies = career.legacy?.trophies || [];
  const s = career.stats || {};
  switch (id) {
    case 'first_league_title':
      return trophies.some((t) => t.type === 'league');
    case 'first_cup_title':
      return trophies.some((t) => t.type === 'cup');
    case 'first_continental_title':
      return trophies.some((t) => t.type === 'continental');
    case 'qualify_continental': {
      const cont = career.continental;
      return !!cont && cont.season === career.season
        && cont.qualifiers.includes(career.playerClubId);
    }
    case 'continental_final': {
      const cont = career.continental;
      if (!cont || cont.season !== career.season) return false;
      const kf = cont.knockout.fixtures[0];
      return !!kf && (kf.home === career.playerClubId || kf.away === career.playerClubId);
    }
    case 'ranked_top3':
      return Number.isInteger(ctx.rankedBest) && ctx.rankedBest <= 3 && ctx.rankedBest >= 1;
    case 'wins50':
      return (s.wins || 0) >= 50;
    case 'wins100':
      return (s.wins || 0) >= 100;
    case 'facility5': {
      const facs = career.clubs?.[career.playerClubId]?.facilities || {};
      return Object.values(facs).some((f) => (f.level || 0) >= 5);
    }
    case 'prestige500':
      return computePrestige(career, ctx).score >= 500;
    default:
      return false;
  }
}

/**
 * Unlock newly-met milestones. Returns the unlocked milestone defs (with cash).
 * Restart-safe: unlocked map persists on the career save. Concurrent-safe:
 * Node single-threaded; the map check+set is atomic per call.
 */
export function checkMilestones(career, cfg, ctx = {}) {
  ensureLegacy(career);
  const unlocked = [];
  for (const m of cfg.clubMilestones || []) {
    if (career.legacy.milestones[m.id]) continue;
    if (milestoneMet(m.id, career, ctx)) {
      career.legacy.milestones[m.id] = Date.now();
      unlocked.push(m);
    }
  }
  return unlocked;
}

/** Pay milestone rewards through the ledger + notify. One-time by construction. */
export function applyMilestoneRewards(career, list) {
  if (!list.length) return [];
  const club = career.clubs[career.playerClubId].club;
  return list.map((m) => {
    recordTransaction(club, {
      type: 'milestone_reward',
      amount: m.cash,
      description: `Milestone: ${m.title}`,
    });
    notify(career, `🎖️ Milestone unlocked: ${m.title} (+${m.cash.toLocaleString()}).`);
    return m.id;
  });
}

/** Milestone list with unlock state for the client. */
export function milestoneProgress(career, cfg, ctx = {}) {
  ensureLegacy(career);
  return (cfg.clubMilestones || []).map((m) => ({
    id: m.id,
    title: m.title,
    desc: m.desc,
    cash: m.cash,
    unlocked: !!career.legacy.milestones[m.id],
    unlockedAt: career.legacy.milestones[m.id] || null,
  }));
}
