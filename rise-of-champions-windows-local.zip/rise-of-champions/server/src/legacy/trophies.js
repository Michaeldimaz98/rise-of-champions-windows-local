// Trophy cabinet — trophies are created only by authoritative server events
// (league season end, ranked season finalization). Idempotent by trophy id.
// Phase 34.
import { assert } from '../core/validate.js';
import { ensureLegacy } from './records.js';

const VALID_TYPES = new Set(['league', 'cup', 'ranked', 'special', 'continental']);

/**
 * Award a trophy. Returns the trophy, or null if it already exists (replay-safe).
 */
export function awardTrophy(
  career,
  { id, type, competition, season, result } = {},
) {
  assert(id && typeof id === 'string', 'trophy id required');
  assert(VALID_TYPES.has(type), `invalid trophy type: ${type}`);
  ensureLegacy(career);
  if (career.legacy.trophies.some((t) => t.id === id)) return null;
  const trophy = {
    id,
    type,
    competition: String(competition ?? '').slice(0, 60),
    season: Number.isInteger(season) ? season : null,
    result: String(result ?? '').slice(0, 60),
    earnedAt: Date.now(),
  };
  career.legacy.trophies.push(trophy);
  return trophy;
}

export function trophyCount(career, type = null) {
  ensureLegacy(career);
  return career.legacy.trophies.filter((t) => !type || t.type === type).length;
}

export function trophiesByType(career) {
  ensureLegacy(career);
  const out = {};
  for (const t of career.legacy.trophies) out[t.type] = (out[t.type] || 0) + 1;
  return out;
}
