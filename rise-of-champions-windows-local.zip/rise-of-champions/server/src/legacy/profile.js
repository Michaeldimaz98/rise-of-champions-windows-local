// Manager profiles: own full profile + public profiles for other managers.
// Public profiles never expose cash, inbox, objectives, shop, or account data.
// Phase 34.
import { ensureLegacy } from './records.js';
import { computePrestige } from './prestige.js';
import { publicIdentity } from './identity.js';

function clubPublic(career, cfg, ctx) {
  const club = career.clubs[career.playerClubId].club;
  const prestige = computePrestige(career, ctx);
  const s = career.stats || {};
  return {
    clubName: club.name,
    shortName: club.shortName,
    season: career.season,
    prestige: prestige.score,
    prestigeTier: prestige.tier,
    reputation: club.reputation,
    level: club.level,
    trophies: career.legacy.trophies.length,
    matches: s.played || 0,
    wins: s.wins || 0,
    identity: publicIdentity(career),
  };
}

/** Full profile for the manager's own account (includes all their careers). */
export function ownManagerProfile(user, mgr, careers, cfg, rankedCtxOf) {
  const list = careers.filter((c) => c.userId === user.id);
  const clubs = list.map((c) => {
    ensureLegacy(c);
    return { ...clubPublic(c, cfg, rankedCtxOf(user.id)), careerId: c.id };
  });
  const totals = clubs.reduce(
    (a, c) => ({
      matches: a.matches + c.matches,
      wins: a.wins + c.wins,
      trophies: a.trophies + c.trophies,
    }),
    { matches: 0, wins: 0, trophies: 0 },
  );
  return {
    username: user.username,
    level: mgr?.level ?? 1,
    xp: mgr?.xp ?? 0,
    clubs,
    totals,
  };
}

/** Public profile for another manager: identity + achievements only. No economy. */
export function publicManagerProfile(user, mgr, careers, cfg, rankedCtxOf) {
  const list = careers.filter((c) => c.userId === user.id);
  return {
    username: user.username,
    level: mgr?.level ?? 1,
    clubs: list.map((c) => {
      ensureLegacy(c);
      const p = clubPublic(c, cfg, rankedCtxOf(user.id));
      return {
        clubName: p.clubName,
        shortName: p.shortName,
        season: p.season,
        prestige: p.prestige,
        prestigeTier: p.prestigeTier,
        trophies: p.trophies,
        matches: p.matches,
        wins: p.wins,
        identity: p.identity,
      };
    }),
  };
}
