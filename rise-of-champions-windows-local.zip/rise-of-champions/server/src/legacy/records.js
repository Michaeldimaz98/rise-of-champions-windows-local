// Club records — updated only from validated match results, never from clients.
// Phase 34.
import { assert } from '../core/validate.js';

function blankRecords() {
  return {
    biggestWin: null, // { gf, ga, opponent, at }
    biggestDefeat: null,
    mostGoalsInMatch: null,
    longestUnbeaten: 0,
  };
}

/** Ensure career.legacy + identity + streak counters exist (backfills old saves). */
export function ensureLegacy(career) {
  assert(career && typeof career === 'object', 'career required');
  if (!career.legacy || typeof career.legacy !== 'object') {
    career.legacy = { records: blankRecords(), trophies: [], milestones: {} };
  } else {
    career.legacy.records = { ...blankRecords(), ...(career.legacy.records || {}) };
    if (!Array.isArray(career.legacy.trophies)) career.legacy.trophies = [];
    if (!career.legacy.milestones || typeof career.legacy.milestones !== 'object') {
      career.legacy.milestones = {};
    }
  }
  if (!career.identity || typeof career.identity !== 'object') {
    career.identity = { motto: '', stadiumName: '' };
  }
  // Fill stat defaults field-by-field (never clobber): ensureLegacy may run
  // before ensureRewardState (rewards.js), and both must agree on the shape.
  if (!career.stats || typeof career.stats !== 'object') career.stats = {};
  for (const [k, v] of Object.entries({
    played: 0, wins: 0, draws: 0, losses: 0, goalsFor: 0,
    winStreak: 0, bestWinStreak: 0, unbeaten: 0, bestUnbeaten: 0,
  })) {
    if (career.stats[k] == null) career.stats[k] = v;
  }
  return career.legacy;
}

/**
 * Record one validated match result into club records.
 * Called server-side only, right after the authoritative result exists.
 */
export function recordMatch(career, { gf, ga, opponent = '', at = Date.now() } = {}) {
  assert(Number.isInteger(gf) && gf >= 0, 'gf must be a non-negative int');
  assert(Number.isInteger(ga) && ga >= 0, 'ga must be a non-negative int');
  ensureLegacy(career);
  const r = career.legacy.records;
  const won = gf > ga;
  const lost = ga > gf;

  // Streaks.
  career.stats.unbeaten = lost ? 0 : (career.stats.unbeaten || 0) + 1;
  career.stats.bestUnbeaten = Math.max(career.stats.bestUnbeaten || 0, career.stats.unbeaten);
  r.longestUnbeaten = Math.max(r.longestUnbeaten, career.stats.unbeaten);

  const rec = { gf, ga, opponent: String(opponent).slice(0, 60), at };
  const margin = gf - ga;
  if (won) {
    const cur = r.biggestWin;
    if (!cur || margin > cur.gf - cur.ga || (margin === cur.gf - cur.ga && gf > cur.gf)) {
      r.biggestWin = rec;
    }
  } else if (lost) {
    const cur = r.biggestDefeat;
    if (!cur || -margin > cur.ga - cur.gf || (-margin === cur.ga - cur.gf && ga > cur.ga)) {
      r.biggestDefeat = rec;
    }
  }
  const total = gf + ga;
  const curM = r.mostGoalsInMatch;
  if (!curM || total > curM.gf + curM.ga) r.mostGoalsInMatch = rec;
  return r;
}
