// Club identity — manager-editable data (motto, stadium name).
// Strict server-side validation; no moderation system at this phase.
// Phase 34.
import { assert } from '../core/validate.js';
import { ensureLegacy } from './records.js';

const RULES = {
  motto: { max: 80, field: 'motto' },
  stadiumName: { max: 40, field: 'stadium name' },
};

// Letters, digits, spaces and common punctuation; no control chars or markup.
const ALLOWED = /^[A-Za-z0-9 .,'"!?:;()\-#&\/+]*$/u;

export function validateIdentityText(value, { max, field }) {
  assert(typeof value === 'string', `${field} must be a string`);
  const v = value.trim();
  assert(v.length <= max, `${field} must be at most ${max} characters`);
  assert(ALLOWED.test(v), `${field} contains disallowed characters`);
  return v;
}

/** Update club identity (own career only — enforced by the route). */
export function updateIdentity(career, body = {}) {
  ensureLegacy(career);
  const out = {};
  if (body.motto !== undefined) out.motto = validateIdentityText(body.motto, RULES.motto);
  if (body.stadiumName !== undefined) {
    out.stadiumName = validateIdentityText(body.stadiumName, RULES.stadiumName);
  }
  assert(Object.keys(out).length > 0, 'nothing to update');
  Object.assign(career.identity, out);
  return { ...career.identity };
}

/** Public-safe identity (no private data). */
export function publicIdentity(career) {
  ensureLegacy(career);
  return {
    motto: career.identity.motto || '',
    stadiumName: career.identity.stadiumName || '',
  };
}
