import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createServer } from '../server/src/http/server.js';
import { sendInbox } from '../server/src/liveops/inbox.js';
import { createCareer } from '../server/src/career/career.js';
import { settleEvent } from '../server/src/events/events.js';
async function withServer(run) {
  const server = createServer();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  try { await run(server.address().port); }
  finally { await new Promise((resolve) => server.close(resolve)); }
}
test('health endpoint returns the application fingerprint', async () => {
  await withServer(async (port) => {
    const got = await new Promise((resolve, reject) => {
      http.get({ host: '127.0.0.1', port, path: '/__health' }, (res) => {
        let body = ''; res.setEncoding('utf8');
        res.on('data', (c) => { body += c; });
        res.on('end', () => resolve({ status: res.statusCode, body }));
      }).on('error', reject);
    });
    assert.equal(got.status, 200);
    assert.deepEqual(JSON.parse(got.body), { app: 'rise-of-champions', status: 'ok' });
  });
});
test('oversized request body receives 413', async () => {
  await withServer(async (port) => {
    const status = await new Promise((resolve, reject) => {
      const payload = Buffer.alloc(1_100_000, 0x41);
      const req = http.request({
        host: '127.0.0.1', port, path: '/api/phase79-body-limit-test', method: 'POST',
        headers: { 'content-type': 'application/json', 'content-length': payload.length },
      }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); });
      req.on('error', reject); req.end(payload);
    });
    assert.equal(status, 413);
  });
});
test('inbox dedupe key prevents duplicate Ranked result messages', () => {
  const state = {};
  const first = sendInbox(state, 'manager-1', {
    type: 'ranked_result', title: 'Ranked win', dedupeKey: 'ranked-result:fixture-1:manager-1',
  }, 1000);
  const replay = sendInbox(state, 'manager-1', {
    type: 'ranked_result', title: 'Ranked win retry', dedupeKey: 'ranked-result:fixture-1:manager-1',
  }, 2000);
  assert.equal(replay.id, first.id);
  assert.equal(state['manager-1'].length, 1);
});
test('Event retry after partial career save does not pay a manager twice', () => {
  const a = createCareer({ clubName: 'Phase79 Club A', seed: 'phase79-club-a' });
  let b = createCareer({ clubName: 'Phase79 Club B', seed: 'phase79-club-b' });
  const cashA0 = a.clubs[a.playerClubId].club.cash;
  const cashB0 = b.clubs[b.playerClubId].club.cash;
  const users = { userA: a, userB: b };
  const initialEvent = {
    id: 'evt-phase79-crash-recovery', name: 'Phase 79 Test Event', startsAt: 0, endsAt: 1,
    rewards: { '1': 50000, '2': 25000, participation: 1000 },
    participants: {
      userA: { username: 'Manager A', score: 20, played: 2, joinedAt: 1 },
      userB: { username: 'Manager B', score: 10, played: 1, joinedAt: 2 },
    },
    rewardsPaid: false,
  };
  const retryEvent = structuredClone(initialEvent);
  const first = settleEvent(initialEvent, {}, { getCareer: (uid) => users[uid], now: 2 });
  assert.equal(first.length, 2);
  const cashAAfterSave = a.clubs[a.playerClubId].club.cash;
  assert.equal(cashAAfterSave, cashA0 + 50000);
  assert.ok(a._eventRewardClaims.includes(initialEvent.id));
  // Simulate crash after A was saved but before B and events.json.
  b = createCareer({ clubName: 'Phase79 Club B', seed: 'phase79-club-b' });
  users.userB = b;
  const retry = settleEvent(retryEvent, {}, { getCareer: (uid) => users[uid], now: 2 });
  assert.deepEqual(retry.map((p) => p.userId), ['userB']);
  assert.equal(a.clubs[a.playerClubId].club.cash, cashAAfterSave);
  assert.equal(b.clubs[b.playerClubId].club.cash, cashB0 + 25000);
});
